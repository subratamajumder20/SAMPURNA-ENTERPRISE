-- 002_bb_motors.sql
-- SAMPURNA AI Phase 2A Production Module: B.B. Motors (Automotive Workshop & Services)

CREATE TABLE IF NOT EXISTS bb_workshops (
    workshop_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    location TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'ACTIVE'
);

CREATE TABLE IF NOT EXISTS bb_vehicles (
    vehicle_id TEXT PRIMARY KEY,
    customer_id TEXT NOT NULL,
    registration_number TEXT UNIQUE NOT NULL,
    make TEXT NOT NULL,
    model TEXT NOT NULL,
    year INTEGER,
    vin TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bb_job_cards (
    job_card_id TEXT PRIMARY KEY,
    job_number TEXT UNIQUE NOT NULL, -- e.g. BB-JC-2026-000001
    vehicle_id TEXT NOT NULL,
    customer_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'OPEN', -- OPEN, ESTIMATED, IN_PROGRESS, READY, DELIVERED, CLOSED
    assigned_mechanic TEXT,
    estimated_cost REAL DEFAULT 0.0,
    actual_cost REAL DEFAULT 0.0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
