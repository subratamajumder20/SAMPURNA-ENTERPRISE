-- 001_initial_schema.sql
-- SAMPURNA AI Phase 1 Core Architecture
-- Authentication, RBAC, Multi-Business Tenant Isolation, Approval Engine, Audit Logging

CREATE TABLE IF NOT EXISTS users (
    user_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    phone TEXT,
    role TEXT NOT NULL, -- OWNER, ADMIN, MANAGER, SALES, PRODUCTION_MANAGER, DESIGNER, STORE_KEEPER, PURCHASE, DELIVERY, ACCOUNTANT, READ_ONLY
    business_access TEXT NOT NULL, -- ALL, SAMPURNA_ENTERPRISE, BB_MOTORS, RENAISSANCE_HOTELS, SAMPURNA_FINANCIAL
    division_access TEXT NOT NULL DEFAULT 'BOTH', -- PRINTING, TRADING, BOTH
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS approval_requests (
    request_id TEXT PRIMARY KEY,
    business_id TEXT NOT NULL,
    division_id TEXT,
    request_type TEXT NOT NULL, -- LARGE_DISCOUNT, PURCHASE_ORDER, INVENTORY_ADJUSTMENT, REFUND, CREDIT_SALE, URGENT_PRODUCTION, INVOICE_CANCELLATION
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    requested_by TEXT NOT NULL,
    amount REAL DEFAULT 0.0,
    threshold REAL DEFAULT 0.0,
    details TEXT,
    status TEXT NOT NULL DEFAULT 'PENDING', -- PENDING, APPROVED, REJECTED
    reviewed_by TEXT,
    reviewed_at TIMESTAMP,
    rejection_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS audit_logs (
    log_id TEXT PRIMARY KEY,
    actor_id TEXT NOT NULL,
    actor_name TEXT NOT NULL,
    business TEXT NOT NULL,
    division TEXT,
    entity TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    action TEXT NOT NULL,
    details TEXT,
    result TEXT NOT NULL, -- SUCCESS, FAILED, REJECTED
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS shared_customers (
    customer_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    alternate_phone TEXT,
    email TEXT,
    address TEXT,
    city TEXT,
    state TEXT,
    pincode TEXT,
    gstin_optional TEXT,
    customer_type TEXT NOT NULL DEFAULT 'INDIVIDUAL', -- INDIVIDUAL, BUSINESS, CORPORATE, GOVERNMENT, OTHER
    notes TEXT,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS shared_suppliers (
    supplier_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT,
    address TEXT,
    gstin TEXT,
    products_supplied TEXT,
    payment_terms TEXT,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS shared_invoices (
    invoice_id TEXT PRIMARY KEY,
    invoice_number TEXT UNIQUE NOT NULL,
    business_id TEXT NOT NULL,
    division_id TEXT,
    order_id TEXT,
    quotation_id TEXT,
    customer_id TEXT NOT NULL,
    invoice_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    subtotal REAL NOT NULL,
    discount REAL DEFAULT 0.0,
    taxable_value REAL NOT NULL,
    cgst REAL DEFAULT 0.0,
    sgst REAL DEFAULT 0.0,
    igst REAL DEFAULT 0.0,
    total_tax REAL NOT NULL,
    grand_total REAL NOT NULL,
    balance_due REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'UNPAID', -- UNPAID, PARTIALLY_PAID, PAID, CANCELLED
    created_by TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS shared_payments (
    payment_id TEXT PRIMARY KEY,
    invoice_id TEXT NOT NULL,
    customer_id TEXT NOT NULL,
    amount REAL NOT NULL,
    payment_method TEXT NOT NULL, -- CASH, UPI, CARD, BANK_TRANSFER, OTHER
    reference_number TEXT,
    notes TEXT,
    received_by TEXT NOT NULL,
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
