-- 004_sampurna_enterprise.sql
-- SAMPURNA AI Phase 2C: Sampurna Enterprise Business Management Module
-- Division A: Printing & Digital Services | Division B: Building & Trading Materials

-- 1. Divisions
CREATE TABLE IF NOT EXISTS enterprise_divisions (
    division_id TEXT PRIMARY KEY, -- 'PRINTING', 'TRADING'
    name TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'ACTIVE'
);

-- 2. Categories
CREATE TABLE IF NOT EXISTS enterprise_categories (
    category_id TEXT PRIMARY KEY,
    division_id TEXT NOT NULL, -- PRINTING or TRADING
    name TEXT NOT NULL,
    code TEXT NOT NULL UNIQUE,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    FOREIGN KEY (division_id) REFERENCES enterprise_divisions(division_id)
);

-- 3. Products
CREATE TABLE IF NOT EXISTS enterprise_products (
    product_id TEXT PRIMARY KEY,
    division_id TEXT NOT NULL, -- PRINTING or TRADING
    category_id TEXT NOT NULL,
    product_code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    description TEXT,
    unit TEXT NOT NULL, -- PCS, BOX, PACK, SHEET, BAG, TON, SQFT, MTR, KG
    purchase_price REAL NOT NULL DEFAULT 0.0,
    selling_price REAL NOT NULL DEFAULT 0.0,
    gst_rate REAL NOT NULL DEFAULT 18.0, -- Configurable GST % (5, 12, 18, 28)
    minimum_stock REAL NOT NULL DEFAULT 0.0,
    reorder_quantity REAL NOT NULL DEFAULT 0.0,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (division_id) REFERENCES enterprise_divisions(division_id),
    FOREIGN KEY (category_id) REFERENCES enterprise_categories(category_id)
);

-- 4. Rate Cards & Versions (Deterministic Pricing Engine & Historical Immutability)
CREATE TABLE IF NOT EXISTS enterprise_rate_cards (
    rate_card_id TEXT PRIMARY KEY,
    division_id TEXT NOT NULL, -- PRINTING or TRADING
    product_id TEXT NOT NULL,
    paper_type TEXT, -- e.g. Art Card, Ivory, SBS, Kraft, Maplitho
    paper_size TEXT, -- e.g. A4, A3, 12x18, 13x19, Custom
    gsm INTEGER, -- e.g. 130, 170, 250, 300, 350
    colour_mode TEXT, -- SINGLE_COLOUR, MULTI_COLOUR, CMYK, B_AND_W
    side_count INTEGER DEFAULT 1, -- 1 = single side, 2 = double side
    min_quantity INTEGER NOT NULL DEFAULT 1,
    max_quantity INTEGER,
    base_rate_per_unit REAL NOT NULL,
    setup_charge REAL DEFAULT 0.0,
    finishing_rate REAL DEFAULT 0.0, -- Lamination, UV, Foiling, Embossing
    binding_rate REAL DEFAULT 0.0, -- Saddle Stitch, Perfect, Spiral, Wiro
    cutting_folding_rate REAL DEFAULT 0.0,
    urgent_surcharge_rate REAL DEFAULT 0.0,
    version INTEGER NOT NULL DEFAULT 1,
    is_active INTEGER NOT NULL DEFAULT 1,
    effective_from TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    effective_to TIMESTAMP,
    created_by TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS enterprise_rate_versions (
    version_id TEXT PRIMARY KEY,
    rate_card_id TEXT NOT NULL,
    version_number INTEGER NOT NULL,
    rate_data_json TEXT NOT NULL,
    changed_by TEXT NOT NULL,
    change_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5. Quotations
CREATE TABLE IF NOT EXISTS enterprise_quotations (
    quotation_id TEXT PRIMARY KEY,
    quotation_number TEXT UNIQUE NOT NULL, -- SE-PRINT-QTN-2026-000001 or SE-TRD-QTN-2026-000001
    customer_id TEXT NOT NULL,
    division_id TEXT NOT NULL, -- PRINTING or TRADING
    rate_card_version_applied INTEGER,
    valid_until DATE NOT NULL,
    subtotal REAL NOT NULL,
    discount REAL NOT NULL DEFAULT 0.0,
    taxable_value REAL NOT NULL,
    cgst REAL NOT NULL DEFAULT 0.0,
    sgst REAL NOT NULL DEFAULT 0.0,
    igst REAL NOT NULL DEFAULT 0.0,
    tax REAL NOT NULL,
    grand_total REAL NOT NULL,
    terms TEXT,
    notes TEXT,
    status TEXT NOT NULL DEFAULT 'DRAFT', -- DRAFT, SENT, PENDING_APPROVAL, CUSTOMER_APPROVED, CUSTOMER_REJECTED, EXPIRED, CONVERTED, CANCELLED
    approval_request_id TEXT,
    created_by TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES shared_customers(customer_id),
    FOREIGN KEY (division_id) REFERENCES enterprise_divisions(division_id)
);

CREATE TABLE IF NOT EXISTS enterprise_quotation_items (
    quotation_item_id TEXT PRIMARY KEY,
    quotation_id TEXT NOT NULL,
    product_id TEXT NOT NULL,
    description TEXT,
    specification_json TEXT, -- paper_type, gsm, colour, side, lamination, binding, etc.
    quantity REAL NOT NULL,
    unit TEXT NOT NULL,
    unit_price REAL NOT NULL,
    discount REAL NOT NULL DEFAULT 0.0,
    tax_rate REAL NOT NULL,
    taxable_value REAL NOT NULL,
    cgst REAL NOT NULL DEFAULT 0.0,
    sgst REAL NOT NULL DEFAULT 0.0,
    igst REAL NOT NULL DEFAULT 0.0,
    tax REAL NOT NULL,
    line_total REAL NOT NULL,
    FOREIGN KEY (quotation_id) REFERENCES enterprise_quotations(quotation_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES enterprise_products(product_id)
);

-- 6. Orders
CREATE TABLE IF NOT EXISTS enterprise_orders (
    order_id TEXT PRIMARY KEY,
    order_number TEXT UNIQUE NOT NULL, -- SE-PRINT-ORD-2026-000001 or SE-TRD-ORD-2026-000001
    customer_id TEXT NOT NULL,
    division_id TEXT NOT NULL, -- PRINTING or TRADING
    quotation_id TEXT,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    required_date DATE,
    priority TEXT NOT NULL DEFAULT 'NORMAL', -- LOW, NORMAL, HIGH, URGENT
    status TEXT NOT NULL, -- Printing: QUOTATION_APPROVED, ARTWORK, MATERIAL, PRODUCTION, QC, PACKING, DELIVERY, COMPLETED
                          -- Trading: ORDER_CONFIRMED, STOCK_RESERVED, READY_FOR_DISPATCH, DISPATCHED, DELIVERED, COMPLETED
    subtotal REAL NOT NULL,
    discount REAL NOT NULL DEFAULT 0.0,
    taxable_value REAL NOT NULL,
    tax REAL NOT NULL,
    grand_total REAL NOT NULL,
    notes TEXT,
    created_by TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES shared_customers(customer_id),
    FOREIGN KEY (division_id) REFERENCES enterprise_divisions(division_id)
);

CREATE TABLE IF NOT EXISTS enterprise_order_items (
    order_item_id TEXT PRIMARY KEY,
    order_id TEXT NOT NULL,
    product_id TEXT NOT NULL,
    description TEXT,
    specification_json TEXT,
    quantity REAL NOT NULL,
    unit TEXT NOT NULL,
    unit_price REAL NOT NULL,
    tax_rate REAL NOT NULL,
    line_total REAL NOT NULL,
    FOREIGN KEY (order_id) REFERENCES enterprise_orders(order_id) ON DELETE CASCADE
);

-- 7. Artwork Management (Strictly separated from Quotation approval)
CREATE TABLE IF NOT EXISTS enterprise_artworks (
    artwork_id TEXT PRIMARY KEY,
    order_id TEXT NOT NULL,
    file_name TEXT NOT NULL,
    file_type TEXT NOT NULL,
    storage_reference TEXT NOT NULL, -- Object storage or Google Drive URI
    version INTEGER NOT NULL DEFAULT 1,
    uploaded_by TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'PENDING', -- NOT_REQUIRED, PENDING, UPLOADED, UNDER_REVIEW, CUSTOMER_REVIEW, APPROVED, REJECTED, REVISION_REQUIRED
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES enterprise_orders(order_id)
);

-- 8. Production Jobs & Kanban
CREATE TABLE IF NOT EXISTS enterprise_production_jobs (
    production_job_id TEXT PRIMARY KEY,
    job_number TEXT UNIQUE NOT NULL, -- SE-PRD-2026-000001
    order_id TEXT NOT NULL,
    division_id TEXT NOT NULL DEFAULT 'PRINTING',
    priority TEXT NOT NULL DEFAULT 'NORMAL', -- LOW, NORMAL, HIGH, URGENT
    assigned_to TEXT,
    planned_start TIMESTAMP,
    planned_completion TIMESTAMP,
    actual_start TIMESTAMP,
    actual_completion TIMESTAMP,
    status TEXT NOT NULL DEFAULT 'QUEUED', -- QUEUED, ARTWORK_PENDING, MATERIAL_PENDING, READY_FOR_PRODUCTION, IN_PRODUCTION, PAUSED, QUALITY_CHECK, READY_FOR_PACKING, PACKED, READY_FOR_DELIVERY, COMPLETED, CANCELLED
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES enterprise_orders(order_id)
);

-- 9. Material Requirements & Consumables
CREATE TABLE IF NOT EXISTS enterprise_material_requirements (
    requirement_id TEXT PRIMARY KEY,
    production_job_id TEXT NOT NULL,
    material_id TEXT NOT NULL,
    material_name TEXT NOT NULL,
    quantity_required REAL NOT NULL,
    quantity_reserved REAL NOT NULL DEFAULT 0.0,
    quantity_issued REAL NOT NULL DEFAULT 0.0,
    unit TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'REQUIRED', -- REQUIRED, RESERVED, PARTIALLY_AVAILABLE, AVAILABLE, ISSUED, SHORTAGE
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (production_job_id) REFERENCES enterprise_production_jobs(production_job_id)
);

-- 10. Inventory (Division Isolated, Negative Stock Prevented)
CREATE TABLE IF NOT EXISTS enterprise_inventory (
    inventory_id TEXT PRIMARY KEY,
    division_id TEXT NOT NULL, -- PRINTING or TRADING
    product_or_material_id TEXT NOT NULL,
    name TEXT NOT NULL,
    unit TEXT NOT NULL,
    current_stock REAL NOT NULL DEFAULT 0.0,
    reserved_stock REAL NOT NULL DEFAULT 0.0,
    available_stock REAL NOT NULL DEFAULT 0.0, -- current_stock - reserved_stock
    minimum_stock REAL NOT NULL DEFAULT 0.0,
    reorder_quantity REAL NOT NULL DEFAULT 0.0,
    location TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (division_id) REFERENCES enterprise_divisions(division_id),
    CONSTRAINT chk_positive_current_stock CHECK (current_stock >= 0),
    CONSTRAINT chk_positive_reserved_stock CHECK (reserved_stock >= 0)
);

CREATE TABLE IF NOT EXISTS enterprise_inventory_transactions (
    transaction_id TEXT PRIMARY KEY,
    inventory_id TEXT NOT NULL,
    division_id TEXT NOT NULL,
    transaction_type TEXT NOT NULL, -- PURCHASE, RESERVATION, RELEASE, ISSUE, RETURN, ADJUSTMENT_IN, ADJUSTMENT_OUT, SALE, DAMAGE, TRANSFER
    quantity REAL NOT NULL,
    stock_before REAL NOT NULL,
    stock_after REAL NOT NULL,
    reference_type TEXT, -- ORDER, PRODUCTION_JOB, PURCHASE_ORDER, AUDIT
    reference_id TEXT,
    notes TEXT,
    performed_by TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (inventory_id) REFERENCES enterprise_inventory(inventory_id)
);

-- 11. Purchase Requests & Purchase Orders & Goods Receipt
CREATE TABLE IF NOT EXISTS enterprise_purchase_requests (
    purchase_request_id TEXT PRIMARY KEY,
    division_id TEXT NOT NULL,
    material_or_product_id TEXT NOT NULL,
    material_name TEXT NOT NULL,
    quantity REAL NOT NULL,
    unit TEXT NOT NULL,
    required_by DATE,
    production_job_id TEXT,
    priority TEXT NOT NULL DEFAULT 'NORMAL',
    status TEXT NOT NULL DEFAULT 'PENDING_APPROVAL', -- DRAFT, PENDING_APPROVAL, APPROVED, ORDERED, PARTIALLY_RECEIVED, RECEIVED, CANCELLED
    approval_request_id TEXT,
    notes TEXT,
    requested_by TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS enterprise_purchase_orders (
    purchase_order_id TEXT PRIMARY KEY,
    po_number TEXT UNIQUE NOT NULL, -- SE-PO-2026-000001
    division_id TEXT NOT NULL,
    supplier_id TEXT NOT NULL,
    items_json TEXT NOT NULL,
    quantity REAL NOT NULL,
    subtotal REAL NOT NULL,
    tax REAL NOT NULL,
    total REAL NOT NULL,
    expected_delivery DATE,
    status TEXT NOT NULL DEFAULT 'DRAFT', -- DRAFT, PENDING_APPROVAL, APPROVED, ORDERED, PARTIALLY_RECEIVED, RECEIVED, CANCELLED
    created_by TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (supplier_id) REFERENCES shared_suppliers(supplier_id)
);

CREATE TABLE IF NOT EXISTS enterprise_goods_receipts (
    receipt_id TEXT PRIMARY KEY,
    receipt_number TEXT UNIQUE NOT NULL, -- SE-GRN-2026-000001
    purchase_order_id TEXT NOT NULL,
    inventory_id TEXT NOT NULL,
    quantity_received REAL NOT NULL,
    unit TEXT NOT NULL,
    received_by TEXT NOT NULL,
    notes TEXT,
    received_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (purchase_order_id) REFERENCES enterprise_purchase_orders(purchase_order_id),
    FOREIGN KEY (inventory_id) REFERENCES enterprise_inventory(inventory_id)
);

-- 12. Quality Control & Rework
CREATE TABLE IF NOT EXISTS enterprise_quality_checks (
    qc_id TEXT PRIMARY KEY,
    production_job_id TEXT NOT NULL,
    order_id TEXT NOT NULL,
    checklist_results_json TEXT NOT NULL, -- print_quality, colour_accuracy, paper, size, cutting, alignment, lamination, binding, spelling, artwork_version, physical_damage
    checked_by TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'PENDING', -- PENDING, PASSED, FAILED, REWORK_REQUIRED
    remarks TEXT,
    checked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (production_job_id) REFERENCES enterprise_production_jobs(production_job_id)
);

CREATE TABLE IF NOT EXISTS enterprise_rework (
    rework_id TEXT PRIMARY KEY,
    production_job_id TEXT NOT NULL,
    qc_id TEXT NOT NULL,
    reason TEXT NOT NULL,
    failed_items_count INTEGER NOT NULL,
    responsible_stage TEXT NOT NULL,
    rework_count INTEGER NOT NULL DEFAULT 1,
    notes TEXT,
    created_by TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (production_job_id) REFERENCES enterprise_production_jobs(production_job_id),
    FOREIGN KEY (qc_id) REFERENCES enterprise_quality_checks(qc_id)
);

-- 13. Packing
CREATE TABLE IF NOT EXISTS enterprise_packing (
    packing_id TEXT PRIMARY KEY,
    order_id TEXT NOT NULL,
    quantity REAL NOT NULL,
    package_count INTEGER NOT NULL DEFAULT 1,
    packed_by TEXT NOT NULL,
    packed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    status TEXT NOT NULL DEFAULT 'COMPLETED', -- PENDING, IN_PROGRESS, COMPLETED
    FOREIGN KEY (order_id) REFERENCES enterprise_orders(order_id)
);

-- 14. Deliveries
CREATE TABLE IF NOT EXISTS enterprise_deliveries (
    delivery_id TEXT PRIMARY KEY,
    delivery_number TEXT UNIQUE NOT NULL, -- SE-DEL-2026-000001
    order_id TEXT NOT NULL,
    customer_id TEXT NOT NULL,
    delivery_address TEXT NOT NULL,
    delivery_method TEXT NOT NULL, -- CUSTOMER_PICKUP, COMPANY_DELIVERY, COURIER, TRANSPORT, OTHER
    delivery_person TEXT,
    vehicle_optional TEXT,
    scheduled_date DATE,
    actual_date TIMESTAMP,
    status TEXT NOT NULL DEFAULT 'PENDING', -- PENDING, SCHEDULED, OUT_FOR_DELIVERY, DELIVERED, FAILED, CANCELLED
    proof_reference_optional TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES enterprise_orders(order_id),
    FOREIGN KEY (customer_id) REFERENCES shared_customers(customer_id)
);

-- Indexes for performance & division isolation
CREATE INDEX IF NOT EXISTS idx_ent_prod_division ON enterprise_products(division_id);
CREATE INDEX IF NOT EXISTS idx_ent_quote_division ON enterprise_quotations(division_id);
CREATE INDEX IF NOT EXISTS idx_ent_quote_customer ON enterprise_quotations(customer_id);
CREATE INDEX IF NOT EXISTS idx_ent_order_division ON enterprise_orders(division_id);
CREATE INDEX IF NOT EXISTS idx_ent_order_customer ON enterprise_orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_ent_inv_division ON enterprise_inventory(division_id);
CREATE INDEX IF NOT EXISTS idx_ent_prod_job_status ON enterprise_production_jobs(status);
