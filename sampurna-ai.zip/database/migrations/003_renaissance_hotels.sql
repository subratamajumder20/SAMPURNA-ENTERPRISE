-- 003_renaissance_hotels.sql
-- SAMPURNA AI Phase 2B Production Module: Renaissance Hotels (Hospitality & Rooms)

CREATE TABLE IF NOT EXISTS rh_properties (
    property_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    location TEXT NOT NULL, -- e.g. Puri, Bhubaneswar
    status TEXT NOT NULL DEFAULT 'ACTIVE'
);

CREATE TABLE IF NOT EXISTS rh_room_types (
    room_type_id TEXT PRIMARY KEY,
    property_id TEXT NOT NULL,
    name TEXT NOT NULL, -- Deluxe, Super Deluxe, Suite
    base_rate REAL NOT NULL,
    capacity INTEGER NOT NULL DEFAULT 2
);

CREATE TABLE IF NOT EXISTS rh_reservations (
    reservation_id TEXT PRIMARY KEY,
    reservation_number TEXT UNIQUE NOT NULL, -- e.g. RH-RES-2026-000001
    property_id TEXT NOT NULL,
    customer_id TEXT NOT NULL,
    room_type_id TEXT NOT NULL,
    check_in DATE NOT NULL,
    check_out DATE NOT NULL,
    status TEXT NOT NULL DEFAULT 'CONFIRMED', -- CONFIRMED, CHECKED_IN, CHECKED_OUT, CANCELLED
    total_amount REAL NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
