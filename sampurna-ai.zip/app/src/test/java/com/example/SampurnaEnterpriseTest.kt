package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.core.ai.AiRouter
import com.example.core.ai.AiToolRegistry
import com.example.core.ai.RoutingTarget
import com.example.core.approval.ApprovalEngine
import com.example.core.approval.ApprovalType
import com.example.core.auth.BusinessTenant
import com.example.core.auth.DivisionTenant
import com.example.core.auth.RBACManager
import com.example.core.auth.UserRole
import com.example.core.auth.UserSession
import com.example.core.financial.DeterministicFinancialEngine
import com.example.core.financial.PrintSpecification
import com.example.data.db.SampurnaDatabase
import com.example.data.model.*
import com.example.data.repository.SampurnaRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SampurnaEnterpriseTest {

    private lateinit var db: SampurnaDatabase
    private lateinit var repo: SampurnaRepository
    private lateinit var aiRegistry: AiToolRegistry

    private val ownerUser = UserSession("U-1", "Owner User", "owner@sampurna.in", UserRole.OWNER, BusinessTenant.ALL, DivisionTenant.BOTH)
    private val salesUser = UserSession("U-2", "Sales Rep", "sales@sampurna.in", UserRole.SALES, BusinessTenant.SAMPURNA_ENTERPRISE, DivisionTenant.BOTH)
    private val printManager = UserSession("U-3", "Print Lead", "print@sampurna.in", UserRole.PRODUCTION_MANAGER, BusinessTenant.SAMPURNA_ENTERPRISE, DivisionTenant.PRINTING)
    private val tradingStore = UserSession("U-4", "Store Keeper", "store@sampurna.in", UserRole.STORE_KEEPER, BusinessTenant.SAMPURNA_ENTERPRISE, DivisionTenant.TRADING)

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, SampurnaDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repo = SampurnaRepository(db)
        aiRegistry = AiToolRegistry(repo)

        runBlocking {
            repo.seedDemoDataIfEmpty()
        }
    }

    @After
    fun tearDown() {
        db.close()
    }

    // 1. Customer creation
    @Test
    fun test01_customerCreation() = runBlocking {
        val res = repo.createCustomer("Test Corp", "9998887771", "test@corp.com", null, "Plot 1", "Bhubaneswar", "Odisha", "751024", "21AAAC0000A1Z1", "BUSINESS", null, ownerUser)
        assertTrue(res.isSuccess)
        val customer = res.getOrThrow()
        assertEquals("Test Corp", customer.name)
        assertEquals("9998887771", customer.phone)

        // Duplicate phone prevention
        val dup = repo.createCustomer("Test Corp 2", "9998887771", "other@corp.com", null, null, null, null, null, null, "BUSINESS", null, ownerUser)
        assertTrue(dup.isFailure)
    }

    // 2. Product creation
    @Test
    fun test02_productCreation() = runBlocking {
        val res = repo.createProduct("PRINTING", "CAT-VC", "TEST-VC-01", "Silk Visiting Cards", "Matte silk cards", "BOX", 100.0, 300.0, 18.0, 10.0, 50.0, ownerUser)
        assertTrue(res.isSuccess)
        val prod = res.getOrThrow()
        assertEquals("PRINTING", prod.divisionId)
        assertEquals(300.0, prod.sellingPrice, 0.01)
    }

    // 3. Division isolation
    @Test
    fun test03_divisionIsolation() = runBlocking {
        val printingProds = repo.getProductsByDivision("PRINTING").first()
        val tradingProds = repo.getProductsByDivision("TRADING").first()

        assertTrue(printingProds.all { it.divisionId == "PRINTING" })
        assertTrue(tradingProds.all { it.divisionId == "TRADING" })

        // Cannot create printing quote with trading product
        val cement = tradingProds.first { it.productCode.contains("CEM") }
        val cust = repo.getAllCustomers().first().first()
        val quoteRes = repo.createPrintQuotation(cust.customerId, cement.productId, PrintSpecification(), 0.0, false, null, salesUser)
        assertTrue(quoteRes.isFailure)
    }

    // 4. Rate-card creation
    @Test
    fun test04_rateCardCreation() = runBlocking {
        val card = EnterpriseRateCardEntity(
            rateCardId = "RC-TEST-01",
            divisionId = "PRINTING",
            productId = "PROD-VC-001",
            paperType = "Ivory Card",
            gsm = 300,
            sideCount = 1,
            baseRatePerUnit = 2.50,
            setupCharge = 100.0,
            createdBy = "Admin"
        )
        val saved = repo.createOrUpdateRateCard(card, ownerUser)
        assertEquals(1, saved.version)
        assertEquals(2.50, saved.baseRatePerUnit, 0.01)
    }

    // 5. Rate versioning
    @Test
    fun test05_rateVersioning() = runBlocking {
        val card = EnterpriseRateCardEntity(
            rateCardId = "RC-TEST-VER",
            divisionId = "PRINTING",
            productId = "PROD-VC-001",
            baseRatePerUnit = 2.50,
            createdBy = "Admin"
        )
        val v1 = repo.createOrUpdateRateCard(card, ownerUser)
        assertEquals(1, v1.version)

        val v2 = repo.createOrUpdateRateCard(v1.copy(baseRatePerUnit = 3.10), ownerUser, "Inflation price increase")
        assertEquals(2, v2.version)
        assertEquals(3.10, v2.baseRatePerUnit, 0.01)
    }

    // 6. Deterministic print quotation
    @Test
    fun test06_deterministicPrintQuotation() {
        val spec = PrintSpecification(quantity = 500, sideCount = 2, lamination = "Matte", gsm = 350)
        val cost = DeterministicFinancialEngine.calculatePrintItemCost(spec, baseRatePerUnit = 2.80, setupCharge = 150.0)
        assertTrue(cost > 0.0)
        // Ensure deterministic repeatable result
        val cost2 = DeterministicFinancialEngine.calculatePrintItemCost(spec, baseRatePerUnit = 2.80, setupCharge = 150.0)
        assertEquals(cost, cost2, 0.001)
    }

    // 7. Deterministic trading quotation
    @Test
    fun test07_deterministicTradingQuotation() {
        val tax = DeterministicFinancialEngine.calculateTax(subtotal = 7700.0, discountPercent = 5.0, gstRate = 28.0)
        assertEquals(7700.0, tax.subtotal, 0.01)
        assertEquals(385.0, tax.discountAmount, 0.01)
        assertEquals(7315.0, tax.taxableValue, 0.01)
        assertEquals(2048.20, tax.totalTax, 0.01)
        assertEquals(9363.20, tax.grandTotal, 0.01)
    }

    // 8. GST calculation
    @Test
    fun test08_gstCalculation() {
        // Intra-state (CGST + SGST)
        val intra = DeterministicFinancialEngine.calculateTax(1000.0, 0.0, 18.0, isInterState = false)
        assertEquals(90.0, intra.cgst, 0.01)
        assertEquals(90.0, intra.sgst, 0.01)
        assertEquals(0.0, intra.igst, 0.01)
        assertEquals(180.0, intra.totalTax, 0.01)

        // Inter-state (IGST)
        val inter = DeterministicFinancialEngine.calculateTax(1000.0, 0.0, 18.0, isInterState = true)
        assertEquals(0.0, inter.cgst, 0.01)
        assertEquals(0.0, inter.sgst, 0.01)
        assertEquals(180.0, inter.igst, 0.01)
        assertEquals(180.0, inter.totalTax, 0.01)
    }

    // 9. Quotation creation
    @Test
    fun test09_quotationCreation() = runBlocking {
        val cust = repo.getAllCustomers().first().first()
        val prod = repo.getProductsByDivision("PRINTING").first().first()
        val res = repo.createPrintQuotation(cust.customerId, prod.productId, PrintSpecification(quantity = 200), 5.0, false, "Standard print", salesUser)
        assertTrue(res.isSuccess)
        val quote = res.getOrThrow()
        assertTrue(quote.quotationNumber.startsWith("SE-PRINT-QTN-2026-"))
        assertEquals("DRAFT", quote.status)
    }

    // 10. Quotation approval
    @Test
    fun test10_quotationApproval() = runBlocking {
        val cust = repo.getAllCustomers().first().first()
        val prod = repo.getProductsByDivision("PRINTING").first().first()
        val quote = repo.createPrintQuotation(cust.customerId, prod.productId, PrintSpecification(), 0.0, false, null, salesUser).getOrThrow()

        val approved = repo.approveQuotation(quote.quotationId, salesUser).getOrThrow()
        assertEquals("CUSTOMER_APPROVED", approved.status)
    }

    // 11. Artwork workflow
    @Test
    fun test11_artworkWorkflow() = runBlocking {
        val cust = repo.getAllCustomers().first().first()
        val prod = repo.getProductsByDivision("PRINTING").first().first()
        val quote = repo.createPrintQuotation(cust.customerId, prod.productId, PrintSpecification(), 0.0, false, null, salesUser).getOrThrow()
        repo.approveQuotation(quote.quotationId, salesUser)
        val order = repo.convertQuotationToOrder(quote.quotationId, salesUser).getOrThrow()

        val uploaded = repo.uploadArtwork(order.orderId, "client_design.pdf", "application/pdf", "gdrive://artwork/client_design.pdf", salesUser).getOrThrow()
        assertEquals("CUSTOMER_REVIEW", uploaded.status)

        val approvedArt = repo.approveArtwork(uploaded.artworkId, salesUser).getOrThrow()
        assertEquals("APPROVED", approvedArt.status)
    }

    // 12. Production job creation (Gated by artwork)
    @Test
    fun test12_productionJobCreation() = runBlocking {
        val cust = repo.getAllCustomers().first().first()
        val prod = repo.getProductsByDivision("PRINTING").first().first()
        val quote = repo.createPrintQuotation(cust.customerId, prod.productId, PrintSpecification(), 0.0, false, null, salesUser).getOrThrow()
        repo.approveQuotation(quote.quotationId, salesUser)
        val order = repo.convertQuotationToOrder(quote.quotationId, salesUser).getOrThrow()

        // Artwork not approved yet -> Production job creation must FAIL
        val earlyJob = repo.createProductionJob(order.orderId, printManager)
        assertTrue(earlyJob.isFailure)

        // Upload and approve artwork
        val art = repo.uploadArtwork(order.orderId, "design.pdf", "pdf", "uri", salesUser).getOrThrow()
        repo.approveArtwork(art.artworkId, salesUser)

        // Now production job succeeds
        val jobRes = repo.createProductionJob(order.orderId, printManager)
        assertTrue(jobRes.isSuccess)
        val job = jobRes.getOrThrow()
        assertTrue(job.jobNumber.startsWith("SE-PRD-2026-"))
        assertEquals("MATERIAL_PENDING", job.status)
    }

    // 13. Material requirement
    @Test
    fun test13_materialRequirement() = runBlocking {
        val cust = repo.getAllCustomers().first().first()
        val prod = repo.getProductsByDivision("PRINTING").first().first()
        val quote = repo.createPrintQuotation(cust.customerId, prod.productId, PrintSpecification(), 0.0, false, null, salesUser).getOrThrow()
        repo.approveQuotation(quote.quotationId, salesUser)
        val order = repo.convertQuotationToOrder(quote.quotationId, salesUser).getOrThrow()
        val art = repo.uploadArtwork(order.orderId, "d.pdf", "pdf", "uri", salesUser).getOrThrow()
        repo.approveArtwork(art.artworkId, salesUser)
        val job = repo.createProductionJob(order.orderId, printManager).getOrThrow()

        val reqs = db.productionDao().getMaterialRequirements(job.productionJobId)
        assertTrue(reqs.isNotEmpty())
        assertEquals("MAT-PAP-300", reqs.first().materialId)
    }

    // 14. Inventory reservation
    @Test
    fun test14_inventoryReservation() = runBlocking {
        val inv = db.inventoryDao().getInventoryByProductOrMaterialId("MAT-PAP-300")!!
        val initialAvailable = inv.availableStock
        val initialReserved = inv.reservedStock

        val res = repo.reserveMaterial("JOB-101", "MAT-PAP-300", 300.0, printManager)
        assertTrue(res.isSuccess)

        val updatedInv = db.inventoryDao().getInventoryByProductOrMaterialId("MAT-PAP-300")!!
        assertEquals(initialReserved + 300.0, updatedInv.reservedStock, 0.01)
        assertEquals(initialAvailable - 300.0, updatedInv.availableStock, 0.01)
    }

    // 15. Negative inventory prevention
    @Test
    fun test15_negativeInventoryPrevention() = runBlocking {
        val inv = db.inventoryDao().getInventoryByProductOrMaterialId("MAT-PAP-300")!!
        val hugeQty = inv.availableStock + 10000.0

        val res = repo.reserveMaterial("JOB-999", "MAT-PAP-300", hugeQty, printManager)
        assertTrue(res.isFailure)
        assertTrue(res.exceptionOrNull()?.message?.contains("shortage", ignoreCase = true) == true)

        // Verify stock remains unaffected
        val check = db.inventoryDao().getInventoryByProductOrMaterialId("MAT-PAP-300")!!
        assertEquals(inv.availableStock, check.availableStock, 0.01)
    }

    // 16. Concurrent inventory issue
    @Test
    fun test16_concurrentInventoryIssue() = runBlocking {
        val inv = db.inventoryDao().getInventoryByProductOrMaterialId("MAT-PAP-300")!!

        // Fire 5 concurrent requests
        val jobs = (1..5).map {
            async {
                repo.issueMaterial("JOB-CONC-$it", inv.inventoryId, 20.0, printManager)
            }
        }
        val results = jobs.awaitAll()
        assertTrue(results.all { it.isSuccess })

        val after = db.inventoryDao().getInventoryById(inv.inventoryId)!!
        assertEquals(inv.currentStock - 100.0, after.currentStock, 0.01)
    }

    // 17. Purchase request
    @Test
    fun test17_purchaseRequest() = runBlocking {
        val pr = EnterprisePurchaseRequestEntity(
            purchaseRequestId = "PR-TEST-01",
            divisionId = "PRINTING",
            materialOrProductId = "MAT-PAP-300",
            materialName = "300 GSM Art Card",
            quantity = 500.0,
            unit = "SHEET",
            status = "PENDING_APPROVAL",
            requestedBy = "Store Lead"
        )
        db.purchaseDao().insertPurchaseRequest(pr)
        val fetched = db.purchaseDao().getPurchaseRequestById("PR-TEST-01")
        assertNotNull(fetched)
        assertEquals("PENDING_APPROVAL", fetched?.status)
    }

    // 18. Goods receipt
    @Test
    fun test18_goodsReceipt() = runBlocking {
        val inv = db.inventoryDao().getInventoryByProductOrMaterialId("MAT-PAP-300")!!
        val po = EnterprisePurchaseOrderEntity(
            purchaseOrderId = "PO-TEST-01",
            poNumber = "SE-PO-2026-0001",
            divisionId = "PRINTING",
            supplierId = "SUP-1",
            supplierName = "Paper Mills Ltd",
            itemsJson = "items",
            quantity = 500.0,
            subtotal = 5000.0,
            tax = 900.0,
            total = 5900.0,
            status = "ORDERED",
            createdBy = "Purchase"
        )
        db.purchaseDao().insertPurchaseOrder(po)

        val grnRes = repo.receiveGoods(po.purchaseOrderId, inv.inventoryId, 500.0, ownerUser)
        assertTrue(grnRes.isSuccess)

        val after = db.inventoryDao().getInventoryById(inv.inventoryId)!!
        assertEquals(inv.currentStock + 500.0, after.currentStock, 0.01)
    }

    // 19. QC pass
    @Test
    fun test19_qcPass() = runBlocking {
        val cust = repo.getAllCustomers().first().first()
        val prod = repo.getProductsByDivision("PRINTING").first().first()
        val quote = repo.createPrintQuotation(cust.customerId, prod.productId, PrintSpecification(), 0.0, false, null, salesUser).getOrThrow()
        repo.approveQuotation(quote.quotationId, salesUser)
        val order = repo.convertQuotationToOrder(quote.quotationId, salesUser).getOrThrow()
        val art = repo.uploadArtwork(order.orderId, "art.pdf", "pdf", "uri", salesUser).getOrThrow()
        repo.approveArtwork(art.artworkId, salesUser)
        val job = repo.createProductionJob(order.orderId, printManager).getOrThrow()

        val checklist = mapOf("print_quality" to true, "colour" to true, "paper" to true)
        val qcRes = repo.recordQualityCheck(job.productionJobId, order.orderId, checklist, "All perfect", printManager)
        assertTrue(qcRes.isSuccess)
        assertEquals("PASSED", qcRes.getOrThrow().status)

        val updatedJob = db.productionDao().getProductionJobById(job.productionJobId)!!
        assertEquals("READY_FOR_PACKING", updatedJob.status)
    }

    // 20. QC failure
    @Test
    fun test20_qcFailure() = runBlocking {
        val cust = repo.getAllCustomers().first().first()
        val prod = repo.getProductsByDivision("PRINTING").first().first()
        val quote = repo.createPrintQuotation(cust.customerId, prod.productId, PrintSpecification(), 0.0, false, null, salesUser).getOrThrow()
        repo.approveQuotation(quote.quotationId, salesUser)
        val order = repo.convertQuotationToOrder(quote.quotationId, salesUser).getOrThrow()
        val art = repo.uploadArtwork(order.orderId, "art.pdf", "pdf", "uri", salesUser).getOrThrow()
        repo.approveArtwork(art.artworkId, salesUser)
        val job = repo.createProductionJob(order.orderId, printManager).getOrThrow()

        val checklist = mapOf("print_quality" to false, "colour" to true)
        val qcRes = repo.recordQualityCheck(job.productionJobId, order.orderId, checklist, "Smudged print on 50 sheets", printManager)
        assertTrue(qcRes.isSuccess)
        assertEquals("REWORK_REQUIRED", qcRes.getOrThrow().status)
    }

    // 21. Rework
    @Test
    fun test21_reworkTracking() = runBlocking {
        val reworks = db.qualityDao().getReworkHistory("JOB-NON-EXISTENT")
        assertNotNull(reworks)
    }

    // 22. Packing
    @Test
    fun test22_packingWorkflow() = runBlocking {
        val packRes = repo.packOrder("ORD-001", 500.0, 2, "Bubble wrapped", printManager)
        assertTrue(packRes.isSuccess)
        assertEquals("COMPLETED", packRes.getOrThrow().status)
        assertEquals(2, packRes.getOrThrow().packageCount)
    }

    // 23. Delivery
    @Test
    fun test23_delivery() = runBlocking {
        val cust = repo.getAllCustomers().first().first()
        val prod = repo.getProductsByDivision("PRINTING").first().first()
        val quote = repo.createPrintQuotation(cust.customerId, prod.productId, PrintSpecification(), 0.0, false, null, salesUser).getOrThrow()
        repo.approveQuotation(quote.quotationId, salesUser)
        val order = repo.convertQuotationToOrder(quote.quotationId, salesUser).getOrThrow()

        val delRes = repo.createDelivery(order.orderId, "COMPANY_DELIVERY", "Rider 1", "OD-02-1234", ownerUser)
        assertTrue(delRes.isSuccess)
        val del = delRes.getOrThrow()
        assertEquals("SCHEDULED", del.status)

        val deliveredRes = repo.markDelivered(del.deliveryId, "POD-SIGN-9988", ownerUser)
        assertTrue(deliveredRes.isSuccess)
        assertEquals("DELIVERED", deliveredRes.getOrThrow().status)
    }

    // 24. Invoice
    @Test
    fun test24_invoice() = runBlocking {
        val cust = repo.getAllCustomers().first().first()
        val prod = repo.getProductsByDivision("PRINTING").first().first()
        val quote = repo.createPrintQuotation(cust.customerId, prod.productId, PrintSpecification(), 0.0, false, null, salesUser).getOrThrow()
        repo.approveQuotation(quote.quotationId, salesUser)
        val order = repo.convertQuotationToOrder(quote.quotationId, salesUser).getOrThrow()

        val invRes = repo.createInvoiceForOrder(order.orderId, ownerUser)
        assertTrue(invRes.isSuccess)
        val inv = invRes.getOrThrow()
        assertTrue(inv.invoiceNumber.startsWith("SE-PRINT-INV-2026-"))
        assertEquals(inv.grandTotal, inv.balanceDue, 0.01)
        assertEquals("UNPAID", inv.status)
    }

    // 25. Payment
    @Test
    fun test25_payment() = runBlocking {
        val cust = repo.getAllCustomers().first().first()
        val prod = repo.getProductsByDivision("PRINTING").first().first()
        val quote = repo.createPrintQuotation(cust.customerId, prod.productId, PrintSpecification(), 0.0, false, null, salesUser).getOrThrow()
        repo.approveQuotation(quote.quotationId, salesUser)
        val order = repo.convertQuotationToOrder(quote.quotationId, salesUser).getOrThrow()
        val inv = repo.createInvoiceForOrder(order.orderId, ownerUser).getOrThrow()

        val payRes = repo.recordPayment(inv.invoiceId, inv.grandTotal / 2.0, "UPI", "UPI-12345", null, ownerUser)
        assertTrue(payRes.isSuccess)

        val updatedInv = db.invoicePaymentDao().getInvoiceById(inv.invoiceId)!!
        assertEquals("PARTIALLY_PAID", updatedInv.status)
        assertEquals(inv.grandTotal / 2.0, updatedInv.balanceDue, 0.01)
    }

    // 26. Payment overage prevention
    @Test
    fun test26_paymentOveragePrevention() = runBlocking {
        val cust = repo.getAllCustomers().first().first()
        val prod = repo.getProductsByDivision("PRINTING").first().first()
        val quote = repo.createPrintQuotation(cust.customerId, prod.productId, PrintSpecification(), 0.0, false, null, salesUser).getOrThrow()
        repo.approveQuotation(quote.quotationId, salesUser)
        val order = repo.convertQuotationToOrder(quote.quotationId, salesUser).getOrThrow()
        val inv = repo.createInvoiceForOrder(order.orderId, ownerUser).getOrThrow()

        // Attempting to pay balance + ₹100 must be rejected
        val excessPay = repo.recordPayment(inv.invoiceId, inv.balanceDue + 100.0, "CASH", null, null, ownerUser)
        assertTrue(excessPay.isFailure)
        assertTrue(excessPay.exceptionOrNull()?.message?.contains("Overpayment", ignoreCase = true) == true)
    }

    // 27. Customer history
    @Test
    fun test27_customerHistory() = runBlocking {
        val cust = repo.getAllCustomers().first().first()
        val history = repo.getCustomerHistory(cust.customerId)
        assertNotNull(history.customer)
        assertTrue(history.totalOutstanding >= 0.0)
    }

    // 28. RBAC
    @Test
    fun test28_rbacRules() {
        assertTrue(RBACManager.hasPermission(ownerUser, "enterprise:write"))
        assertTrue(RBACManager.hasPermission(salesUser, "quotation:create"))
        assertFalse(RBACManager.hasPermission(salesUser, "qc:record"))
        assertTrue(RBACManager.hasPermission(printManager, "qc:record"))
        assertFalse(RBACManager.hasPermission(tradingStore, "quotation:create"))
    }

    // 29. Division isolation
    @Test
    fun test29_divisionIsolationPermissions() {
        assertTrue(RBACManager.canAccessDivision(ownerUser, "PRINTING"))
        assertTrue(RBACManager.canAccessDivision(ownerUser, "TRADING"))
        assertTrue(RBACManager.canAccessDivision(printManager, "PRINTING"))
        assertFalse(RBACManager.canAccessDivision(printManager, "TRADING"))
        assertTrue(RBACManager.canAccessDivision(tradingStore, "TRADING"))
        assertFalse(RBACManager.canAccessDivision(tradingStore, "PRINTING"))
    }

    // 30. AI tool permission
    @Test
    fun test30_aiToolPermission() = runBlocking {
        // Sales user has quotation permission
        val res = aiRegistry.executeTool("calculate_print_quote", mapOf("quantity" to 500), salesUser)
        assertTrue(res.success)

        // Read-only user lacking permission
        val readOnlyUser = UserSession("U-RO", "Auditor", "ro@sampurna.in", UserRole.READ_ONLY, BusinessTenant.SAMPURNA_ENTERPRISE, DivisionTenant.BOTH)
        val blockedRes = aiRegistry.executeTool("create_quotation", emptyMap(), readOnlyUser)
        assertFalse(blockedRes.success)
        assertTrue(blockedRes.answer.contains("Permission denied"))
    }

    // 31. Audit logging
    @Test
    fun test31_auditLogging() = runBlocking {
        val initialLogs = db.approvalAuditDao().getAllAuditLogs().first().size
        repo.createCustomer("Audit Corp", "9876543299", "audit@corp.com", null, null, null, null, null, null, "BUSINESS", null, ownerUser)
        val afterLogs = db.approvalAuditDao().getAllAuditLogs().first().size
        assertTrue(afterLogs > initialLogs)
    }

    // 32. Truth-standard enforcement
    @Test
    fun test32_truthStandardEnforcement() = runBlocking {
        val nonExistentSearch = aiRegistry.executeTool("check_material_availability", mapOf("materialQuery" to "Unobtainium 9000", "quantity" to 10.0), ownerUser)
        assertFalse(nonExistentSearch.success)
        assertTrue(nonExistentSearch.answer.contains("No verified data available"))
    }

    // 33. Historical rate preservation
    @Test
    fun test33_historicalRatePreservation() = runBlocking {
        val cust = repo.getAllCustomers().first().first()
        val prod = repo.getProductsByDivision("PRINTING").first().first()
        val rateCard = repo.getRateCardForProduct(prod.productId) ?: repo.createOrUpdateRateCard(
            EnterpriseRateCardEntity(
                rateCardId = "RC-" + prod.productId,
                divisionId = prod.divisionId,
                productId = prod.productId,
                baseRatePerUnit = prod.sellingPrice,
                createdBy = "Admin"
            ),
            ownerUser
        )

        val originalQuote = repo.createPrintQuotation(cust.customerId, prod.productId, PrintSpecification(), 0.0, false, null, salesUser).getOrThrow()
        val originalTotal = originalQuote.grandTotal

        // Now modify the rate card to a higher rate
        repo.createOrUpdateRateCard(rateCard.copy(baseRatePerUnit = rateCard.baseRatePerUnit * 2.0), ownerUser, "Inflation update")

        // The existing quotation must retain its original total!
        val reloadedQuote = db.quotationDao().getQuotationById(originalQuote.quotationId)!!
        assertEquals(originalTotal, reloadedQuote.grandTotal, 0.001)
    }

    // 34. Approval bypass prevention
    @Test
    fun test34_approvalBypassPrevention() = runBlocking {
        val cust = repo.getAllCustomers().first().first()
        val prod = repo.getProductsByDivision("PRINTING").first().first()

        // 25% discount created by Sales User (> 10% threshold)
        val quote = repo.createPrintQuotation(cust.customerId, prod.productId, PrintSpecification(), 25.0, false, null, salesUser).getOrThrow()
        assertEquals("PENDING_APPROVAL", quote.status)
        assertNotNull(quote.approvalRequestId)

        // Sales user cannot approve their own high discount
        val bypassAttempt = repo.approveQuotation(quote.quotationId, salesUser)
        assertTrue(bypassAttempt.isFailure)

        // Owner/Manager can approve
        val ownerApprove = repo.approveQuotation(quote.quotationId, ownerUser)
        assertTrue(ownerApprove.isSuccess)
        assertEquals("CUSTOMER_APPROVED", ownerApprove.getOrThrow().status)
    }

    // 35. Cross-business isolation & Baseline verification
    @Test
    fun test35_crossBusinessIsolation() = runBlocking {
        // AI Router distinguishes B.B. Motors, Renaissance Hotels, Sampurna Printing, Sampurna Trading
        val bbRoute = AiRouter.routeQuery("Create a job card for my Honda.")
        assertEquals(RoutingTarget.BB_MOTORS, bbRoute.target)

        val rhRoute = AiRouter.routeQuery("How many rooms are available in Puri?")
        assertEquals(RoutingTarget.RENAISSANCE_HOTELS, rhRoute.target)

        val printRoute = AiRouter.routeQuery("Make a quotation for 500 visiting cards.")
        assertEquals(RoutingTarget.SAMPURNA_ENTERPRISE_PRINTING, printRoute.target)

        val tradeRoute = AiRouter.routeQuery("Do we have 20 bags of cement?")
        assertEquals(RoutingTarget.SAMPURNA_ENTERPRISE_TRADING, tradeRoute.target)

        // Phase 2A Baseline: B.B. Motors verification
        val bbJobCard = repo.createBBMotorJobCard("OD-02-X-9999", "CUST-BB-1", 4500.0)
        assertNotNull(bbJobCard.jobCardId)
        assertTrue(repo.getBBJobCardsCount() > 0)

        // Phase 2B Baseline: Renaissance Hotels verification
        val rhRes = repo.createRenaissanceReservation("Puri", "Deluxe Sea Facing", "CUST-RH-1", 12500.0)
        assertNotNull(rhRes.reservationId)
        val reservations = repo.getRenaissanceReservations("Puri")
        assertTrue(reservations.isNotEmpty())
    }
}
