package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.*
import com.example.data.model.*

@Database(
    entities = [
        CustomerEntity::class,
        SupplierEntity::class,
        ApprovalRequestEntity::class,
        AuditLogEntity::class,
        EnterpriseDivisionEntity::class,
        EnterpriseCategoryEntity::class,
        EnterpriseProductEntity::class,
        EnterpriseRateCardEntity::class,
        EnterpriseRateVersionEntity::class,
        EnterpriseQuotationEntity::class,
        EnterpriseQuotationItemEntity::class,
        EnterpriseOrderEntity::class,
        EnterpriseOrderItemEntity::class,
        EnterpriseArtworkEntity::class,
        EnterpriseProductionJobEntity::class,
        EnterpriseMaterialRequirementEntity::class,
        EnterpriseInventoryEntity::class,
        EnterpriseInventoryTransactionEntity::class,
        EnterprisePurchaseRequestEntity::class,
        EnterprisePurchaseOrderEntity::class,
        EnterpriseGoodsReceiptEntity::class,
        EnterpriseQualityCheckEntity::class,
        EnterpriseReworkEntity::class,
        EnterprisePackingEntity::class,
        EnterpriseDeliveryEntity::class,
        InvoiceEntity::class,
        PaymentEntity::class,
        BBMotorJobCardEntity::class,
        RenaissanceReservationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SampurnaDatabase : RoomDatabase() {
    abstract fun customerDao(): CustomerDao
    abstract fun supplierDao(): SupplierDao
    abstract fun catalogDao(): EnterpriseCatalogDao
    abstract fun rateCardDao(): EnterpriseRateCardDao
    abstract fun quotationDao(): EnterpriseQuotationDao
    abstract fun orderDao(): EnterpriseOrderDao
    abstract fun artworkDao(): EnterpriseArtworkDao
    abstract fun productionDao(): EnterpriseProductionDao
    abstract fun inventoryDao(): EnterpriseInventoryDao
    abstract fun purchaseDao(): EnterprisePurchaseDao
    abstract fun qualityDao(): EnterpriseQualityDao
    abstract fun deliveryDao(): EnterpriseDeliveryDao
    abstract fun invoicePaymentDao(): InvoicePaymentDao
    abstract fun approvalAuditDao(): ApprovalAuditDao
    abstract fun baselineDao(): BaselineDao

    companion object {
        @Volatile
        private var INSTANCE: SampurnaDatabase? = null

        fun getDatabase(context: Context): SampurnaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SampurnaDatabase::class.java,
                    "sampurna_enterprise_database"
                )
                    .fallbackToDestructiveMigration(true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
