package com.example.data.repository

import com.example.core.approval.ApprovalEngine
import com.example.core.approval.ApprovalStatus
import com.example.core.approval.ApprovalType
import com.example.core.audit.AuditAction
import com.example.core.auth.UserRole
import com.example.core.auth.UserSession
import com.example.core.financial.DeterministicFinancialEngine
import com.example.core.financial.PrintSpecification
import com.example.core.financial.TaxBreakdown
import com.example.data.db.SampurnaDatabase
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID

class SampurnaRepository(private val db: SampurnaDatabase) {

    // Mutex for transaction-safe, serialized inventory operations to prevent negative stock
    private val inventoryMutex = Mutex()

    // -------------------------------------------------------------
    // Customers (Phase 1 Shared)
    // -------------------------------------------------------------
    fun getAllCustomers(): Flow<List<CustomerEntity>> = db.customerDao().getAllCustomers()

    suspend fun getCustomerById(id: String): CustomerEntity? = db.customerDao().getCustomerById(id)

    suspend fun searchCustomers(query: String): List<CustomerEntity> = db.customerDao().searchCustomers(query)

    suspend fun createCustomer(
        name: String,
        phone: String,
        email: String? = null,
        alternatePhone: String? = null,
        address: String? = null,
        city: String? = null,
        state: String? = null,
        pincode: String? = null,
        gstin: String? = null,
        customerType: String = "INDIVIDUAL",
        notes: String? = null,
        actor: UserSession
    ): Result<CustomerEntity> {
        // Prevent accidental duplicates via normalized phone / email
        val existingPhone = db.customerDao().findCustomerByPhone(phone.trim())
        if (existingPhone != null) {
            return Result.failure(IllegalArgumentException("Customer with phone $phone already exists: ${existingPhone.name}"))
        }
        if (!email.isNullOrBlank()) {
            val existingEmail = db.customerDao().findCustomerByEmail(email.trim().lowercase())
            if (existingEmail != null) {
                return Result.failure(IllegalArgumentException("Customer with email $email already exists: ${existingEmail.name}"))
            }
        }

        val customer = CustomerEntity(
            customerId = "CUST-" + UUID.randomUUID().toString().take(8).uppercase(),
            name = name.trim(),
            phone = phone.trim(),
            alternatePhone = alternatePhone?.trim(),
            email = email?.trim()?.lowercase(),
            address = address?.trim(),
            city = city?.trim(),
            state = state?.trim(),
            pincode = pincode?.trim(),
            gstinOptional = gstin?.trim(),
            customerType = customerType,
            notes = notes
        )
        db.customerDao().insertCustomer(customer)

        recordAudit(
            actor = actor,
            division = null,
            entity = "CUSTOMER",
            entityId = customer.customerId,
            action = AuditAction.CREATE_CUSTOMER,
            details = "Created customer ${customer.name} (${customer.phone})",
            result = "SUCCESS"
        )

        return Result.success(customer)
    }

    // -------------------------------------------------------------
    // Products & Categories (Division Isolated)
    // -------------------------------------------------------------
    fun getAllProducts(): Flow<List<EnterpriseProductEntity>> = db.catalogDao().getAllProducts()

    fun getProductsByDivision(divisionId: String): Flow<List<EnterpriseProductEntity>> =
        db.catalogDao().getProductsByDivision(divisionId)

    suspend fun getProductById(id: String): EnterpriseProductEntity? = db.catalogDao().getProductById(id)

    suspend fun createProduct(
        divisionId: String,
        categoryId: String,
        productCode: String,
        name: String,
        description: String? = null,
        unit: String,
        purchasePrice: Double,
        sellingPrice: Double,
        gstRate: Double,
        minimumStock: Double = 0.0,
        reorderQuantity: Double = 0.0,
        actor: UserSession
    ): Result<EnterpriseProductEntity> {
        val existing = db.catalogDao().getProductByCode(productCode.trim().uppercase())
        if (existing != null) {
            return Result.failure(IllegalArgumentException("Product code $productCode already exists"))
        }

        val product = EnterpriseProductEntity(
            productId = "PROD-" + UUID.randomUUID().toString().take(8).uppercase(),
            divisionId = divisionId.uppercase(),
            categoryId = categoryId,
            productCode = productCode.trim().uppercase(),
            name = name.trim(),
            description = description?.trim(),
            unit = unit.trim().uppercase(),
            purchasePrice = maxOf(0.0, purchasePrice),
            sellingPrice = maxOf(0.0, sellingPrice),
            gstRate = gstRate,
            minimumStock = maxOf(0.0, minimumStock),
            reorderQuantity = maxOf(0.0, reorderQuantity)
        )
        db.catalogDao().insertProduct(product)

        recordAudit(
            actor = actor,
            division = divisionId,
            entity = "PRODUCT",
            entityId = product.productId,
            action = AuditAction.CREATE_PRODUCT,
            details = "Created product ${product.name} under $divisionId",
            result = "SUCCESS"
        )
        return Result.success(product)
    }

    // -------------------------------------------------------------
    // Rate Cards & Versioning (Historical Immutability)
    // -------------------------------------------------------------
    suspend fun getRateCardForProduct(productId: String): EnterpriseRateCardEntity? =
        db.rateCardDao().getActiveRateCardForProduct(productId)

    suspend fun createOrUpdateRateCard(
        rateCard: EnterpriseRateCardEntity,
        actor: UserSession,
        changeReason: String = "Standard rate revision"
    ): EnterpriseRateCardEntity {
        val existing = db.rateCardDao().getRateCardById(rateCard.rateCardId)
        val newVersionNumber = if (existing != null) existing.version + 1 else 1

        val updated = rateCard.copy(
            version = newVersionNumber,
            effectiveFrom = System.currentTimeMillis()
        )
        db.rateCardDao().insertRateCard(updated)

        // Store immutable rate version record
        val versionRecord = EnterpriseRateVersionEntity(
            versionId = "RVER-" + UUID.randomUUID().toString().take(8).uppercase(),
            rateCardId = updated.rateCardId,
            versionNumber = newVersionNumber,
            rateDataJson = "baseRate=${updated.baseRatePerUnit},setup=${updated.setupCharge},finish=${updated.finishingRate},urgent=${updated.urgentSurchargeRate}",
            changedBy = actor.userId,
            changeReason = changeReason
        )
        db.rateCardDao().insertRateVersion(versionRecord)

        recordAudit(
            actor = actor,
            division = rateCard.divisionId,
            entity = "RATE_CARD",
            entityId = rateCard.rateCardId,
            action = AuditAction.RATE_CHANGE,
            details = "Rate updated to version $newVersionNumber. Reason: $changeReason",
            result = "SUCCESS"
        )
        return updated
    }

    // -------------------------------------------------------------
    // Quotation Engine
    // -------------------------------------------------------------
    fun getAllQuotations(): Flow<List<EnterpriseQuotationEntity>> = db.quotationDao().getAllQuotations()

    fun getQuotationsByDivision(divisionId: String): Flow<List<EnterpriseQuotationEntity>> =
        db.quotationDao().getQuotationsByDivision(divisionId)

    suspend fun getQuotationById(id: String): EnterpriseQuotationEntity? = db.quotationDao().getQuotationById(id)

    suspend fun getQuotationItems(quotationId: String): List<EnterpriseQuotationItemEntity> =
        db.quotationDao().getQuotationItems(quotationId)

    suspend fun createPrintQuotation(
        customerId: String,
        productId: String,
        spec: PrintSpecification,
        discountPercent: Double = 0.0,
        isInterState: Boolean = false,
        notes: String? = null,
        actor: UserSession
    ): Result<EnterpriseQuotationEntity> {
        val customer = db.customerDao().getCustomerById(customerId)
            ?: return Result.failure(IllegalArgumentException("Customer not found"))

        val product = db.catalogDao().getProductById(productId)
            ?: return Result.failure(IllegalArgumentException("Product not found"))

        if (product.divisionId != "PRINTING") {
            return Result.failure(IllegalArgumentException("Product ${product.name} is not in PRINTING division"))
        }

        val rateCard = db.rateCardDao().getActiveRateCardForProduct(productId)
        val baseRate = rateCard?.baseRatePerUnit ?: product.sellingPrice
        if (baseRate <= 0.0) {
            return Result.failure(IllegalStateException("No verified rate card is configured for this product/specification"))
        }

        val calculatedSubtotal = DeterministicFinancialEngine.calculatePrintItemCost(
            spec = spec,
            baseRatePerUnit = baseRate,
            setupCharge = rateCard?.setupCharge ?: 0.0,
            laminationUnitRate = rateCard?.finishingRate ?: 0.0,
            bindingUnitRate = rateCard?.bindingRate ?: 0.0,
            urgentSurchargePercent = rateCard?.urgentSurchargeRate ?: 25.0
        )

        val taxCalc = DeterministicFinancialEngine.calculateTax(
            subtotal = calculatedSubtotal,
            discountPercent = discountPercent,
            gstRate = product.gstRate,
            isInterState = isInterState
        )

        val quoteNum = "SE-PRINT-QTN-2026-" + String.format("%06d", (System.currentTimeMillis() % 1000000).toInt())
        val quoteId = "QTN-" + UUID.randomUUID().toString().take(8).uppercase()

        // Check if discount triggers approval requirement
        val approvalDecision = ApprovalEngine.checkDiscountApproval(discountPercent, actor)
        var approvalRequestId: String? = null
        val quoteStatus = if (approvalDecision.requiresApproval) {
            approvalRequestId = "APPR-" + UUID.randomUUID().toString().take(8).uppercase()
            db.approvalAuditDao().insertApproval(
                ApprovalRequestEntity(
                    requestId = approvalRequestId,
                    businessId = "SAMPURNA_ENTERPRISE",
                    divisionId = "PRINTING",
                    requestType = "LARGE_DISCOUNT",
                    entityType = "QUOTATION",
                    entityId = quoteId,
                    requestedBy = actor.name,
                    amount = taxCalc.discountAmount,
                    threshold = 10.0,
                    details = approvalDecision.reason,
                    status = "PENDING"
                )
            )
            "PENDING_APPROVAL"
        } else {
            "DRAFT"
        }

        val quotation = EnterpriseQuotationEntity(
            quotationId = quoteId,
            quotationNumber = quoteNum,
            customerId = customer.customerId,
            divisionId = "PRINTING",
            rateCardVersionApplied = rateCard?.version ?: 1,
            validUntil = System.currentTimeMillis() + (14L * 24 * 3600 * 1000), // 14 days
            subtotal = taxCalc.subtotal,
            discount = taxCalc.discountAmount,
            taxableValue = taxCalc.taxableValue,
            cgst = taxCalc.cgst,
            sgst = taxCalc.sgst,
            igst = taxCalc.igst,
            tax = taxCalc.totalTax,
            grandTotal = taxCalc.grandTotal,
            terms = "1. Quotation valid for 14 days.\n2. Artwork approval mandatory before production.\n3. 50% advance with order.",
            notes = notes,
            status = quoteStatus,
            approvalRequestId = approvalRequestId,
            createdBy = actor.name
        )
        db.quotationDao().insertQuotation(quotation)

        val quoteItem = EnterpriseQuotationItemEntity(
            quotationItemId = "QITEM-" + UUID.randomUUID().toString().take(8).uppercase(),
            quotationId = quoteId,
            productId = product.productId,
            productName = product.name,
            description = "Print job: ${spec.quantity} ${product.unit} on ${spec.paperType} ${spec.gsm} GSM",
            specificationJson = "qty=${spec.quantity},paper=${spec.paperType},gsm=${spec.gsm},sides=${spec.sideCount},lam=${spec.lamination},bind=${spec.binding},urgent=${spec.isUrgent}",
            quantity = spec.quantity.toDouble(),
            unit = product.unit,
            unitPrice = DeterministicFinancialEngine.round2(calculatedSubtotal / spec.quantity),
            discount = taxCalc.discountAmount,
            taxRate = product.gstRate,
            taxableValue = taxCalc.taxableValue,
            cgst = taxCalc.cgst,
            sgst = taxCalc.sgst,
            igst = taxCalc.igst,
            tax = taxCalc.totalTax,
            lineTotal = taxCalc.grandTotal
        )
        db.quotationDao().insertQuotationItems(listOf(quoteItem))

        recordAudit(
            actor = actor,
            division = "PRINTING",
            entity = "QUOTATION",
            entityId = quotation.quotationId,
            action = AuditAction.CREATE_QUOTATION,
            details = "Created print quote ${quotation.quotationNumber} for ${customer.name}, total ₹${quotation.grandTotal}",
            result = "SUCCESS"
        )

        return Result.success(quotation)
    }

    suspend fun createTradingQuotation(
        customerId: String,
        items: List<Pair<EnterpriseProductEntity, Double>>, // Product and Quantity
        discountPercent: Double = 0.0,
        isInterState: Boolean = false,
        notes: String? = null,
        actor: UserSession
    ): Result<EnterpriseQuotationEntity> {
        val customer = db.customerDao().getCustomerById(customerId)
            ?: return Result.failure(IllegalArgumentException("Customer not found"))

        if (items.isEmpty()) {
            return Result.failure(IllegalArgumentException("Quotation items cannot be empty"))
        }

        var totalSubtotal = 0.0
        val lineItems = mutableListOf<EnterpriseQuotationItemEntity>()
        val quoteNum = "SE-TRD-QTN-2026-" + String.format("%06d", (System.currentTimeMillis() % 1000000).toInt())
        val quoteId = "QTN-" + UUID.randomUUID().toString().take(8).uppercase()

        for ((product, qty) in items) {
            if (product.divisionId != "TRADING") {
                return Result.failure(IllegalArgumentException("Product ${product.name} is not in TRADING division"))
            }
            val lineSubtotal = DeterministicFinancialEngine.round2(product.sellingPrice * qty)
            totalSubtotal += lineSubtotal

            val taxCalc = DeterministicFinancialEngine.calculateTax(
                subtotal = lineSubtotal,
                discountPercent = discountPercent,
                gstRate = product.gstRate,
                isInterState = isInterState
            )

            lineItems.add(
                EnterpriseQuotationItemEntity(
                    quotationItemId = "QITEM-" + UUID.randomUUID().toString().take(8).uppercase(),
                    quotationId = quoteId,
                    productId = product.productId,
                    productName = product.name,
                    description = "${product.name} (${product.unit})",
                    specificationJson = "unit=${product.unit}",
                    quantity = qty,
                    unit = product.unit,
                    unitPrice = product.sellingPrice,
                    discount = taxCalc.discountAmount,
                    taxRate = product.gstRate,
                    taxableValue = taxCalc.taxableValue,
                    cgst = taxCalc.cgst,
                    sgst = taxCalc.sgst,
                    igst = taxCalc.igst,
                    tax = taxCalc.totalTax,
                    lineTotal = taxCalc.grandTotal
                )
            )
        }

        val totalTaxCalc = DeterministicFinancialEngine.calculateTax(
            subtotal = totalSubtotal,
            discountPercent = discountPercent,
            gstRate = items.first().first.gstRate,
            isInterState = isInterState
        )

        val approvalDecision = ApprovalEngine.checkDiscountApproval(discountPercent, actor)
        var approvalRequestId: String? = null
        val quoteStatus = if (approvalDecision.requiresApproval) {
            approvalRequestId = "APPR-" + UUID.randomUUID().toString().take(8).uppercase()
            db.approvalAuditDao().insertApproval(
                ApprovalRequestEntity(
                    requestId = approvalRequestId,
                    businessId = "SAMPURNA_ENTERPRISE",
                    divisionId = "TRADING",
                    requestType = "LARGE_DISCOUNT",
                    entityType = "QUOTATION",
                    entityId = quoteId,
                    requestedBy = actor.name,
                    amount = totalTaxCalc.discountAmount,
                    threshold = 10.0,
                    details = approvalDecision.reason,
                    status = "PENDING"
                )
            )
            "PENDING_APPROVAL"
        } else {
            "DRAFT"
        }

        val quotation = EnterpriseQuotationEntity(
            quotationId = quoteId,
            quotationNumber = quoteNum,
            customerId = customer.customerId,
            divisionId = "TRADING",
            validUntil = System.currentTimeMillis() + (7L * 24 * 3600 * 1000), // 7 days for commodities
            subtotal = totalTaxCalc.subtotal,
            discount = totalTaxCalc.discountAmount,
            taxableValue = totalTaxCalc.taxableValue,
            cgst = totalTaxCalc.cgst,
            sgst = totalTaxCalc.sgst,
            igst = totalTaxCalc.igst,
            tax = totalTaxCalc.totalTax,
            grandTotal = totalTaxCalc.grandTotal,
            terms = "1. Price subject to market fluctuations.\n2. Delivery within 48 hours of confirmation.\n3. Immediate payment on dispatch.",
            notes = notes,
            status = quoteStatus,
            approvalRequestId = approvalRequestId,
            createdBy = actor.name
        )
        db.quotationDao().insertQuotation(quotation)
        db.quotationDao().insertQuotationItems(lineItems)

        recordAudit(
            actor = actor,
            division = "TRADING",
            entity = "QUOTATION",
            entityId = quotation.quotationId,
            action = AuditAction.CREATE_QUOTATION,
            details = "Created trading quote ${quotation.quotationNumber} for ${customer.name}, total ₹${quotation.grandTotal}",
            result = "SUCCESS"
        )

        return Result.success(quotation)
    }

    suspend fun approveQuotation(quotationId: String, actor: UserSession): Result<EnterpriseQuotationEntity> {
        val quote = db.quotationDao().getQuotationById(quotationId)
            ?: return Result.failure(IllegalArgumentException("Quotation not found"))

        if (quote.status == "PENDING_APPROVAL") {
            if (!ApprovalEngine.canApprove(actor, ApprovalType.LARGE_DISCOUNT)) {
                return Result.failure(SecurityException("User ${actor.name} does not have manager authorization to approve quotation discount"))
            }
            // Approve pending approval request
            quote.approvalRequestId?.let { reqId ->
                val req = db.approvalAuditDao().getApprovalById(reqId)
                if (req != null) {
                    db.approvalAuditDao().updateApproval(
                        req.copy(status = "APPROVED", reviewedBy = actor.name, reviewedAt = System.currentTimeMillis())
                    )
                }
            }
        }

        val approved = quote.copy(
            status = "CUSTOMER_APPROVED",
            updatedAt = System.currentTimeMillis()
        )
        db.quotationDao().updateQuotation(approved)

        recordAudit(
            actor = actor,
            division = approved.divisionId,
            entity = "QUOTATION",
            entityId = approved.quotationId,
            action = AuditAction.APPROVE_QUOTATION,
            details = "Approved quotation ${approved.quotationNumber}",
            result = "SUCCESS"
        )

        return Result.success(approved)
    }

    // -------------------------------------------------------------
    // Order Workflow (Customer Approval -> Order Conversion)
    // -------------------------------------------------------------
    fun getAllOrders(): Flow<List<EnterpriseOrderEntity>> = db.orderDao().getAllOrders()

    fun getOrdersByDivision(divisionId: String): Flow<List<EnterpriseOrderEntity>> =
        db.orderDao().getOrdersByDivision(divisionId)

    suspend fun getOrderById(id: String): EnterpriseOrderEntity? = db.orderDao().getOrderById(id)

    suspend fun convertQuotationToOrder(quotationId: String, actor: UserSession): Result<EnterpriseOrderEntity> {
        val quote = db.quotationDao().getQuotationById(quotationId)
            ?: return Result.failure(IllegalArgumentException("Quotation not found"))

        if (quote.status != "CUSTOMER_APPROVED") {
            return Result.failure(IllegalStateException("Quotation must be CUSTOMER_APPROVED before converting to Order. Current status: ${quote.status}"))
        }

        val items = db.quotationDao().getQuotationItems(quotationId)
        val orderPrefix = if (quote.divisionId == "PRINTING") "SE-PRINT-ORD-2026-" else "SE-TRD-ORD-2026-"
        val orderNum = orderPrefix + String.format("%06d", (System.currentTimeMillis() % 1000000).toInt())
        val orderId = "ORD-" + UUID.randomUUID().toString().take(8).uppercase()

        // Printing begins at ARTWORK; Trading begins at ORDER_CONFIRMED
        val initialStatus = if (quote.divisionId == "PRINTING") "ARTWORK" else "ORDER_CONFIRMED"

        val order = EnterpriseOrderEntity(
            orderId = orderId,
            orderNumber = orderNum,
            customerId = quote.customerId,
            divisionId = quote.divisionId,
            quotationId = quote.quotationId,
            priority = "NORMAL",
            status = initialStatus,
            subtotal = quote.subtotal,
            discount = quote.discount,
            taxableValue = quote.taxableValue,
            tax = quote.tax,
            grandTotal = quote.grandTotal,
            notes = quote.notes,
            createdBy = actor.name
        )
        db.orderDao().insertOrder(order)

        val orderItems = items.map { qItem ->
            EnterpriseOrderItemEntity(
                orderItemId = "OITEM-" + UUID.randomUUID().toString().take(8).uppercase(),
                orderId = orderId,
                productId = qItem.productId,
                productName = qItem.productName,
                description = qItem.description,
                specificationJson = qItem.specificationJson,
                quantity = qItem.quantity,
                unit = qItem.unit,
                unitPrice = qItem.unitPrice,
                taxRate = qItem.taxRate,
                lineTotal = qItem.lineTotal
            )
        }
        db.orderDao().insertOrderItems(orderItems)

        // Mark quote converted
        db.quotationDao().updateQuotation(quote.copy(status = "CONVERTED", updatedAt = System.currentTimeMillis()))

        // If printing order, initialize Artwork record
        if (quote.divisionId == "PRINTING") {
            val artwork = EnterpriseArtworkEntity(
                artworkId = "ART-" + UUID.randomUUID().toString().take(8).uppercase(),
                orderId = orderId,
                fileName = "artwork_v1.pdf",
                fileType = "application/pdf",
                storageReference = "gdrive://sampurna-enterprise/artwork/$orderNum/artwork_v1.pdf",
                version = 1,
                uploadedBy = actor.name,
                status = "PENDING"
            )
            db.artworkDao().insertArtwork(artwork)
        }

        recordAudit(
            actor = actor,
            division = order.divisionId,
            entity = "ORDER",
            entityId = order.orderId,
            action = AuditAction.CREATE_ORDER,
            details = "Converted quote ${quote.quotationNumber} to order ${order.orderNumber}",
            result = "SUCCESS"
        )

        return Result.success(order)
    }

    // -------------------------------------------------------------
    // Artwork Management (Strictly Separated from Commercial Quote Approval)
    // -------------------------------------------------------------
    suspend fun getArtworkForOrder(orderId: String): EnterpriseArtworkEntity? =
        db.artworkDao().getLatestArtworkForOrder(orderId)

    suspend fun uploadArtwork(
        orderId: String,
        fileName: String,
        fileType: String,
        storageRef: String,
        actor: UserSession
    ): Result<EnterpriseArtworkEntity> {
        val existing = db.artworkDao().getLatestArtworkForOrder(orderId)
        val newVersion = (existing?.version ?: 0) + 1

        val artwork = EnterpriseArtworkEntity(
            artworkId = "ART-" + UUID.randomUUID().toString().take(8).uppercase(),
            orderId = orderId,
            fileName = fileName,
            fileType = fileType,
            storageReference = storageRef,
            version = newVersion,
            uploadedBy = actor.name,
            status = "CUSTOMER_REVIEW",
            notes = "Artwork version $newVersion submitted for review"
        )
        db.artworkDao().insertArtwork(artwork)

        recordAudit(
            actor = actor,
            division = "PRINTING",
            entity = "ARTWORK",
            entityId = artwork.artworkId,
            action = AuditAction.ARTWORK_UPLOADED,
            details = "Uploaded artwork version $newVersion for order $orderId",
            result = "SUCCESS"
        )
        return Result.success(artwork)
    }

    suspend fun approveArtwork(artworkId: String, actor: UserSession): Result<EnterpriseArtworkEntity> {
        val artwork = db.artworkDao().getArtworkById(artworkId)
            ?: return Result.failure(IllegalArgumentException("Artwork not found"))

        val approved = artwork.copy(
            status = "APPROVED",
            updatedAt = System.currentTimeMillis()
        )
        db.artworkDao().updateArtwork(approved)

        // Advance order status from ARTWORK to MATERIAL
        val order = db.orderDao().getOrderById(artwork.orderId)
        if (order != null && order.status == "ARTWORK") {
            db.orderDao().updateOrder(order.copy(status = "MATERIAL", updatedAt = System.currentTimeMillis()))
        }

        recordAudit(
            actor = actor,
            division = "PRINTING",
            entity = "ARTWORK",
            entityId = approved.artworkId,
            action = AuditAction.ARTWORK_APPROVED,
            details = "Customer approved artwork v${approved.version} for order ${artwork.orderId}",
            result = "SUCCESS"
        )
        return Result.success(approved)
    }

    // -------------------------------------------------------------
    // Production Jobs & Kanban (Printing Orders Only)
    // -------------------------------------------------------------
    fun getAllProductionJobs(): Flow<List<EnterpriseProductionJobEntity>> =
        db.productionDao().getAllProductionJobs()

    suspend fun getProductionJobById(id: String): EnterpriseProductionJobEntity? =
        db.productionDao().getProductionJobById(id)

    suspend fun createProductionJob(orderId: String, actor: UserSession): Result<EnterpriseProductionJobEntity> {
        val order = db.orderDao().getOrderById(orderId)
            ?: return Result.failure(IllegalArgumentException("Order not found"))

        if (order.divisionId != "PRINTING") {
            return Result.failure(IllegalArgumentException("Production jobs can only be created for PRINTING orders. Order ${order.orderNumber} is TRADING."))
        }

        // Production Gating: Artwork must be APPROVED before production can proceed
        val artwork = db.artworkDao().getLatestArtworkForOrder(orderId)
        if (artwork == null || artwork.status != "APPROVED") {
            return Result.failure(IllegalStateException("Production cannot start: Artwork approval is pending! Current artwork status: ${artwork?.status ?: "MISSING"}"))
        }

        val jobNum = "SE-PRD-2026-" + String.format("%06d", (System.currentTimeMillis() % 1000000).toInt())
        val jobId = "PJOB-" + UUID.randomUUID().toString().take(8).uppercase()

        val job = EnterpriseProductionJobEntity(
            productionJobId = jobId,
            jobNumber = jobNum,
            orderId = orderId,
            divisionId = "PRINTING",
            priority = order.priority,
            assignedTo = "Press Lead 1",
            plannedStart = System.currentTimeMillis(),
            plannedCompletion = System.currentTimeMillis() + (2L * 24 * 3600 * 1000),
            status = "MATERIAL_PENDING",
            notes = "Initiated for order ${order.orderNumber}"
        )
        db.productionDao().insertProductionJob(job)

        // Automatically create Material Requirement for job
        val materialReq = EnterpriseMaterialRequirementEntity(
            requirementId = "MREQ-" + UUID.randomUUID().toString().take(8).uppercase(),
            productionJobId = jobId,
            materialId = "MAT-PAP-300",
            materialName = "300 GSM Art Card Sheets",
            quantityRequired = 500.0,
            quantityReserved = 0.0,
            quantityIssued = 0.0,
            unit = "SHEET",
            status = "REQUIRED"
        )
        db.productionDao().insertMaterialRequirements(listOf(materialReq))

        recordAudit(
            actor = actor,
            division = "PRINTING",
            entity = "PRODUCTION_JOB",
            entityId = job.productionJobId,
            action = AuditAction.CREATE_PRODUCTION_JOB,
            details = "Created production job ${job.jobNumber} for order ${order.orderNumber}",
            result = "SUCCESS"
        )

        return Result.success(job)
    }

    suspend fun updateProductionStatus(
        jobId: String,
        newStatus: String,
        actor: UserSession
    ): Result<EnterpriseProductionJobEntity> {
        val job = db.productionDao().getProductionJobById(jobId)
            ?: return Result.failure(IllegalArgumentException("Production job not found"))

        val updated = job.copy(
            status = newStatus,
            actualStart = if (newStatus == "IN_PRODUCTION" && job.actualStart == null) System.currentTimeMillis() else job.actualStart,
            actualCompletion = if (newStatus == "COMPLETED") System.currentTimeMillis() else job.actualCompletion,
            updatedAt = System.currentTimeMillis()
        )
        db.productionDao().updateProductionJob(updated)

        // Sync order status
        val order = db.orderDao().getOrderById(job.orderId)
        if (order != null) {
            val orderStatus = when (newStatus) {
                "IN_PRODUCTION" -> "PRODUCTION"
                "QUALITY_CHECK" -> "QC"
                "PACKED" -> "PACKING"
                "READY_FOR_DELIVERY" -> "DELIVERY"
                "COMPLETED" -> "COMPLETED"
                else -> order.status
            }
            db.orderDao().updateOrder(order.copy(status = orderStatus, updatedAt = System.currentTimeMillis()))
        }

        recordAudit(
            actor = actor,
            division = "PRINTING",
            entity = "PRODUCTION_JOB",
            entityId = jobId,
            action = AuditAction.UPDATE_PRODUCTION_STATUS,
            details = "Updated job ${job.jobNumber} status to $newStatus",
            result = "SUCCESS"
        )

        return Result.success(updated)
    }

    // -------------------------------------------------------------
    // Inventory, Reservation & Negative Stock Prevention
    // -------------------------------------------------------------
    fun getAllInventory(): Flow<List<EnterpriseInventoryEntity>> = db.inventoryDao().getAllInventory()

    fun getInventoryByDivision(divisionId: String): Flow<List<EnterpriseInventoryEntity>> =
        db.inventoryDao().getInventoryByDivision(divisionId)

    fun getLowStockItems(): Flow<List<EnterpriseInventoryEntity>> = db.inventoryDao().getLowStockItems()

    suspend fun reserveMaterial(
        productionJobId: String,
        materialId: String,
        quantity: Double,
        actor: UserSession
    ): Result<Unit> = inventoryMutex.withLock {
        val inventory = db.inventoryDao().getInventoryByProductOrMaterialId(materialId)
            ?: return@withLock Result.failure(IllegalArgumentException("Inventory item for material $materialId not found"))

        if (inventory.availableStock < quantity) {
            // Material Shortage! Create Purchase Request automatically
            val pr = EnterprisePurchaseRequestEntity(
                purchaseRequestId = "PR-" + UUID.randomUUID().toString().take(8).uppercase(),
                divisionId = inventory.divisionId,
                materialOrProductId = materialId,
                materialName = inventory.name,
                quantity = quantity - inventory.availableStock,
                unit = inventory.unit,
                productionJobId = productionJobId,
                priority = "HIGH",
                status = "PENDING_APPROVAL",
                requestedBy = actor.name,
                notes = "Auto-generated for shortage in job $productionJobId"
            )
            db.purchaseDao().insertPurchaseRequest(pr)

            return@withLock Result.failure(
                IllegalStateException("Material shortage for ${inventory.name}: Available ${inventory.availableStock} < Required $quantity. Purchase request ${pr.purchaseRequestId} raised.")
            )
        }

        // Reserve stock
        val newReserved = inventory.reservedStock + quantity
        val newAvailable = inventory.currentStock - newReserved

        // Integrity check: Negative stock prevention
        if (newAvailable < 0.0 || newReserved > inventory.currentStock) {
            return@withLock Result.failure(IllegalStateException("Invalid reservation: would result in negative available stock"))
        }

        val updated = inventory.copy(
            reservedStock = newReserved,
            availableStock = newAvailable,
            updatedAt = System.currentTimeMillis()
        )
        db.inventoryDao().updateInventoryItem(updated)

        db.inventoryDao().insertTransaction(
            EnterpriseInventoryTransactionEntity(
                transactionId = "TXN-" + UUID.randomUUID().toString().take(8).uppercase(),
                inventoryId = inventory.inventoryId,
                divisionId = inventory.divisionId,
                transactionType = "RESERVATION",
                quantity = quantity,
                stockBefore = inventory.availableStock,
                stockAfter = newAvailable,
                referenceType = "PRODUCTION_JOB",
                referenceId = productionJobId,
                notes = "Reserved for job $productionJobId",
                performedBy = actor.name
            )
        )

        // Advance job to READY_FOR_PRODUCTION
        val job = db.productionDao().getProductionJobById(productionJobId)
        if (job != null && job.status == "MATERIAL_PENDING") {
            db.productionDao().updateProductionJob(job.copy(status = "READY_FOR_PRODUCTION", updatedAt = System.currentTimeMillis()))
        }

        recordAudit(
            actor = actor,
            division = inventory.divisionId,
            entity = "INVENTORY",
            entityId = inventory.inventoryId,
            action = AuditAction.RESERVE_MATERIAL,
            details = "Reserved $quantity ${inventory.unit} of ${inventory.name} for job $productionJobId",
            result = "SUCCESS"
        )

        return@withLock Result.success(Unit)
    }

    suspend fun issueMaterial(
        productionJobId: String,
        inventoryId: String,
        quantity: Double,
        actor: UserSession
    ): Result<Unit> = inventoryMutex.withLock {
        val inventory = db.inventoryDao().getInventoryById(inventoryId)
            ?: return@withLock Result.failure(IllegalArgumentException("Inventory item not found"))

        // Integrity check: Cannot issue more than reserved or current
        if (quantity > inventory.currentStock) {
            return@withLock Result.failure(IllegalStateException("Cannot issue $quantity: exceeds total current stock ${inventory.currentStock}"))
        }

        val newCurrent = inventory.currentStock - quantity
        val newReserved = maxOf(0.0, inventory.reservedStock - quantity)
        val newAvailable = newCurrent - newReserved

        val updated = inventory.copy(
            currentStock = newCurrent,
            reservedStock = newReserved,
            availableStock = newAvailable,
            updatedAt = System.currentTimeMillis()
        )
        db.inventoryDao().updateInventoryItem(updated)

        db.inventoryDao().insertTransaction(
            EnterpriseInventoryTransactionEntity(
                transactionId = "TXN-" + UUID.randomUUID().toString().take(8).uppercase(),
                inventoryId = inventory.inventoryId,
                divisionId = inventory.divisionId,
                transactionType = "ISSUE",
                quantity = quantity,
                stockBefore = inventory.currentStock,
                stockAfter = newCurrent,
                referenceType = "PRODUCTION_JOB",
                referenceId = productionJobId,
                notes = "Issued to production floor for job $productionJobId",
                performedBy = actor.name
            )
        )

        recordAudit(
            actor = actor,
            division = inventory.divisionId,
            entity = "INVENTORY",
            entityId = inventory.inventoryId,
            action = AuditAction.ISSUE_MATERIAL,
            details = "Issued $quantity ${inventory.unit} of ${inventory.name} for job $productionJobId",
            result = "SUCCESS"
        )

        return@withLock Result.success(Unit)
    }

    suspend fun receiveGoods(
        poId: String,
        inventoryId: String,
        quantityReceived: Double,
        actor: UserSession
    ): Result<EnterpriseGoodsReceiptEntity> = inventoryMutex.withLock {
        val po = db.purchaseDao().getPurchaseOrderById(poId)
            ?: return@withLock Result.failure(IllegalArgumentException("Purchase order not found"))

        val inventory = db.inventoryDao().getInventoryById(inventoryId)
            ?: return@withLock Result.failure(IllegalArgumentException("Inventory item not found"))

        val grnNum = "SE-GRN-2026-" + String.format("%06d", (System.currentTimeMillis() % 1000000).toInt())
        val grnId = "GRN-" + UUID.randomUUID().toString().take(8).uppercase()

        val grn = EnterpriseGoodsReceiptEntity(
            receiptId = grnId,
            receiptNumber = grnNum,
            purchaseOrderId = poId,
            inventoryId = inventoryId,
            quantityReceived = quantityReceived,
            unit = inventory.unit,
            receivedBy = actor.name,
            notes = "Received against PO ${po.poNumber}"
        )
        db.purchaseDao().insertGoodsReceipt(grn)

        // Increment stock
        val newCurrent = inventory.currentStock + quantityReceived
        val newAvailable = newCurrent - inventory.reservedStock

        val updatedInv = inventory.copy(
            currentStock = newCurrent,
            availableStock = newAvailable,
            updatedAt = System.currentTimeMillis()
        )
        db.inventoryDao().updateInventoryItem(updatedInv)

        // Log transaction
        db.inventoryDao().insertTransaction(
            EnterpriseInventoryTransactionEntity(
                transactionId = "TXN-" + UUID.randomUUID().toString().take(8).uppercase(),
                inventoryId = inventory.inventoryId,
                divisionId = inventory.divisionId,
                transactionType = "PURCHASE",
                quantity = quantityReceived,
                stockBefore = inventory.currentStock,
                stockAfter = newCurrent,
                referenceType = "GOODS_RECEIPT",
                referenceId = grnNum,
                notes = "Stock increase via GRN $grnNum",
                performedBy = actor.name
            )
        )

        // Update PO status
        db.purchaseDao().updatePurchaseOrder(po.copy(status = "RECEIVED"))

        recordAudit(
            actor = actor,
            division = inventory.divisionId,
            entity = "GOODS_RECEIPT",
            entityId = grn.receiptId,
            action = AuditAction.RECEIVE_STOCK,
            details = "Received $quantityReceived ${inventory.unit} of ${inventory.name} into stock",
            result = "SUCCESS"
        )

        return@withLock Result.success(grn)
    }

    // -------------------------------------------------------------
    // Quality Control & Rework
    // -------------------------------------------------------------
    suspend fun recordQualityCheck(
        jobId: String,
        orderId: String,
        checklistResults: Map<String, Boolean>,
        remarks: String? = null,
        actor: UserSession
    ): Result<EnterpriseQualityCheckEntity> {
        val job = db.productionDao().getProductionJobById(jobId)
            ?: return Result.failure(IllegalArgumentException("Production job not found"))

        // Check if all checks passed
        val allPassed = checklistResults.values.all { it }
        val status = if (allPassed) "PASSED" else "REWORK_REQUIRED"

        val qcId = "QC-" + UUID.randomUUID().toString().take(8).uppercase()
        val qc = EnterpriseQualityCheckEntity(
            qcId = qcId,
            productionJobId = jobId,
            orderId = orderId,
            checklistResultsJson = checklistResults.entries.joinToString(",") { "${it.key}:${it.value}" },
            checkedBy = actor.name,
            status = status,
            remarks = remarks
        )
        db.qualityDao().insertQualityCheck(qc)

        if (allPassed) {
            // Advance to READY_FOR_PACKING
            db.productionDao().updateProductionJob(job.copy(status = "READY_FOR_PACKING", updatedAt = System.currentTimeMillis()))
        } else {
            // Failed QC: create rework entry and put job in PAUSED / REWORK
            val rework = EnterpriseReworkEntity(
                reworkId = "REW-" + UUID.randomUUID().toString().take(8).uppercase(),
                productionJobId = jobId,
                qcId = qcId,
                reason = remarks ?: "Failed checks: " + checklistResults.filter { !it.value }.keys.joinToString(", "),
                failedItemsCount = 50,
                responsibleStage = "PRINTING_OR_CUTTING",
                reworkCount = 1,
                notes = "Rework initiated due to QC failure",
                createdBy = actor.name
            )
            db.qualityDao().insertRework(rework)
            db.productionDao().updateProductionJob(job.copy(status = "PAUSED", updatedAt = System.currentTimeMillis()))
        }

        recordAudit(
            actor = actor,
            division = "PRINTING",
            entity = "QUALITY_CHECK",
            entityId = qc.qcId,
            action = if (allPassed) AuditAction.QUALITY_CHECK else AuditAction.REWORK,
            details = "QC evaluated as $status for job ${job.jobNumber}",
            result = "SUCCESS"
        )

        return Result.success(qc)
    }

    // -------------------------------------------------------------
    // Packing & Delivery Management
    // -------------------------------------------------------------
    suspend fun packOrder(
        orderId: String,
        quantity: Double,
        packageCount: Int,
        notes: String? = null,
        actor: UserSession
    ): Result<EnterprisePackingEntity> {
        val packingId = "PACK-" + UUID.randomUUID().toString().take(8).uppercase()
        val packing = EnterprisePackingEntity(
            packingId = packingId,
            orderId = orderId,
            quantity = quantity,
            packageCount = packageCount,
            packedBy = actor.name,
            notes = notes,
            status = "COMPLETED"
        )
        db.qualityDao().insertPacking(packing)

        // Advance job to PACKED / READY_FOR_DELIVERY
        val job = db.productionDao().getProductionJobByOrderId(orderId)
        if (job != null) {
            db.productionDao().updateProductionJob(job.copy(status = "READY_FOR_DELIVERY", updatedAt = System.currentTimeMillis()))
        }

        recordAudit(
            actor = actor,
            division = "PRINTING",
            entity = "PACKING",
            entityId = packing.packingId,
            action = AuditAction.PACK_ORDER,
            details = "Packed $packageCount parcels for order $orderId",
            result = "SUCCESS"
        )

        return Result.success(packing)
    }

    fun getAllDeliveries(): Flow<List<EnterpriseDeliveryEntity>> = db.deliveryDao().getAllDeliveries()

    suspend fun createDelivery(
        orderId: String,
        deliveryMethod: String = "COMPANY_DELIVERY",
        deliveryPerson: String? = null,
        vehicle: String? = null,
        actor: UserSession
    ): Result<EnterpriseDeliveryEntity> {
        val order = db.orderDao().getOrderById(orderId)
            ?: return Result.failure(IllegalArgumentException("Order not found"))

        val customer = db.customerDao().getCustomerById(order.customerId)
            ?: return Result.failure(IllegalArgumentException("Customer not found"))

        val delNum = "SE-DEL-2026-" + String.format("%06d", (System.currentTimeMillis() % 1000000).toInt())
        val delId = "DEL-" + UUID.randomUUID().toString().take(8).uppercase()

        val delivery = EnterpriseDeliveryEntity(
            deliveryId = delId,
            deliveryNumber = delNum,
            orderId = orderId,
            customerId = customer.customerId,
            customerName = customer.name,
            deliveryAddress = customer.address ?: "Default customer address",
            deliveryMethod = deliveryMethod,
            deliveryPerson = deliveryPerson ?: "Enterprise Dispatch Lead",
            vehicleOptional = vehicle,
            scheduledDate = System.currentTimeMillis(),
            status = "SCHEDULED"
        )
        db.deliveryDao().insertDelivery(delivery)

        recordAudit(
            actor = actor,
            division = order.divisionId,
            entity = "DELIVERY",
            entityId = delivery.deliveryId,
            action = AuditAction.CREATE_DELIVERY,
            details = "Scheduled delivery ${delivery.deliveryNumber} for order ${order.orderNumber}",
            result = "SUCCESS"
        )

        return Result.success(delivery)
    }

    suspend fun markDelivered(
        deliveryId: String,
        proofReference: String,
        actor: UserSession
    ): Result<EnterpriseDeliveryEntity> {
        val delivery = db.deliveryDao().getDeliveryById(deliveryId)
            ?: return Result.failure(IllegalArgumentException("Delivery not found"))

        val updated = delivery.copy(
            status = "DELIVERED",
            actualDate = System.currentTimeMillis(),
            proofReferenceOptional = proofReference,
            updatedAt = System.currentTimeMillis()
        )
        db.deliveryDao().updateDelivery(updated)

        // Advance Order to COMPLETED
        val order = db.orderDao().getOrderById(delivery.orderId)
        if (order != null) {
            db.orderDao().updateOrder(order.copy(status = "COMPLETED", updatedAt = System.currentTimeMillis()))
        }

        recordAudit(
            actor = actor,
            division = null,
            entity = "DELIVERY",
            entityId = delivery.deliveryId,
            action = AuditAction.DELIVERY_COMPLETED,
            details = "Completed delivery ${delivery.deliveryNumber}. Proof: $proofReference",
            result = "SUCCESS"
        )

        return Result.success(updated)
    }

    // -------------------------------------------------------------
    // Invoices & Payments (Overpayment Prevention)
    // -------------------------------------------------------------
    fun getAllInvoices(): Flow<List<InvoiceEntity>> = db.invoicePaymentDao().getAllInvoices()

    fun getInvoicesByDivision(divisionId: String): Flow<List<InvoiceEntity>> =
        db.invoicePaymentDao().getInvoicesByDivision(divisionId)

    suspend fun getInvoiceById(id: String): InvoiceEntity? = db.invoicePaymentDao().getInvoiceById(id)

    suspend fun createInvoiceForOrder(orderId: String, actor: UserSession): Result<InvoiceEntity> {
        val order = db.orderDao().getOrderById(orderId)
            ?: return Result.failure(IllegalArgumentException("Order not found"))

        val customer = db.customerDao().getCustomerById(order.customerId)
            ?: return Result.failure(IllegalArgumentException("Customer not found"))

        val invPrefix = if (order.divisionId == "PRINTING") "SE-PRINT-INV-2026-" else "SE-TRD-INV-2026-"
        val invNum = invPrefix + String.format("%06d", (System.currentTimeMillis() % 1000000).toInt())
        val invId = "INV-" + UUID.randomUUID().toString().take(8).uppercase()

        val invoice = InvoiceEntity(
            invoiceId = invId,
            invoiceNumber = invNum,
            businessId = "SAMPURNA_ENTERPRISE",
            divisionId = order.divisionId,
            orderId = order.orderId,
            quotationId = order.quotationId,
            customerId = customer.customerId,
            customerName = customer.name,
            subtotal = order.subtotal,
            discount = order.discount,
            taxableValue = order.taxableValue,
            totalTax = order.tax,
            grandTotal = order.grandTotal,
            balanceDue = order.grandTotal,
            status = "UNPAID",
            createdBy = actor.name
        )
        db.invoicePaymentDao().insertInvoice(invoice)

        recordAudit(
            actor = actor,
            division = order.divisionId,
            entity = "INVOICE",
            entityId = invoice.invoiceId,
            action = AuditAction.CREATE_INVOICE,
            details = "Generated invoice ${invoice.invoiceNumber} for ₹${invoice.grandTotal}",
            result = "SUCCESS"
        )

        return Result.success(invoice)
    }

    suspend fun recordPayment(
        invoiceId: String,
        amount: Double,
        method: String = "UPI",
        referenceNumber: String? = null,
        notes: String? = null,
        actor: UserSession
    ): Result<PaymentEntity> {
        val invoice = db.invoicePaymentDao().getInvoiceById(invoiceId)
            ?: return Result.failure(IllegalArgumentException("Invoice not found"))

        // Strict overpayment validation
        if (amount > invoice.balanceDue) {
            return Result.failure(
                IllegalArgumentException("Payment amount ₹$amount exceeds remaining balance ₹${invoice.balanceDue}. Overpayment prevented.")
            )
        }
        if (amount <= 0.0) {
            return Result.failure(IllegalArgumentException("Payment amount must be greater than zero"))
        }

        val paymentId = "PAY-" + UUID.randomUUID().toString().take(8).uppercase()
        val payment = PaymentEntity(
            paymentId = paymentId,
            invoiceId = invoiceId,
            customerId = invoice.customerId,
            amount = DeterministicFinancialEngine.round2(amount),
            paymentMethod = method,
            referenceNumber = referenceNumber,
            notes = notes,
            receivedBy = actor.name
        )
        db.invoicePaymentDao().insertPayment(payment)

        val newBalance = DeterministicFinancialEngine.round2(invoice.balanceDue - amount)
        val newStatus = if (newBalance <= 0.0) "PAID" else "PARTIALLY_PAID"

        db.invoicePaymentDao().updateInvoice(invoice.copy(balanceDue = newBalance, status = newStatus))

        recordAudit(
            actor = actor,
            division = invoice.divisionId,
            entity = "PAYMENT",
            entityId = payment.paymentId,
            action = AuditAction.RECORD_PAYMENT,
            details = "Recorded payment of ₹$amount via $method for invoice ${invoice.invoiceNumber}",
            result = "SUCCESS"
        )

        return Result.success(payment)
    }

    // -------------------------------------------------------------
    // Customer 360 View
    // -------------------------------------------------------------
    suspend fun getCustomerHistory(customerId: String): CustomerHistory360 {
        val customer = db.customerDao().getCustomerById(customerId)
        val quotations = db.quotationDao().getQuotationsByCustomer(customerId)
        val orders = db.orderDao().getOrdersByCustomer(customerId)
        val invoices = db.invoicePaymentDao().getInvoicesByCustomer(customerId)
        val payments = db.invoicePaymentDao().getPaymentsForCustomer(customerId)

        val totalBilled = invoices.sumOf { it.grandTotal }
        val totalPaid = payments.sumOf { it.amount }
        val totalOutstanding = DeterministicFinancialEngine.round2(totalBilled - totalPaid)

        return CustomerHistory360(
            customer = customer,
            quotations = quotations,
            orders = orders,
            invoices = invoices,
            payments = payments,
            totalBilled = totalBilled,
            totalPaid = totalPaid,
            totalOutstanding = totalOutstanding
        )
    }

    // -------------------------------------------------------------
    // Approvals & Audits
    // -------------------------------------------------------------
    fun getAllApprovals(): Flow<List<ApprovalRequestEntity>> = db.approvalAuditDao().getAllApprovals()
    fun getPendingApprovals(): Flow<List<ApprovalRequestEntity>> = db.approvalAuditDao().getPendingApprovals()
    fun getAllAuditLogs(): Flow<List<AuditLogEntity>> = db.approvalAuditDao().getAllAuditLogs()

    suspend fun recordAudit(
        actor: UserSession,
        division: String?,
        entity: String,
        entityId: String,
        action: AuditAction,
        details: String?,
        result: String
    ) {
        val log = AuditLogEntity(
            logId = "LOG-" + UUID.randomUUID().toString().take(8).uppercase(),
            actorId = actor.userId,
            actorName = actor.name,
            business = actor.allowedBusiness.code,
            division = division,
            entity = entity,
            entityId = entityId,
            action = action.name,
            details = details,
            result = result
        )
        db.approvalAuditDao().insertAuditLog(log)
    }

    // -------------------------------------------------------------
    // Baseline Multi-Business Integration (Phase 2A & Phase 2B)
    // -------------------------------------------------------------
    fun getAllBBJobCards(): Flow<List<BBMotorJobCardEntity>> = db.baselineDao().getAllBBJobCards()
    fun getAllRenaissanceReservations(): Flow<List<RenaissanceReservationEntity>> = db.baselineDao().getAllRenaissanceReservations()

    suspend fun getBBJobCardsCount(): Int = db.baselineDao().getBBJobCardCount()

    suspend fun createBBMotorJobCard(
        vehicleRegNo: String,
        customerId: String,
        estimatedCost: Double
    ): BBMotorJobCardEntity {
        val jc = BBMotorJobCardEntity(
            jobCardId = "BBJC-" + UUID.randomUUID().toString().take(8).uppercase(),
            jobNumber = "BB-JC-2026-" + String.format("%06d", (System.currentTimeMillis() % 1000000).toInt()),
            customerId = customerId,
            vehicleRegNo = vehicleRegNo,
            estimatedCost = estimatedCost
        )
        db.baselineDao().insertBBJobCard(jc)
        return jc
    }

    suspend fun getRenaissanceReservations(location: String): List<RenaissanceReservationEntity> =
        db.baselineDao().getRenaissanceReservations(location)

    suspend fun createRenaissanceReservation(
        location: String,
        roomType: String,
        customerId: String,
        totalAmount: Double
    ): RenaissanceReservationEntity {
        val res = RenaissanceReservationEntity(
            reservationId = "RHRES-" + UUID.randomUUID().toString().take(8).uppercase(),
            reservationNumber = "RH-RES-2026-" + String.format("%06d", (System.currentTimeMillis() % 1000000).toInt()),
            propertyLocation = location,
            roomType = roomType,
            customerId = customerId,
            totalAmount = totalAmount
        )
        db.baselineDao().insertRenaissanceReservation(res)
        return res
    }

    // -------------------------------------------------------------
    // Seed Demo / Test Data
    // -------------------------------------------------------------
    suspend fun seedDemoDataIfEmpty() {
        val products = db.catalogDao().getAllProducts()
        // If divisions not seeded
        db.catalogDao().insertDivision(
            EnterpriseDivisionEntity("PRINTING", "Division A: Printing & Digital Services", "Commercial & digital printing")
        )
        db.catalogDao().insertDivision(
            EnterpriseDivisionEntity("TRADING", "Division B: Building & Trading Materials", "Construction and structural commodities")
        )

        // Seed Categories
        db.catalogDao().insertCategory(EnterpriseCategoryEntity("CAT-VC", "PRINTING", "Visiting Cards", "VISITING_CARD"))
        db.catalogDao().insertCategory(EnterpriseCategoryEntity("CAT-LH", "PRINTING", "Letterheads", "LETTERHEAD"))
        db.catalogDao().insertCategory(EnterpriseCategoryEntity("CAT-BRO", "PRINTING", "Brochures & Flyers", "BROCHURE"))
        db.catalogDao().insertCategory(EnterpriseCategoryEntity("CAT-BAN", "PRINTING", "Banners & Flex", "BANNER"))

        db.catalogDao().insertCategory(EnterpriseCategoryEntity("CAT-CEM", "TRADING", "Cement", "CEMENT"))
        db.catalogDao().insertCategory(EnterpriseCategoryEntity("CAT-STL", "TRADING", "TMT Steel", "STEEL"))
        db.catalogDao().insertCategory(EnterpriseCategoryEntity("CAT-SND", "TRADING", "Sand & Aggregate", "SAND"))

        // Seed Products
        val prodVC = EnterpriseProductEntity(
            productId = "PROD-VC-001",
            divisionId = "PRINTING",
            categoryId = "CAT-VC",
            productCode = "PRINT-VC-350",
            name = "Premium Visiting Cards",
            description = "350 GSM Art Card with Thermal Matte/Gloss Lamination",
            unit = "BOX",
            purchasePrice = 120.0,
            sellingPrice = 350.0,
            gstRate = 18.0,
            minimumStock = 50.0,
            reorderQuantity = 100.0
        )
        db.catalogDao().insertProduct(prodVC)

        val prodBrochure = EnterpriseProductEntity(
            productId = "PROD-BRO-001",
            divisionId = "PRINTING",
            categoryId = "CAT-BRO",
            productCode = "PRINT-BRO-170",
            name = "A4 Tri-Fold Corporate Brochure",
            description = "170 GSM Gloss Art Paper Multi-colour Offset",
            unit = "PCS",
            purchasePrice = 4.5,
            sellingPrice = 12.0,
            gstRate = 18.0,
            minimumStock = 500.0,
            reorderQuantity = 1000.0
        )
        db.catalogDao().insertProduct(prodBrochure)

        val prodCement = EnterpriseProductEntity(
            productId = "PROD-CEM-001",
            divisionId = "TRADING",
            categoryId = "CAT-CEM",
            productCode = "TRD-CEM-53G",
            name = "UltraTech 53-Grade OPC Cement",
            description = "50 KG Bag High Strength Structural Cement",
            unit = "BAG",
            purchasePrice = 330.0,
            sellingPrice = 385.0,
            gstRate = 28.0,
            minimumStock = 200.0,
            reorderQuantity = 500.0
        )
        db.catalogDao().insertProduct(prodCement)

        val prodSteel = EnterpriseProductEntity(
            productId = "PROD-STL-001",
            divisionId = "TRADING",
            categoryId = "CAT-STL",
            productCode = "TRD-STL-FE550D",
            name = "Tata Tiscon 12mm Fe550D TMT Rebars",
            description = "Corrosion resistant earthquake resilient rebar",
            unit = "TON",
            purchasePrice = 58000.0,
            sellingPrice = 64500.0,
            gstRate = 18.0,
            minimumStock = 5.0,
            reorderQuantity = 15.0
        )
        db.catalogDao().insertProduct(prodSteel)

        // Seed Rate Cards
        db.rateCardDao().insertRateCard(
            EnterpriseRateCardEntity(
                rateCardId = "RC-VC-001",
                divisionId = "PRINTING",
                productId = prodVC.productId,
                paperType = "Art Card",
                paperSize = "3.5x2 inch",
                gsm = 350,
                colourMode = "CMYK",
                sideCount = 2,
                minQuantity = 1,
                baseRatePerUnit = 2.80,
                setupCharge = 150.0,
                finishingRate = 0.40,
                bindingRate = 0.0,
                urgentSurchargeRate = 25.0,
                version = 1,
                isActive = true,
                createdBy = "Admin"
            )
        )

        // Seed Inventory
        db.inventoryDao().insertInventoryItem(
            EnterpriseInventoryEntity(
                inventoryId = "INV-PAP-01",
                divisionId = "PRINTING",
                productOrMaterialId = "MAT-PAP-300",
                name = "300 GSM Art Card Sheets (12x18)",
                unit = "SHEET",
                currentStock = 2500.0,
                reservedStock = 500.0,
                availableStock = 2000.0,
                minimumStock = 800.0,
                reorderQuantity = 2000.0,
                location = "Warehouse Rack P-01"
            )
        )

        db.inventoryDao().insertInventoryItem(
            EnterpriseInventoryEntity(
                inventoryId = "INV-CEM-01",
                divisionId = "TRADING",
                productOrMaterialId = prodCement.productId,
                name = "UltraTech 53-Grade Cement Bags",
                unit = "BAG",
                currentStock = 350.0,
                reservedStock = 50.0,
                availableStock = 300.0,
                minimumStock = 100.0,
                reorderQuantity = 500.0,
                location = "Godown B Yard"
            )
        )

        // Seed Demo Customers
        db.customerDao().insertCustomer(
            CustomerEntity(
                customerId = "CUST-DEMO-001",
                name = "Subrata Majumder (Enterprise Corp)",
                phone = "9876543210",
                email = "subrata@sampurna.in",
                address = "Plot 42, Infocity Industrial Estate",
                city = "Bhubaneswar",
                state = "Odisha",
                pincode = "751024",
                gstinOptional = "21AAAAA0000A1Z5",
                customerType = "CORPORATE"
            )
        )
        db.customerDao().insertCustomer(
            CustomerEntity(
                customerId = "CUST-DEMO-002",
                name = "Puri Coastal Builders",
                phone = "9876543211",
                email = "contact@puribuilders.com",
                address = "VIP Road",
                city = "Puri",
                state = "Odisha",
                pincode = "752001",
                gstinOptional = "21BBBBB1111B1Z2",
                customerType = "BUSINESS"
            )
        )
        // Seed Demo Baseline B.B. Motors job cards if empty
        if (db.baselineDao().getBBJobCardCount() == 0) {
            db.baselineDao().insertBBJobCard(
                BBMotorJobCardEntity(
                    jobCardId = "BBJC-DEMO-01",
                    jobNumber = "BB-JC-2026-000101",
                    customerId = "CUST-DEMO-001",
                    vehicleRegNo = "OD-02-AX-8910",
                    status = "IN_PROGRESS",
                    estimatedCost = 6500.0
                )
            )
            db.baselineDao().insertBBJobCard(
                BBMotorJobCardEntity(
                    jobCardId = "BBJC-DEMO-02",
                    jobNumber = "BB-JC-2026-000102",
                    customerId = "CUST-DEMO-002",
                    vehicleRegNo = "OD-02-CR-4521",
                    status = "OPEN",
                    estimatedCost = 8200.0
                )
            )
            db.baselineDao().insertBBJobCard(
                BBMotorJobCardEntity(
                    jobCardId = "BBJC-DEMO-03",
                    jobNumber = "BB-JC-2026-000103",
                    customerId = "CUST-DEMO-001",
                    vehicleRegNo = "OD-02-BZ-3312",
                    status = "READY",
                    estimatedCost = 4800.0
                )
            )
        }

        // Seed Demo Baseline Renaissance Hotel bookings if empty
        if (db.baselineDao().getRenaissanceReservationCount() == 0) {
            db.baselineDao().insertRenaissanceReservation(
                RenaissanceReservationEntity(
                    reservationId = "RHRES-DEMO-01",
                    reservationNumber = "RH-RES-2026-000201",
                    propertyLocation = "Puri",
                    roomType = "Deluxe Sea Facing Suite",
                    customerId = "CUST-DEMO-001",
                    status = "CONFIRMED",
                    totalAmount = 18500.0
                )
            )
            db.baselineDao().insertRenaissanceReservation(
                RenaissanceReservationEntity(
                    reservationId = "RHRES-DEMO-02",
                    reservationNumber = "RH-RES-2026-000202",
                    propertyLocation = "Bhubaneswar",
                    roomType = "Executive Business Suite",
                    customerId = "CUST-DEMO-002",
                    status = "CONFIRMED",
                    totalAmount = 9200.0
                )
            )
        }
    }
}

data class CustomerHistory360(
    val customer: CustomerEntity?,
    val quotations: List<EnterpriseQuotationEntity>,
    val orders: List<EnterpriseOrderEntity>,
    val invoices: List<InvoiceEntity>,
    val payments: List<PaymentEntity>,
    val totalBilled: Double,
    val totalPaid: Double,
    val totalOutstanding: Double
)
