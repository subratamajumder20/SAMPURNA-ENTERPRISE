package com.example.data.dao

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerDao {
    @Query("SELECT * FROM shared_customers ORDER BY name ASC")
    fun getAllCustomers(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM shared_customers WHERE customerId = :id")
    suspend fun getCustomerById(id: String): CustomerEntity?

    @Query("SELECT * FROM shared_customers WHERE phone = :phone LIMIT 1")
    suspend fun findCustomerByPhone(phone: String): CustomerEntity?

    @Query("SELECT * FROM shared_customers WHERE email = :email LIMIT 1")
    suspend fun findCustomerByEmail(email: String): CustomerEntity?

    @Query("SELECT * FROM shared_customers WHERE name LIKE '%' || :query || '%' OR phone LIKE '%' || :query || '%'")
    suspend fun searchCustomers(query: String): List<CustomerEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: CustomerEntity)

    @Update
    suspend fun updateCustomer(customer: CustomerEntity)
}

@Dao
interface SupplierDao {
    @Query("SELECT * FROM shared_suppliers ORDER BY name ASC")
    fun getAllSuppliers(): Flow<List<SupplierEntity>>

    @Query("SELECT * FROM shared_suppliers WHERE supplierId = :id")
    suspend fun getSupplierById(id: String): SupplierEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSupplier(supplier: SupplierEntity)
}

@Dao
interface EnterpriseCatalogDao {
    @Query("SELECT * FROM enterprise_divisions")
    fun getAllDivisions(): Flow<List<EnterpriseDivisionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDivision(division: EnterpriseDivisionEntity)

    @Query("SELECT * FROM enterprise_categories WHERE divisionId = :divisionId")
    fun getCategoriesByDivision(divisionId: String): Flow<List<EnterpriseCategoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: EnterpriseCategoryEntity)

    @Query("SELECT * FROM enterprise_products WHERE divisionId = :divisionId ORDER BY name ASC")
    fun getProductsByDivision(divisionId: String): Flow<List<EnterpriseProductEntity>>

    @Query("SELECT * FROM enterprise_products ORDER BY name ASC")
    fun getAllProducts(): Flow<List<EnterpriseProductEntity>>

    @Query("SELECT * FROM enterprise_products WHERE productId = :id")
    suspend fun getProductById(id: String): EnterpriseProductEntity?

    @Query("SELECT * FROM enterprise_products WHERE productCode = :code LIMIT 1")
    suspend fun getProductByCode(code: String): EnterpriseProductEntity?

    @Query("SELECT * FROM enterprise_products WHERE (name LIKE '%' || :query || '%' OR productCode LIKE '%' || :query || '%') AND (divisionId = :divisionId OR :divisionId = 'BOTH')")
    suspend fun searchProducts(query: String, divisionId: String): List<EnterpriseProductEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: EnterpriseProductEntity)

    @Update
    suspend fun updateProduct(product: EnterpriseProductEntity)
}

@Dao
interface EnterpriseRateCardDao {
    @Query("SELECT * FROM enterprise_rate_cards WHERE divisionId = :divisionId AND isActive = 1")
    fun getActiveRateCardsByDivision(divisionId: String): Flow<List<EnterpriseRateCardEntity>>

    @Query("SELECT * FROM enterprise_rate_cards WHERE productId = :productId AND isActive = 1 LIMIT 1")
    suspend fun getActiveRateCardForProduct(productId: String): EnterpriseRateCardEntity?

    @Query("SELECT * FROM enterprise_rate_cards WHERE rateCardId = :id")
    suspend fun getRateCardById(id: String): EnterpriseRateCardEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRateCard(rateCard: EnterpriseRateCardEntity)

    @Update
    suspend fun updateRateCard(rateCard: EnterpriseRateCardEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRateVersion(version: EnterpriseRateVersionEntity)

    @Query("SELECT * FROM enterprise_rate_versions WHERE rateCardId = :rateCardId ORDER BY versionNumber DESC")
    suspend fun getRateVersions(rateCardId: String): List<EnterpriseRateVersionEntity>
}

@Dao
interface EnterpriseQuotationDao {
    @Query("SELECT * FROM enterprise_quotations ORDER BY createdAt DESC")
    fun getAllQuotations(): Flow<List<EnterpriseQuotationEntity>>

    @Query("SELECT * FROM enterprise_quotations WHERE divisionId = :divisionId ORDER BY createdAt DESC")
    fun getQuotationsByDivision(divisionId: String): Flow<List<EnterpriseQuotationEntity>>

    @Query("SELECT * FROM enterprise_quotations WHERE quotationId = :id")
    suspend fun getQuotationById(id: String): EnterpriseQuotationEntity?

    @Query("SELECT * FROM enterprise_quotations WHERE quotationNumber = :num LIMIT 1")
    suspend fun getQuotationByNumber(num: String): EnterpriseQuotationEntity?

    @Query("SELECT * FROM enterprise_quotations WHERE customerId = :customerId ORDER BY createdAt DESC")
    suspend fun getQuotationsByCustomer(customerId: String): List<EnterpriseQuotationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuotation(quotation: EnterpriseQuotationEntity)

    @Update
    suspend fun updateQuotation(quotation: EnterpriseQuotationEntity)

    @Query("SELECT * FROM enterprise_quotation_items WHERE quotationId = :quotationId")
    suspend fun getQuotationItems(quotationId: String): List<EnterpriseQuotationItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuotationItems(items: List<EnterpriseQuotationItemEntity>)
}

@Dao
interface EnterpriseOrderDao {
    @Query("SELECT * FROM enterprise_orders ORDER BY createdAt DESC")
    fun getAllOrders(): Flow<List<EnterpriseOrderEntity>>

    @Query("SELECT * FROM enterprise_orders WHERE divisionId = :divisionId ORDER BY createdAt DESC")
    fun getOrdersByDivision(divisionId: String): Flow<List<EnterpriseOrderEntity>>

    @Query("SELECT * FROM enterprise_orders WHERE orderId = :id")
    suspend fun getOrderById(id: String): EnterpriseOrderEntity?

    @Query("SELECT * FROM enterprise_orders WHERE orderNumber = :num LIMIT 1")
    suspend fun getOrderByNumber(num: String): EnterpriseOrderEntity?

    @Query("SELECT * FROM enterprise_orders WHERE customerId = :customerId ORDER BY createdAt DESC")
    suspend fun getOrdersByCustomer(customerId: String): List<EnterpriseOrderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: EnterpriseOrderEntity)

    @Update
    suspend fun updateOrder(order: EnterpriseOrderEntity)

    @Query("SELECT * FROM enterprise_order_items WHERE orderId = :orderId")
    suspend fun getOrderItems(orderId: String): List<EnterpriseOrderItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrderItems(items: List<EnterpriseOrderItemEntity>)
}

@Dao
interface EnterpriseArtworkDao {
    @Query("SELECT * FROM enterprise_artworks WHERE orderId = :orderId ORDER BY version DESC")
    suspend fun getArtworksForOrder(orderId: String): List<EnterpriseArtworkEntity>

    @Query("SELECT * FROM enterprise_artworks WHERE orderId = :orderId ORDER BY version DESC LIMIT 1")
    suspend fun getLatestArtworkForOrder(orderId: String): EnterpriseArtworkEntity?

    @Query("SELECT * FROM enterprise_artworks WHERE artworkId = :id")
    suspend fun getArtworkById(id: String): EnterpriseArtworkEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertArtwork(artwork: EnterpriseArtworkEntity)

    @Update
    suspend fun updateArtwork(artwork: EnterpriseArtworkEntity)
}

@Dao
interface EnterpriseProductionDao {
    @Query("SELECT * FROM enterprise_production_jobs ORDER BY createdAt DESC")
    fun getAllProductionJobs(): Flow<List<EnterpriseProductionJobEntity>>

    @Query("SELECT * FROM enterprise_production_jobs WHERE status = :status ORDER BY priority DESC")
    fun getProductionJobsByStatus(status: String): Flow<List<EnterpriseProductionJobEntity>>

    @Query("SELECT * FROM enterprise_production_jobs WHERE productionJobId = :id")
    suspend fun getProductionJobById(id: String): EnterpriseProductionJobEntity?

    @Query("SELECT * FROM enterprise_production_jobs WHERE jobNumber = :num LIMIT 1")
    suspend fun getProductionJobByNumber(num: String): EnterpriseProductionJobEntity?

    @Query("SELECT * FROM enterprise_production_jobs WHERE orderId = :orderId LIMIT 1")
    suspend fun getProductionJobByOrderId(orderId: String): EnterpriseProductionJobEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProductionJob(job: EnterpriseProductionJobEntity)

    @Update
    suspend fun updateProductionJob(job: EnterpriseProductionJobEntity)

    @Query("SELECT * FROM enterprise_material_requirements WHERE productionJobId = :jobId")
    suspend fun getMaterialRequirements(jobId: String): List<EnterpriseMaterialRequirementEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMaterialRequirements(reqs: List<EnterpriseMaterialRequirementEntity>)

    @Update
    suspend fun updateMaterialRequirement(req: EnterpriseMaterialRequirementEntity)
}

@Dao
interface EnterpriseInventoryDao {
    @Query("SELECT * FROM enterprise_inventory ORDER BY name ASC")
    fun getAllInventory(): Flow<List<EnterpriseInventoryEntity>>

    @Query("SELECT * FROM enterprise_inventory WHERE divisionId = :divisionId ORDER BY name ASC")
    fun getInventoryByDivision(divisionId: String): Flow<List<EnterpriseInventoryEntity>>

    @Query("SELECT * FROM enterprise_inventory WHERE inventoryId = :id")
    suspend fun getInventoryById(id: String): EnterpriseInventoryEntity?

    @Query("SELECT * FROM enterprise_inventory WHERE productOrMaterialId = :prodOrMatId LIMIT 1")
    suspend fun getInventoryByProductOrMaterialId(prodOrMatId: String): EnterpriseInventoryEntity?

    @Query("SELECT * FROM enterprise_inventory WHERE availableStock <= minimumStock")
    fun getLowStockItems(): Flow<List<EnterpriseInventoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventoryItem(item: EnterpriseInventoryEntity)

    @Update
    suspend fun updateInventoryItem(item: EnterpriseInventoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: EnterpriseInventoryTransactionEntity)

    @Query("SELECT * FROM enterprise_inventory_transactions WHERE inventoryId = :inventoryId ORDER BY createdAt DESC")
    suspend fun getTransactionsForInventory(inventoryId: String): List<EnterpriseInventoryTransactionEntity>
}

@Dao
interface EnterprisePurchaseDao {
    @Query("SELECT * FROM enterprise_purchase_requests ORDER BY createdAt DESC")
    fun getAllPurchaseRequests(): Flow<List<EnterprisePurchaseRequestEntity>>

    @Query("SELECT * FROM enterprise_purchase_requests WHERE purchaseRequestId = :id")
    suspend fun getPurchaseRequestById(id: String): EnterprisePurchaseRequestEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchaseRequest(request: EnterprisePurchaseRequestEntity)

    @Update
    suspend fun updatePurchaseRequest(request: EnterprisePurchaseRequestEntity)

    @Query("SELECT * FROM enterprise_purchase_orders ORDER BY createdAt DESC")
    fun getAllPurchaseOrders(): Flow<List<EnterprisePurchaseOrderEntity>>

    @Query("SELECT * FROM enterprise_purchase_orders WHERE purchaseOrderId = :id")
    suspend fun getPurchaseOrderById(id: String): EnterprisePurchaseOrderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchaseOrder(po: EnterprisePurchaseOrderEntity)

    @Update
    suspend fun updatePurchaseOrder(po: EnterprisePurchaseOrderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoodsReceipt(grn: EnterpriseGoodsReceiptEntity)
}

@Dao
interface EnterpriseQualityDao {
    @Query("SELECT * FROM enterprise_quality_checks WHERE productionJobId = :jobId ORDER BY checkedAt DESC")
    suspend fun getChecksForJob(jobId: String): List<EnterpriseQualityCheckEntity>

    @Query("SELECT * FROM enterprise_quality_checks WHERE qcId = :id")
    suspend fun getQualityCheckById(id: String): EnterpriseQualityCheckEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQualityCheck(qc: EnterpriseQualityCheckEntity)

    @Update
    suspend fun updateQualityCheck(qc: EnterpriseQualityCheckEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRework(rework: EnterpriseReworkEntity)

    @Query("SELECT * FROM enterprise_rework WHERE productionJobId = :jobId ORDER BY createdAt DESC")
    suspend fun getReworkHistory(jobId: String): List<EnterpriseReworkEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPacking(packing: EnterprisePackingEntity)

    @Query("SELECT * FROM enterprise_packing WHERE orderId = :orderId LIMIT 1")
    suspend fun getPackingForOrder(orderId: String): EnterprisePackingEntity?
}

@Dao
interface EnterpriseDeliveryDao {
    @Query("SELECT * FROM enterprise_deliveries ORDER BY createdAt DESC")
    fun getAllDeliveries(): Flow<List<EnterpriseDeliveryEntity>>

    @Query("SELECT * FROM enterprise_deliveries WHERE deliveryId = :id")
    suspend fun getDeliveryById(id: String): EnterpriseDeliveryEntity?

    @Query("SELECT * FROM enterprise_deliveries WHERE orderId = :orderId LIMIT 1")
    suspend fun getDeliveryByOrderId(orderId: String): EnterpriseDeliveryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDelivery(delivery: EnterpriseDeliveryEntity)

    @Update
    suspend fun updateDelivery(delivery: EnterpriseDeliveryEntity)
}

@Dao
interface InvoicePaymentDao {
    @Query("SELECT * FROM shared_invoices ORDER BY createdAt DESC")
    fun getAllInvoices(): Flow<List<InvoiceEntity>>

    @Query("SELECT * FROM shared_invoices WHERE divisionId = :divisionId ORDER BY createdAt DESC")
    fun getInvoicesByDivision(divisionId: String): Flow<List<InvoiceEntity>>

    @Query("SELECT * FROM shared_invoices WHERE invoiceId = :id")
    suspend fun getInvoiceById(id: String): InvoiceEntity?

    @Query("SELECT * FROM shared_invoices WHERE invoiceNumber = :num LIMIT 1")
    suspend fun getInvoiceByNumber(num: String): InvoiceEntity?

    @Query("SELECT * FROM shared_invoices WHERE customerId = :customerId ORDER BY createdAt DESC")
    suspend fun getInvoicesByCustomer(customerId: String): List<InvoiceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoice(invoice: InvoiceEntity)

    @Update
    suspend fun updateInvoice(invoice: InvoiceEntity)

    @Query("SELECT * FROM shared_payments WHERE invoiceId = :invoiceId ORDER BY paymentDate DESC")
    suspend fun getPaymentsForInvoice(invoiceId: String): List<PaymentEntity>

    @Query("SELECT * FROM shared_payments WHERE customerId = :customerId ORDER BY paymentDate DESC")
    suspend fun getPaymentsForCustomer(customerId: String): List<PaymentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: PaymentEntity)
}

@Dao
interface ApprovalAuditDao {
    @Query("SELECT * FROM approval_requests ORDER BY createdAt DESC")
    fun getAllApprovals(): Flow<List<ApprovalRequestEntity>>

    @Query("SELECT * FROM approval_requests WHERE status = 'PENDING' ORDER BY createdAt DESC")
    fun getPendingApprovals(): Flow<List<ApprovalRequestEntity>>

    @Query("SELECT * FROM approval_requests WHERE requestId = :id")
    suspend fun getApprovalById(id: String): ApprovalRequestEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApproval(req: ApprovalRequestEntity)

    @Update
    suspend fun updateApproval(req: ApprovalRequestEntity)

    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 500")
    fun getAllAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity)
}

@Dao
interface BaselineDao {
    // Phase 2A - BB Motors
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBBJobCard(jobCard: BBMotorJobCardEntity)

    @Query("SELECT * FROM bb_job_cards ORDER BY createdAt DESC")
    fun getAllBBJobCards(): Flow<List<BBMotorJobCardEntity>>

    @Query("SELECT * FROM bb_job_cards WHERE jobNumber = :num LIMIT 1")
    suspend fun getBBJobCardByNumber(num: String): BBMotorJobCardEntity?

    @Query("SELECT COUNT(*) FROM bb_job_cards")
    suspend fun getBBJobCardCount(): Int

    // Phase 2B - Renaissance Hotels
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRenaissanceReservation(reservation: RenaissanceReservationEntity)

    @Query("SELECT * FROM rh_reservations ORDER BY createdAt DESC")
    fun getAllRenaissanceReservations(): Flow<List<RenaissanceReservationEntity>>

    @Query("SELECT * FROM rh_reservations WHERE propertyLocation = :location AND status = 'CONFIRMED'")
    suspend fun getRenaissanceReservations(location: String): List<RenaissanceReservationEntity>

    @Query("SELECT COUNT(*) FROM rh_reservations")
    suspend fun getRenaissanceReservationCount(): Int
}
