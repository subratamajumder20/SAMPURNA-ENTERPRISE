package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// -------------------------------------------------------------
// Core / Shared Entities (Phase 1)
// -------------------------------------------------------------

@Entity(tableName = "shared_customers")
data class CustomerEntity(
    @PrimaryKey val customerId: String,
    val name: String,
    val phone: String,
    val alternatePhone: String? = null,
    val email: String? = null,
    val address: String? = null,
    val city: String? = null,
    val state: String? = null,
    val pincode: String? = null,
    val gstinOptional: String? = null,
    val customerType: String = "INDIVIDUAL", // INDIVIDUAL, BUSINESS, CORPORATE, GOVERNMENT, OTHER
    val notes: String? = null,
    val status: String = "ACTIVE",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "shared_suppliers")
data class SupplierEntity(
    @PrimaryKey val supplierId: String,
    val name: String,
    val phone: String,
    val email: String? = null,
    val address: String? = null,
    val gstin: String? = null,
    val productsSupplied: String? = null,
    val paymentTerms: String? = null,
    val status: String = "ACTIVE",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "approval_requests")
data class ApprovalRequestEntity(
    @PrimaryKey val requestId: String,
    val businessId: String,
    val divisionId: String?,
    val requestType: String,
    val entityType: String,
    val entityId: String,
    val requestedBy: String,
    val amount: Double = 0.0,
    val threshold: Double = 0.0,
    val details: String? = null,
    val status: String = "PENDING", // PENDING, APPROVED, REJECTED
    val reviewedBy: String? = null,
    val reviewedAt: Long? = null,
    val rejectionReason: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey val logId: String,
    val actorId: String,
    val actorName: String,
    val business: String,
    val division: String?,
    val entity: String,
    val entityId: String,
    val action: String,
    val details: String?,
    val result: String,
    val timestamp: Long = System.currentTimeMillis()
)

// -------------------------------------------------------------
// Sampurna Enterprise Entities (Phase 2C)
// -------------------------------------------------------------

@Entity(tableName = "enterprise_divisions")
data class EnterpriseDivisionEntity(
    @PrimaryKey val divisionId: String, // 'PRINTING', 'TRADING'
    val name: String,
    val description: String?,
    val status: String = "ACTIVE"
)

@Entity(tableName = "enterprise_categories")
data class EnterpriseCategoryEntity(
    @PrimaryKey val categoryId: String,
    val divisionId: String, // PRINTING, TRADING
    val name: String,
    val code: String,
    val description: String? = null,
    val status: String = "ACTIVE"
)

@Entity(tableName = "enterprise_products")
data class EnterpriseProductEntity(
    @PrimaryKey val productId: String,
    val divisionId: String, // PRINTING, TRADING
    val categoryId: String,
    val productCode: String,
    val name: String,
    val description: String? = null,
    val unit: String, // PCS, BOX, PACK, SHEET, BAG, TON, SQFT, MTR, KG
    val purchasePrice: Double = 0.0,
    val sellingPrice: Double = 0.0,
    val gstRate: Double = 18.0,
    val minimumStock: Double = 0.0,
    val reorderQuantity: Double = 0.0,
    val status: String = "ACTIVE",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "enterprise_rate_cards")
data class EnterpriseRateCardEntity(
    @PrimaryKey val rateCardId: String,
    val divisionId: String, // PRINTING, TRADING
    val productId: String,
    val paperType: String? = null,
    val paperSize: String? = null,
    val gsm: Int? = null,
    val colourMode: String? = null,
    val sideCount: Int = 1,
    val minQuantity: Int = 1,
    val maxQuantity: Int? = null,
    val baseRatePerUnit: Double,
    val setupCharge: Double = 0.0,
    val finishingRate: Double = 0.0,
    val bindingRate: Double = 0.0,
    val cuttingFoldingRate: Double = 0.0,
    val urgentSurchargeRate: Double = 25.0,
    val version: Int = 1,
    val isActive: Boolean = true,
    val effectiveFrom: Long = System.currentTimeMillis(),
    val effectiveTo: Long? = null,
    val createdBy: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "enterprise_rate_versions")
data class EnterpriseRateVersionEntity(
    @PrimaryKey val versionId: String,
    val rateCardId: String,
    val versionNumber: Int,
    val rateDataJson: String,
    val changedBy: String,
    val changeReason: String?,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "enterprise_quotations")
data class EnterpriseQuotationEntity(
    @PrimaryKey val quotationId: String,
    val quotationNumber: String, // SE-PRINT-QTN-2026-000001 or SE-TRD-QTN-2026-000001
    val customerId: String,
    val divisionId: String, // PRINTING, TRADING
    val rateCardVersionApplied: Int = 1,
    val validUntil: Long,
    val subtotal: Double,
    val discount: Double = 0.0,
    val taxableValue: Double,
    val cgst: Double = 0.0,
    val sgst: Double = 0.0,
    val igst: Double = 0.0,
    val tax: Double,
    val grandTotal: Double,
    val terms: String? = null,
    val notes: String? = null,
    val status: String = "DRAFT", // DRAFT, SENT, PENDING_APPROVAL, CUSTOMER_APPROVED, CUSTOMER_REJECTED, EXPIRED, CONVERTED, CANCELLED
    val approvalRequestId: String? = null,
    val createdBy: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "enterprise_quotation_items")
data class EnterpriseQuotationItemEntity(
    @PrimaryKey val quotationItemId: String,
    val quotationId: String,
    val productId: String,
    val productName: String,
    val description: String? = null,
    val specificationJson: String? = null,
    val quantity: Double,
    val unit: String,
    val unitPrice: Double,
    val discount: Double = 0.0,
    val taxRate: Double = 18.0,
    val taxableValue: Double,
    val cgst: Double = 0.0,
    val sgst: Double = 0.0,
    val igst: Double = 0.0,
    val tax: Double,
    val lineTotal: Double
)

@Entity(tableName = "enterprise_orders")
data class EnterpriseOrderEntity(
    @PrimaryKey val orderId: String,
    val orderNumber: String, // SE-PRINT-ORD-2026-000001 or SE-TRD-ORD-2026-000001
    val customerId: String,
    val divisionId: String, // PRINTING or TRADING
    val quotationId: String? = null,
    val orderDate: Long = System.currentTimeMillis(),
    val requiredDate: Long? = null,
    val priority: String = "NORMAL", // LOW, NORMAL, HIGH, URGENT
    val status: String, // Printing vs Trading pipeline
    val subtotal: Double,
    val discount: Double = 0.0,
    val taxableValue: Double,
    val tax: Double,
    val grandTotal: Double,
    val notes: String? = null,
    val createdBy: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "enterprise_order_items")
data class EnterpriseOrderItemEntity(
    @PrimaryKey val orderItemId: String,
    val orderId: String,
    val productId: String,
    val productName: String,
    val description: String? = null,
    val specificationJson: String? = null,
    val quantity: Double,
    val unit: String,
    val unitPrice: Double,
    val taxRate: Double = 18.0,
    val lineTotal: Double
)

@Entity(tableName = "enterprise_artworks")
data class EnterpriseArtworkEntity(
    @PrimaryKey val artworkId: String,
    val orderId: String,
    val fileName: String,
    val fileType: String,
    val storageReference: String,
    val version: Int = 1,
    val uploadedBy: String,
    val status: String = "PENDING", // NOT_REQUIRED, PENDING, UPLOADED, UNDER_REVIEW, CUSTOMER_REVIEW, APPROVED, REJECTED, REVISION_REQUIRED
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "enterprise_production_jobs")
data class EnterpriseProductionJobEntity(
    @PrimaryKey val productionJobId: String,
    val jobNumber: String, // SE-PRD-2026-000001
    val orderId: String,
    val divisionId: String = "PRINTING",
    val priority: String = "NORMAL", // LOW, NORMAL, HIGH, URGENT
    val assignedTo: String? = null,
    val plannedStart: Long? = null,
    val plannedCompletion: Long? = null,
    val actualStart: Long? = null,
    val actualCompletion: Long? = null,
    val status: String = "QUEUED", // QUEUED, ARTWORK_PENDING, MATERIAL_PENDING, READY_FOR_PRODUCTION, IN_PRODUCTION, PAUSED, QUALITY_CHECK, READY_FOR_PACKING, PACKED, READY_FOR_DELIVERY, COMPLETED, CANCELLED
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "enterprise_material_requirements")
data class EnterpriseMaterialRequirementEntity(
    @PrimaryKey val requirementId: String,
    val productionJobId: String,
    val materialId: String,
    val materialName: String,
    val quantityRequired: Double,
    val quantityReserved: Double = 0.0,
    val quantityIssued: Double = 0.0,
    val unit: String,
    val status: String = "REQUIRED", // REQUIRED, RESERVED, PARTIALLY_AVAILABLE, AVAILABLE, ISSUED, SHORTAGE
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "enterprise_inventory")
data class EnterpriseInventoryEntity(
    @PrimaryKey val inventoryId: String,
    val divisionId: String, // PRINTING or TRADING
    val productOrMaterialId: String,
    val name: String,
    val unit: String,
    val currentStock: Double = 0.0,
    val reservedStock: Double = 0.0,
    val availableStock: Double = 0.0,
    val minimumStock: Double = 0.0,
    val reorderQuantity: Double = 0.0,
    val location: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "enterprise_inventory_transactions")
data class EnterpriseInventoryTransactionEntity(
    @PrimaryKey val transactionId: String,
    val inventoryId: String,
    val divisionId: String,
    val transactionType: String, // PURCHASE, RESERVATION, RELEASE, ISSUE, RETURN, ADJUSTMENT_IN, ADJUSTMENT_OUT, SALE, DAMAGE, TRANSFER
    val quantity: Double,
    val stockBefore: Double,
    val stockAfter: Double,
    val referenceType: String? = null,
    val referenceId: String? = null,
    val notes: String? = null,
    val performedBy: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "enterprise_purchase_requests")
data class EnterprisePurchaseRequestEntity(
    @PrimaryKey val purchaseRequestId: String,
    val divisionId: String,
    val materialOrProductId: String,
    val materialName: String,
    val quantity: Double,
    val unit: String,
    val requiredBy: Long? = null,
    val productionJobId: String? = null,
    val priority: String = "NORMAL",
    val status: String = "PENDING_APPROVAL", // DRAFT, PENDING_APPROVAL, APPROVED, ORDERED, PARTIALLY_RECEIVED, RECEIVED, CANCELLED
    val approvalRequestId: String? = null,
    val notes: String? = null,
    val requestedBy: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "enterprise_purchase_orders")
data class EnterprisePurchaseOrderEntity(
    @PrimaryKey val purchaseOrderId: String,
    val poNumber: String, // SE-PO-2026-000001
    val divisionId: String,
    val supplierId: String,
    val supplierName: String,
    val itemsJson: String,
    val quantity: Double,
    val subtotal: Double,
    val tax: Double,
    val total: Double,
    val expectedDelivery: Long? = null,
    val status: String = "DRAFT", // DRAFT, PENDING_APPROVAL, APPROVED, ORDERED, PARTIALLY_RECEIVED, RECEIVED, CANCELLED
    val createdBy: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "enterprise_goods_receipts")
data class EnterpriseGoodsReceiptEntity(
    @PrimaryKey val receiptId: String,
    val receiptNumber: String, // SE-GRN-2026-000001
    val purchaseOrderId: String,
    val inventoryId: String,
    val quantityReceived: Double,
    val unit: String,
    val receivedBy: String,
    val notes: String? = null,
    val receivedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "enterprise_quality_checks")
data class EnterpriseQualityCheckEntity(
    @PrimaryKey val qcId: String,
    val productionJobId: String,
    val orderId: String,
    val checklistResultsJson: String,
    val checkedBy: String,
    val status: String = "PENDING", // PENDING, PASSED, FAILED, REWORK_REQUIRED
    val remarks: String? = null,
    val checkedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "enterprise_rework")
data class EnterpriseReworkEntity(
    @PrimaryKey val reworkId: String,
    val productionJobId: String,
    val qcId: String,
    val reason: String,
    val failedItemsCount: Int,
    val responsibleStage: String,
    val reworkCount: Int = 1,
    val notes: String? = null,
    val createdBy: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "enterprise_packing")
data class EnterprisePackingEntity(
    @PrimaryKey val packingId: String,
    val orderId: String,
    val quantity: Double,
    val packageCount: Int = 1,
    val packedBy: String,
    val packedAt: Long = System.currentTimeMillis(),
    val notes: String? = null,
    val status: String = "COMPLETED"
)

@Entity(tableName = "enterprise_deliveries")
data class EnterpriseDeliveryEntity(
    @PrimaryKey val deliveryId: String,
    val deliveryNumber: String, // SE-DEL-2026-000001
    val orderId: String,
    val customerId: String,
    val customerName: String,
    val deliveryAddress: String,
    val deliveryMethod: String = "COMPANY_DELIVERY", // CUSTOMER_PICKUP, COMPANY_DELIVERY, COURIER, TRANSPORT, OTHER
    val deliveryPerson: String? = null,
    val vehicleOptional: String? = null,
    val scheduledDate: Long? = null,
    val actualDate: Long? = null,
    val status: String = "PENDING", // PENDING, SCHEDULED, OUT_FOR_DELIVERY, DELIVERED, FAILED, CANCELLED
    val proofReferenceOptional: String? = null,
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "shared_invoices")
data class InvoiceEntity(
    @PrimaryKey val invoiceId: String,
    val invoiceNumber: String, // SE-PRINT-INV-2026-000001 or SE-TRD-INV-2026-000001
    val businessId: String,
    val divisionId: String?,
    val orderId: String?,
    val quotationId: String?,
    val customerId: String,
    val customerName: String,
    val invoiceDate: Long = System.currentTimeMillis(),
    val subtotal: Double,
    val discount: Double = 0.0,
    val taxableValue: Double,
    val cgst: Double = 0.0,
    val sgst: Double = 0.0,
    val igst: Double = 0.0,
    val totalTax: Double,
    val grandTotal: Double,
    val balanceDue: Double,
    val status: String = "UNPAID", // UNPAID, PARTIALLY_PAID, PAID, CANCELLED
    val createdBy: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "shared_payments")
data class PaymentEntity(
    @PrimaryKey val paymentId: String,
    val invoiceId: String,
    val customerId: String,
    val amount: Double,
    val paymentMethod: String, // CASH, UPI, CARD, BANK_TRANSFER, OTHER
    val referenceNumber: String? = null,
    val notes: String? = null,
    val receivedBy: String,
    val paymentDate: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis()
)

// -------------------------------------------------------------
// Baseline Entities for Phase 2A & 2B Multi-Business Verification
// -------------------------------------------------------------

@Entity(tableName = "bb_job_cards")
data class BBMotorJobCardEntity(
    @PrimaryKey val jobCardId: String,
    val jobNumber: String, // BB-JC-2026-000001
    val customerId: String,
    val vehicleRegNo: String,
    val status: String = "OPEN",
    val estimatedCost: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "rh_reservations")
data class RenaissanceReservationEntity(
    @PrimaryKey val reservationId: String,
    val reservationNumber: String, // RH-RES-2026-000001
    val propertyLocation: String, // Puri, Bhubaneswar
    val roomType: String,
    val customerId: String,
    val status: String = "CONFIRMED",
    val totalAmount: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)
