package com.example.core.audit

enum class AuditAction {
    CREATE_CUSTOMER,
    UPDATE_CUSTOMER,
    CREATE_PRODUCT,
    UPDATE_PRODUCT,
    RATE_CHANGE,
    CREATE_QUOTATION,
    APPROVE_QUOTATION,
    REJECT_QUOTATION,
    CREATE_ORDER,
    UPDATE_ORDER,
    CREATE_PRODUCTION_JOB,
    UPDATE_PRODUCTION_STATUS,
    ARTWORK_UPLOADED,
    ARTWORK_APPROVED,
    ARTWORK_REJECTED,
    RESERVE_MATERIAL,
    ISSUE_MATERIAL,
    INVENTORY_ADJUSTMENT,
    CREATE_PURCHASE_REQUEST,
    APPROVE_PURCHASE,
    RECEIVE_STOCK,
    QUALITY_CHECK,
    REWORK,
    PACK_ORDER,
    CREATE_DELIVERY,
    DELIVERY_COMPLETED,
    CREATE_INVOICE,
    RECORD_PAYMENT,
    REFUND,
    CANCEL_ORDER
}

data class AuditRecord(
    val id: String,
    val actorId: String,
    val actorName: String,
    val business: String,
    val division: String?,
    val entity: String,
    val entityId: String,
    val action: AuditAction,
    val details: String?,
    val result: String, // SUCCESS, FAILED, REJECTED
    val timestamp: Long = System.currentTimeMillis()
)
