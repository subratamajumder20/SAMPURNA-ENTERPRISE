package com.example.core.financial

import kotlin.math.round

data class PrintSpecification(
    val paperType: String = "Art Card",
    val paperSize: String = "Standard",
    val finishedSize: String = "3.5x2 inch",
    val gsm: Int = 300,
    val colourMode: String = "CMYK", // CMYK, SINGLE_COLOUR, B_AND_W
    val sideCount: Int = 1, // 1 = Single, 2 = Double
    val lamination: String = "None", // None, Gloss, Matte, Soft Touch, Velvet
    val binding: String = "None", // None, Saddle Stitch, Perfect, Spiral, Wiro
    val cutting: String = "Standard", // Standard, Die Cut
    val folding: String = "None", // None, Half Fold, Tri Fold
    val quantity: Int = 100,
    val finishing: String = "None", // Spot UV, Foil Stamping, Embossing
    val designRequired: Boolean = false,
    val artworkRequired: Boolean = true,
    val isUrgent: Boolean = false
)

data class TaxBreakdown(
    val subtotal: Double,
    val discountPercent: Double,
    val discountAmount: Double,
    val taxableValue: Double,
    val gstRate: Double,
    val isInterState: Boolean = false,
    val cgst: Double,
    val sgst: Double,
    val igst: Double,
    val totalTax: Double,
    val grandTotal: Double
)

object DeterministicFinancialEngine {

    fun round2(value: Double): Double {
        return round(value * 100.0) / 100.0
    }

    /**
     * Reusable, deterministic GST & Tax calculation engine
     * Never relies on LLM arithmetic
     */
    fun calculateTax(
        subtotal: Double,
        discountPercent: Double,
        gstRate: Double,
        isInterState: Boolean = false
    ): TaxBreakdown {
        val sanitizedSubtotal = maxOf(0.0, round2(subtotal))
        val sanitizedDiscountPercent = maxOf(0.0, minOf(100.0, discountPercent))
        val discountAmount = round2(sanitizedSubtotal * (sanitizedDiscountPercent / 100.0))
        val taxableValue = round2(sanitizedSubtotal - discountAmount)

        val totalTax = round2(taxableValue * (gstRate / 100.0))
        val cgst: Double
        val sgst: Double
        val igst: Double

        if (isInterState) {
            cgst = 0.0
            sgst = 0.0
            igst = totalTax
        } else {
            cgst = round2(totalTax / 2.0)
            sgst = round2(totalTax - cgst) // Ensure cgst + sgst == totalTax precisely
            igst = 0.0
        }

        val grandTotal = round2(taxableValue + totalTax)

        return TaxBreakdown(
            subtotal = sanitizedSubtotal,
            discountPercent = sanitizedDiscountPercent,
            discountAmount = discountAmount,
            taxableValue = taxableValue,
            gstRate = gstRate,
            isInterState = isInterState,
            cgst = cgst,
            sgst = sgst,
            igst = igst,
            totalTax = totalTax,
            grandTotal = grandTotal
        )
    }

    /**
     * Deterministic print calculation engine based on rate card parameters
     */
    fun calculatePrintItemCost(
        spec: PrintSpecification,
        baseRatePerUnit: Double,
        setupCharge: Double = 0.0,
        laminationUnitRate: Double = 0.0,
        bindingUnitRate: Double = 0.0,
        urgentSurchargePercent: Double = 25.0
    ): Double {
        val qty = maxOf(1, spec.quantity)
        var unitPrice = baseRatePerUnit

        // Factor in double-side multiplier
        if (spec.sideCount == 2) {
            unitPrice *= 1.65 // Deterministic double-side multiplier
        }

        // GSM adjustment factor
        if (spec.gsm > 300) {
            unitPrice += 0.50
        } else if (spec.gsm > 200) {
            unitPrice += 0.25
        }

        // Lamination addition
        if (spec.lamination != "None") {
            val laminationCost = if (laminationUnitRate > 0) laminationUnitRate else 0.40
            unitPrice += laminationCost * spec.sideCount
        }

        // Binding addition
        if (spec.binding != "None") {
            val bindingCost = if (bindingUnitRate > 0) bindingUnitRate else 2.50
            unitPrice += bindingCost
        }

        // Quantity slab discount (economies of scale)
        val slabFactor = when {
            qty >= 5000 -> 0.70
            qty >= 2000 -> 0.80
            qty >= 1000 -> 0.88
            qty >= 500 -> 0.94
            else -> 1.0
        }
        unitPrice *= slabFactor

        // Design fee if required
        val designFee = if (spec.designRequired) 350.0 else 0.0

        // Subtotal before urgent surcharge
        var total = (unitPrice * qty) + setupCharge + designFee

        // Urgent surcharge
        if (spec.isUrgent) {
            total += total * (urgentSurchargePercent / 100.0)
        }

        return round2(total)
    }
}
