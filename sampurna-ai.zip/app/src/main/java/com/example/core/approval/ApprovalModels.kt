package com.example.core.approval

import com.example.core.auth.UserRole
import com.example.core.auth.UserSession

enum class ApprovalType(val displayName: String, val thresholdAmount: Double) {
    LARGE_DISCOUNT("Discount > 10%", 10.0),
    PURCHASE_ORDER("Purchase Order > ₹25,000", 25000.0),
    INVENTORY_ADJUSTMENT("Manual Inventory Write-Off / Adjustment", 0.0),
    REFUND("Customer Refund", 0.0),
    CREDIT_SALE("Credit Sale > ₹50,000", 50000.0),
    URGENT_PRODUCTION("Urgent Production Priority Fee Waiver", 0.0),
    INVOICE_CANCELLATION("Invoice Cancellation", 0.0)
}

enum class ApprovalStatus {
    PENDING,
    APPROVED,
    REJECTED
}

data class ApprovalDecision(
    val requiresApproval: Boolean,
    val reason: String? = null,
    val approvalType: ApprovalType? = null
)

object ApprovalEngine {

    // Threshold rules
    private const val MAX_UNAPPROVED_DISCOUNT_PERCENT = 10.0
    private const val MAX_UNAPPROVED_PO_AMOUNT = 25000.0
    private const val MAX_UNAPPROVED_CREDIT_AMOUNT = 50000.0

    fun checkDiscountApproval(discountPercent: Double, user: UserSession): ApprovalDecision {
        if (discountPercent > MAX_UNAPPROVED_DISCOUNT_PERCENT) {
            if (user.role == UserRole.OWNER || user.role == UserRole.ADMIN) {
                return ApprovalDecision(requiresApproval = false, reason = "Authorized by ${user.role}")
            }
            return ApprovalDecision(
                requiresApproval = true,
                reason = "Discount of ${discountPercent}% exceeds maximum threshold of ${MAX_UNAPPROVED_DISCOUNT_PERCENT}%",
                approvalType = ApprovalType.LARGE_DISCOUNT
            )
        }
        return ApprovalDecision(requiresApproval = false)
    }

    fun checkPurchaseOrderApproval(amount: Double, user: UserSession): ApprovalDecision {
        if (amount > MAX_UNAPPROVED_PO_AMOUNT) {
            if (user.role == UserRole.OWNER || user.role == UserRole.ADMIN) {
                return ApprovalDecision(requiresApproval = false, reason = "Authorized by ${user.role}")
            }
            return ApprovalDecision(
                requiresApproval = true,
                reason = "Purchase order amount ₹$amount exceeds threshold of ₹$MAX_UNAPPROVED_PO_AMOUNT",
                approvalType = ApprovalType.PURCHASE_ORDER
            )
        }
        return ApprovalDecision(requiresApproval = false)
    }

    fun checkInventoryAdjustmentApproval(user: UserSession): ApprovalDecision {
        if (user.role == UserRole.OWNER || user.role == UserRole.ADMIN) {
            return ApprovalDecision(requiresApproval = false)
        }
        return ApprovalDecision(
            requiresApproval = true,
            reason = "Manual inventory adjustment requires manager/owner approval",
            approvalType = ApprovalType.INVENTORY_ADJUSTMENT
        )
    }

    fun canApprove(user: UserSession, approvalType: ApprovalType): Boolean {
        return user.role in listOf(UserRole.OWNER, UserRole.ADMIN, UserRole.MANAGER)
    }
}
