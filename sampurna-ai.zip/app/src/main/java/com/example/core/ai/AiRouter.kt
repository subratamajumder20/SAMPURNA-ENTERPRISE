package com.example.core.ai

import com.example.core.auth.BusinessTenant
import com.example.core.auth.DivisionTenant

enum class RoutingTarget(val business: BusinessTenant, val division: DivisionTenant?, val description: String) {
    SAMPURNA_ENTERPRISE_PRINTING(BusinessTenant.SAMPURNA_ENTERPRISE, DivisionTenant.PRINTING, "Printing & Digital Services"),
    SAMPURNA_ENTERPRISE_TRADING(BusinessTenant.SAMPURNA_ENTERPRISE, DivisionTenant.TRADING, "Building & Trading Materials"),
    BB_MOTORS(BusinessTenant.BB_MOTORS, null, "B.B. Motors Automotive Services"),
    RENAISSANCE_HOTELS(BusinessTenant.RENAISSANCE_HOTELS, null, "Renaissance Hotels & Hospitality"),
    SAMPURNA_FINANCIAL(BusinessTenant.SAMPURNA_FINANCIAL, null, "Sampurna Financial Management"),
    UNKNOWN(BusinessTenant.ALL, null, "General / Undetermined")
}

data class RoutingResult(
    val target: RoutingTarget,
    val confidence: Double,
    val matchedKeywords: List<String>,
    val actionSuggested: String
)

object AiRouter {

    private fun matchesKeyword(text: String, keyword: String): Boolean {
        val pattern = "\\b${Regex.escape(keyword.lowercase())}\\b"
        return Regex(pattern, RegexOption.IGNORE_CASE).containsMatchIn(text)
    }

    fun routeQuery(query: String): RoutingResult {
        val lower = query.lowercase().trim()

        // 1. BB Motors keywords (automotive)
        val bbMotorsKeywords = listOf(
            "honda", "car", "cars", "job card", "vehicle", "mechanic",
            "brake", "servicing", "garage", "workshop", "engine oil", "odometer", "automobile"
        )
        val bbMatches = bbMotorsKeywords.filter { matchesKeyword(lower, it) }
        if (bbMatches.isNotEmpty()) {
            return RoutingResult(
                target = RoutingTarget.BB_MOTORS,
                confidence = 0.95,
                matchedKeywords = bbMatches,
                actionSuggested = "Route to B.B. Motors Workshop Job Cards & Vehicle Fleet System"
            )
        }

        // 2. Renaissance Hotels keywords (hospitality)
        val hotelKeywords = listOf(
            "room", "rooms", "hotel", "hotels", "puri", "bhubaneswar",
            "resort", "suite", "suites", "check-in", "check-out", "booking", "guest", "hospitality"
        )
        val hotelMatches = hotelKeywords.filter { matchesKeyword(lower, it) }
        if (hotelMatches.isNotEmpty()) {
            return RoutingResult(
                target = RoutingTarget.RENAISSANCE_HOTELS,
                confidence = 0.95,
                matchedKeywords = hotelMatches,
                actionSuggested = "Route to Renaissance Hotels Reservation & Guest Folio System"
            )
        }

        // 3. Printing Division keywords (printing & digital)
        val printKeywords = listOf(
            "card", "cards", "visiting card", "visiting cards", "letterhead", "letterheads",
            "brochure", "brochures", "flyer", "flyers", "banner", "banners", "poster", "posters",
            "pvc", "artwork", "print", "printing", "gsm", "lamination", "offset", "binding"
        )
        val printMatches = printKeywords.filter { matchesKeyword(lower, it) }
        if (printMatches.isNotEmpty()) {
            return RoutingResult(
                target = RoutingTarget.SAMPURNA_ENTERPRISE_PRINTING,
                confidence = 0.95,
                matchedKeywords = printMatches,
                actionSuggested = "Route to Sampurna Enterprise / Division A: Printing & Digital Services"
            )
        }

        // 4. Trading Division keywords (commodities & building materials)
        val tradingKeywords = listOf(
            "cement", "steel", "tmt", "sand", "aggregate", "rebar", "bag", "bags",
            "ton", "tons", "plywood", "hardware", "trading stock", "building material", "construction material"
        )
        val tradingMatches = tradingKeywords.filter { matchesKeyword(lower, it) }
        if (tradingMatches.isNotEmpty()) {
            return RoutingResult(
                target = RoutingTarget.SAMPURNA_ENTERPRISE_TRADING,
                confidence = 0.95,
                matchedKeywords = tradingMatches,
                actionSuggested = "Route to Sampurna Enterprise / Division B: Building & Trading Materials"
            )
        }

        return RoutingResult(
            target = RoutingTarget.UNKNOWN,
            confidence = 0.40,
            matchedKeywords = emptyList(),
            actionSuggested = "General enterprise query or clarification required"
        )
    }
}
