package com.example.core.auth

enum class UserRole(val displayName: String, val level: Int) {
    OWNER("Owner", 100),
    ADMIN("Administrator", 90),
    MANAGER("General Manager", 80),
    SALES("Sales Executive", 50),
    PRODUCTION_MANAGER("Production Manager", 60),
    DESIGNER("Graphic Designer", 40),
    STORE_KEEPER("Store Keeper", 50),
    PURCHASE("Purchase Officer", 50),
    DELIVERY("Delivery Agent", 30),
    ACCOUNTANT("Accountant", 70),
    READ_ONLY("Read Only Auditor", 10)
}

enum class BusinessTenant(val code: String, val displayName: String) {
    ALL("ALL", "All Businesses (Owner View)"),
    SAMPURNA_ENTERPRISE("SAMPURNA_ENTERPRISE", "Sampurna Enterprise"),
    BB_MOTORS("BB_MOTORS", "B.B. Motors"),
    RENAISSANCE_HOTELS("RENAISSANCE_HOTELS", "Renaissance Hotels"),
    SAMPURNA_FINANCIAL("SAMPURNA_FINANCIAL", "Sampurna Financial")
}

enum class DivisionTenant(val code: String, val displayName: String) {
    BOTH("BOTH", "Consolidated (All Divisions)"),
    PRINTING("PRINTING", "Division A: Printing & Digital Services"),
    TRADING("TRADING", "Division B: Building & Trading Materials")
}

data class UserSession(
    val userId: String,
    val name: String,
    val email: String,
    val role: UserRole,
    val allowedBusiness: BusinessTenant = BusinessTenant.SAMPURNA_ENTERPRISE,
    val allowedDivision: DivisionTenant = DivisionTenant.BOTH
)

object RBACManager {

    fun hasPermission(user: UserSession, permission: String): Boolean {
        // Owner and Admin have all permissions
        if (user.role == UserRole.OWNER || user.role == UserRole.ADMIN) return true

        return when (permission) {
            "enterprise:read" -> true
            "enterprise:write" -> user.role in listOf(UserRole.MANAGER, UserRole.SALES, UserRole.PRODUCTION_MANAGER, UserRole.STORE_KEEPER, UserRole.PURCHASE)
            "customer:read" -> true
            "customer:write" -> user.role in listOf(UserRole.MANAGER, UserRole.SALES, UserRole.ACCOUNTANT)
            "quotation:read" -> true
            "quotation:create" -> user.role in listOf(UserRole.MANAGER, UserRole.SALES)
            "quotation:approve" -> user.role in listOf(UserRole.MANAGER)
            "production:read" -> user.role in listOf(UserRole.MANAGER, UserRole.PRODUCTION_MANAGER, UserRole.DESIGNER, UserRole.STORE_KEEPER, UserRole.SALES)
            "production:write" -> user.role in listOf(UserRole.MANAGER, UserRole.PRODUCTION_MANAGER, UserRole.DESIGNER)
            "artwork:approve" -> user.role in listOf(UserRole.MANAGER, UserRole.PRODUCTION_MANAGER, UserRole.SALES)
            "inventory:read" -> true
            "inventory:write" -> user.role in listOf(UserRole.MANAGER, UserRole.STORE_KEEPER, UserRole.PURCHASE)
            "inventory:adjust" -> user.role in listOf(UserRole.MANAGER) // Sensitive
            "purchase:read" -> true
            "purchase:create" -> user.role in listOf(UserRole.MANAGER, UserRole.STORE_KEEPER, UserRole.PURCHASE)
            "purchase:approve" -> user.role in listOf(UserRole.MANAGER)
            "qc:record" -> user.role in listOf(UserRole.MANAGER, UserRole.PRODUCTION_MANAGER)
            "delivery:read" -> true
            "delivery:write" -> user.role in listOf(UserRole.MANAGER, UserRole.DELIVERY, UserRole.STORE_KEEPER)
            "finance:read" -> user.role in listOf(UserRole.MANAGER, UserRole.ACCOUNTANT)
            "finance:write" -> user.role in listOf(UserRole.MANAGER, UserRole.ACCOUNTANT)
            "rate_card:manage" -> user.role in listOf(UserRole.MANAGER)
            else -> false
        }
    }

    fun canAccessDivision(user: UserSession, targetDivision: String): Boolean {
        if (user.role == UserRole.OWNER || user.role == UserRole.ADMIN) return true
        if (user.allowedDivision == DivisionTenant.BOTH) return true
        return user.allowedDivision.name.equals(targetDivision, ignoreCase = true)
    }

    fun canAccessBusiness(user: UserSession, targetBusiness: BusinessTenant): Boolean {
        if (user.role == UserRole.OWNER) return true
        if (user.allowedBusiness == BusinessTenant.ALL) return true
        return user.allowedBusiness == targetBusiness
    }
}
