package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.core.auth.DivisionTenant
import com.example.data.model.InvoiceEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.SampurnaViewModel

@Composable
fun InvoicesScreen(
    viewModel: SampurnaViewModel
) {
    val invoices by viewModel.invoices.collectAsState()
    val division by viewModel.selectedDivision.collectAsState()

    var paymentTargetInvoice by remember { mutableStateOf<InvoiceEntity?>(null) }

    val filteredInvoices = if (division == DivisionTenant.BOTH) {
        invoices
    } else {
        invoices.filter { it.divisionId == division.name }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("invoices_screen")
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Invoices & Collections",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "GST Invoicing & Overpayment Prevention Guard",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (filteredInvoices.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No invoices generated yet for ${division.name}", color = TextSecondary)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredInvoices) { inv ->
                    InvoiceCard(
                        invoice = inv,
                        onRecordPayment = { paymentTargetInvoice = inv }
                    )
                }
            }
        }
    }

    // Payment Dialog
    paymentTargetInvoice?.let { inv ->
        RecordPaymentDialog(
            invoice = inv,
            onDismiss = { paymentTargetInvoice = null },
            onSubmit = { amount, method, ref ->
                viewModel.recordPayment(inv.invoiceId, amount, method, ref)
                paymentTargetInvoice = null
            }
        )
    }
}

@Composable
fun InvoiceCard(
    invoice: InvoiceEntity,
    onRecordPayment: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SlateCard),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SlateBorder, RoundedCornerShape(10.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = invoice.invoiceNumber,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = PrimarySkyLight
                    )
                    Text(
                        text = "Customer: ${invoice.customerName} • Div: ${invoice.divisionId}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }

                Surface(
                    color = if (invoice.status == "PAID") SuccessEmerald.copy(alpha = 0.2f) else AccentAmber.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = invoice.status,
                        color = if (invoice.status == "PAID") SuccessEmerald else AccentAmber,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = SlateBorder)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Total Amount", fontSize = 10.sp, color = TextMuted)
                    Text("₹${invoice.grandTotal}", fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                }
                Column {
                    Text("Tax Amount", fontSize = 10.sp, color = TextMuted)
                    Text("₹${invoice.totalTax}", fontSize = 12.sp, color = TextSecondary)
                }
                Column {
                    Text("Balance Due", fontSize = 10.sp, color = TextMuted)
                    Text(
                        "₹${invoice.balanceDue}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (invoice.balanceDue > 0) DangerRose else SuccessEmerald
                    )
                }

                if (invoice.balanceDue > 0) {
                    Button(
                        onClick = onRecordPayment,
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("Record Payment", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun RecordPaymentDialog(
    invoice: InvoiceEntity,
    onDismiss: () -> Unit,
    onSubmit: (Double, String, String?) -> Unit
) {
    var amountText by remember { mutableStateOf("${invoice.balanceDue}") }
    var selectedMethod by remember { mutableStateOf("UPI") }
    var refNumber by remember { mutableStateOf("UPI-${System.currentTimeMillis().toString().takeLast(6)}") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Record Customer Payment",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Invoice: ${invoice.invoiceNumber} • Remaining: ₹${invoice.balanceDue}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it
                        val parsed = it.toDoubleOrNull() ?: 0.0
                        if (parsed > invoice.balanceDue) {
                            errorMessage = "Overpayment prevented: Cannot pay more than balance ₹${invoice.balanceDue}"
                        } else {
                            errorMessage = null
                        }
                    },
                    label = { Text("Payment Amount (₹)") },
                    modifier = Modifier.fillMaxWidth()
                )

                errorMessage?.let {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(it, color = DangerRose, fontSize = 11.sp)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text("Payment Method", fontSize = 11.sp, color = TextSecondary)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("UPI", "CASH", "BANK_TRANSFER", "CARD").forEach { m ->
                        FilterChip(
                            selected = selectedMethod == m,
                            onClick = { selectedMethod = m },
                            label = { Text(m, fontSize = 10.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = refNumber,
                    onValueChange = { refNumber = it },
                    label = { Text("Reference / UTR Number") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        onClick = {
                            val parsed = amountText.toDoubleOrNull() ?: 0.0
                            if (parsed <= 0 || parsed > invoice.balanceDue) {
                                errorMessage = "Invalid payment amount"
                            } else {
                                onSubmit(parsed, selectedMethod, refNumber.ifBlank { null })
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald),
                        modifier = Modifier.weight(1f)
                    ) { Text("Confirm Payment") }
                }
            }
        }
    }
}
