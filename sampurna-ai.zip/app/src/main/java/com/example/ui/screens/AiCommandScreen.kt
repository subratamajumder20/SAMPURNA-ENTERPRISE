package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.AiChatMessage
import com.example.ui.viewmodel.SampurnaViewModel
import kotlinx.coroutines.launch

@Composable
fun AiCommandScreen(
    viewModel: SampurnaViewModel
) {
    val messages by viewModel.chatMessages.collectAsState()
    var inputQuery by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    val suggestedPrompts = listOf(
        "Make a quotation for 500 visiting cards.",
        "Do we have 20 bags of cement?",
        "Create a job card for my Honda.",
        "How many rooms are available in Puri?",
        "Give me today's Sampurna Enterprise report."
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("ai_command_screen")
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "AI COO Intelligent Router & Console",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Multi-Business Routing • Strict Truth Standard Active",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            Surface(
                color = AccentAmber.copy(alpha = 0.15f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Verified, contentDescription = null, tint = AccentAmber, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Zero Hallucinations", color = AccentAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Suggested Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            suggestedPrompts.forEach { prompt ->
                SuggestionChip(
                    onClick = {
                        viewModel.sendAiQuery(prompt)
                        scope.launch {
                            listState.animateScrollToItem(messages.size)
                        }
                    },
                    label = { Text(prompt, fontSize = 11.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Chat Message List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(messages) { msg ->
                ChatMessageCard(msg)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Query Input Field
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputQuery,
                onValueChange = { inputQuery = it },
                placeholder = { Text("Ask AI COO or enter command...") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_input_field"),
                shape = RoundedCornerShape(12.dp),
                maxLines = 2
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    if (inputQuery.isNotBlank()) {
                        viewModel.sendAiQuery(inputQuery)
                        inputQuery = ""
                        scope.launch {
                            listState.animateScrollToItem(messages.size)
                        }
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .background(PrimarySky, RoundedCornerShape(12.dp))
                    .testTag("ai_send_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
            }
        }
    }
}

@Composable
fun ChatMessageCard(msg: AiChatMessage) {
    val isUser = msg.sender == "USER"

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (isUser) PrimarySky.copy(alpha = 0.2f) else SlateCard
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .widthIn(max = 340.dp)
                .border(
                    1.dp,
                    if (isUser) PrimarySky.copy(alpha = 0.5f) else SlateBorder,
                    RoundedCornerShape(12.dp)
                )
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (isUser) "Operator" else "SAMPURNA AI COO",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = if (isUser) PrimarySkyLight else AccentAmber
                    )

                    msg.businessTag?.let { tag ->
                        Surface(
                            color = SlateBorder,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = tag,
                                fontSize = 9.sp,
                                color = TextSecondary,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = msg.text,
                    fontSize = 13.sp,
                    color = TextPrimary
                )

                // Detailed Output Breakdown (Section 71)
                if (!isUser && msg.dataSource != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(8.dp))

                    Text("DATA SOURCE / CONTEXT:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                    Text(msg.dataSource, fontSize = 10.sp, color = TextSecondary)

                    msg.actionAvailable?.let { action ->
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("ACTION AVAILABLE:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                        Text(action, fontSize = 10.sp, color = PrimarySkyLight)
                    }

                    msg.approvalRequired?.let { app ->
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("APPROVAL REQUIRED:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                        Text(app, fontSize = 10.sp, color = if (app != "None") AccentAmber else TextSecondary)
                    }
                }
            }
        }
    }
}
