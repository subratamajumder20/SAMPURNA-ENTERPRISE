package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.core.auth.DivisionTenant
import com.example.core.financial.DeterministicFinancialEngine
import com.example.core.financial.PrintSpecification
import com.example.data.model.EnterpriseProductEntity
import com.example.data.model.EnterpriseQuotationEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.SampurnaViewModel

@Composable
fun QuotationScreen(
    viewModel: SampurnaViewModel
) {
    val quotations by viewModel.quotations.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val products by viewModel.repo.getAllProducts().collectAsState(initial = emptyList())
    val division by viewModel.selectedDivision.collectAsState()

    var showCreateDialog by remember { mutableStateOf(false) }

    val filteredQuotes = if (division == DivisionTenant.BOTH) quotations else quotations.filter { it.divisionId == division.name }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("quotation_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Quotations (${filteredQuotes.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Deterministic Pricing & GST Engine",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }

                Button(
                    onClick = { showCreateDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimarySky),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("btn_open_quote_builder")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("New Quotation", fontSize = 13.sp)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (filteredQuotes.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.RequestQuote, contentDescription = null, tint = TextMuted, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No quotations created yet", color = TextSecondary, fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Click 'New Quotation' to build a deterministic print or trading quotation.", color = TextMuted, fontSize = 12.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredQuotes) { quote ->
                        QuotationCard(
                            quote = quote,
                            onApprove = { viewModel.approveQuotation(quote.quotationId) },
                            onConvert = { viewModel.convertQuotationToOrder(quote.quotationId) }
                        )
                    }
                }
            }
        }

        if (showCreateDialog) {
            QuotationBuilderDialog(
                products = products,
                customers = customers,
                defaultDivision = if (division == DivisionTenant.TRADING) "TRADING" else "PRINTING",
                onDismiss = { showCreateDialog = false },
                onCreatePrint = { customerId, prodId, spec, discount ->
                    viewModel.createPrintQuotation(customerId, prodId, spec, discount)
                    showCreateDialog = false
                },
                onCreateTrading = { customerId, items, discount ->
                    viewModel.createTradingQuotation(customerId, items, discount)
                    showCreateDialog = false
                }
            )
        }
    }
}

@Composable
fun QuotationCard(
    quote: EnterpriseQuotationEntity,
    onApprove: () -> Unit,
    onConvert: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SlateCard),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SlateBorder, RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = quote.quotationNumber,
                        fontWeight = FontWeight.Bold,
                        color = PrimarySkyLight,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Division: ${quote.divisionId} • Rate Ver: v${quote.rateCardVersionApplied}",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                StatusBadge(status = quote.status)
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = SlateBorder)
            Spacer(modifier = Modifier.height(12.dp))

            // Financial Breakdown
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Subtotal", fontSize = 11.sp, color = TextMuted)
                    Text("₹${quote.subtotal}", fontSize = 12.sp, color = TextSecondary)
                }
                Column {
                    Text("Discount", fontSize = 11.sp, color = TextMuted)
                    Text("₹${quote.discount}", fontSize = 12.sp, color = if (quote.discount > 0) DangerRose else TextSecondary)
                }
                Column {
                    Text("GST (CGST+SGST/IGST)", fontSize = 11.sp, color = TextMuted)
                    Text("₹${quote.tax}", fontSize = 12.sp, color = TextSecondary)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Grand Total", fontSize = 11.sp, color = TextMuted)
                    Text("₹${quote.grandTotal}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = SuccessEmerald)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (quote.status in listOf("DRAFT", "PENDING_APPROVAL", "SENT")) {
                    Button(
                        onClick = onApprove,
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(if (quote.status == "PENDING_APPROVAL") "Approve Discount" else "Customer Approved", fontSize = 12.sp)
                    }
                } else if (quote.status == "CUSTOMER_APPROVED") {
                    Button(
                        onClick = onConvert,
                        colors = ButtonDefaults.buttonColors(containerColor = PrimarySky),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Convert to Order", fontSize = 12.sp)
                    }
                } else if (quote.status == "CONVERTED") {
                    Text("Converted to Order ✓", color = SuccessEmerald, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
fun StatusBadge(status: String) {
    val (bgColor, textColor) = when (status) {
        "DRAFT" -> SlateBorder to TextSecondary
        "SENT" -> PrimarySky.copy(alpha = 0.2f) to PrimarySkyLight
        "PENDING_APPROVAL" -> AccentAmber.copy(alpha = 0.2f) to AccentAmber
        "CUSTOMER_APPROVED" -> SuccessEmerald.copy(alpha = 0.2f) to SuccessEmerald
        "CONVERTED" -> SuccessEmerald.copy(alpha = 0.3f) to SuccessEmerald
        else -> SlateBorder to TextSecondary
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(6.dp)
    ) {
        Text(
            text = status,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuotationBuilderDialog(
    products: List<EnterpriseProductEntity>,
    customers: List<com.example.data.model.CustomerEntity>,
    defaultDivision: String,
    onDismiss: () -> Unit,
    onCreatePrint: (customerId: String, productId: String, spec: PrintSpecification, discount: Double) -> Unit,
    onCreateTrading: (customerId: String, items: List<Pair<EnterpriseProductEntity, Double>>, discount: Double) -> Unit
) {
    var selectedDivision by remember { mutableStateOf(defaultDivision) }
    var selectedCustomer by remember { mutableStateOf(customers.firstOrNull()) }
    var discountPercent by remember { mutableStateOf(0.0) }

    // Printing Form State
    var selectedPrintProduct by remember { mutableStateOf(products.firstOrNull { it.divisionId == "PRINTING" }) }
    var printPaperType by remember { mutableStateOf("Art Card") }
    var printGsm by remember { mutableStateOf(350) }
    var printSides by remember { mutableStateOf(2) }
    var printLamination by remember { mutableStateOf("Matte") }
    var printBinding by remember { mutableStateOf("None") }
    var printQuantity by remember { mutableStateOf(500) }
    var isUrgent by remember { mutableStateOf(false) }

    // Trading Form State
    var selectedTradingProduct by remember { mutableStateOf(products.firstOrNull { it.divisionId == "TRADING" }) }
    var tradingQuantity by remember { mutableStateOf(20.0) }

    // Deterministic Live Preview Calculation
    val printSpec = PrintSpecification(
        paperType = printPaperType,
        gsm = printGsm,
        sideCount = printSides,
        lamination = printLamination,
        binding = printBinding,
        quantity = printQuantity,
        isUrgent = isUrgent
    )

    val previewSubtotal = if (selectedDivision == "PRINTING") {
        DeterministicFinancialEngine.calculatePrintItemCost(
            spec = printSpec,
            baseRatePerUnit = selectedPrintProduct?.sellingPrice ?: 3.0,
            setupCharge = 150.0,
            urgentSurchargePercent = 25.0
        )
    } else {
        DeterministicFinancialEngine.round2((selectedTradingProduct?.sellingPrice ?: 350.0) * tradingQuantity)
    }

    val previewTax = DeterministicFinancialEngine.calculateTax(
        subtotal = previewSubtotal,
        discountPercent = discountPercent,
        gstRate = if (selectedDivision == "PRINTING") (selectedPrintProduct?.gstRate ?: 18.0) else (selectedTradingProduct?.gstRate ?: 28.0)
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .border(1.dp, SlateBorder, RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Quotation Builder",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Deterministic Commercial Calculation",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Division Selector Tabs
                Row(modifier = Modifier.fillMaxWidth()) {
                    FilterChip(
                        selected = selectedDivision == "PRINTING",
                        onClick = { selectedDivision = "PRINTING" },
                        label = { Text("Printing & Digital") },
                        modifier = Modifier.weight(1f).padding(end = 4.dp)
                    )
                    FilterChip(
                        selected = selectedDivision == "TRADING",
                        onClick = { selectedDivision = "TRADING" },
                        label = { Text("Trading Materials") },
                        modifier = Modifier.weight(1f).padding(start = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Customer Selection
                Text("Select Customer", fontSize = 12.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(4.dp))
                if (customers.isNotEmpty()) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SlateCard),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = selectedCustomer?.name ?: "No customer selected",
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "Phone: ${selectedCustomer?.phone ?: "N/A"}",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Division specific input fields
                if (selectedDivision == "PRINTING") {
                    Text("Print Product & Specifications", fontSize = 12.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))

                    Text("Product: ${selectedPrintProduct?.name ?: "Visiting Cards"}", fontSize = 12.sp, color = TextPrimary)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = "$printQuantity",
                            onValueChange = { printQuantity = it.toIntOrNull() ?: 100 },
                            label = { Text("Qty") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = "$printGsm",
                            onValueChange = { printGsm = it.toIntOrNull() ?: 300 },
                            label = { Text("GSM") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = printSides == 1,
                            onClick = { printSides = 1 },
                            label = { Text("1 Side") },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = printSides == 2,
                            onClick = { printSides = 2 },
                            label = { Text("2 Sided") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = printLamination == "Matte",
                            onClick = { printLamination = if (printLamination == "Matte") "None" else "Matte" },
                            label = { Text("Matte Lam") },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = printLamination == "Gloss",
                            onClick = { printLamination = if (printLamination == "Gloss") "None" else "Gloss" },
                            label = { Text("Gloss Lam") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isUrgent, onCheckedChange = { isUrgent = it })
                        Text("Urgent Production (+25% surcharge)", fontSize = 12.sp, color = if (isUrgent) AccentAmber else TextSecondary)
                    }
                } else {
                    Text("Trading Commodity & Quantity", fontSize = 12.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))

                    Text("Product: ${selectedTradingProduct?.name ?: "UltraTech 53G Cement"}", fontSize = 12.sp, color = TextPrimary)
                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = "$tradingQuantity",
                        onValueChange = { tradingQuantity = it.toDoubleOrNull() ?: 1.0 },
                        label = { Text("Quantity (${selectedTradingProduct?.unit ?: "BAG"})") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Discount Input
                OutlinedTextField(
                    value = "$discountPercent",
                    onValueChange = { discountPercent = it.toDoubleOrNull() ?: 0.0 },
                    label = { Text("Discount % (>10% requires manager approval)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Real-time Deterministic Calculation Box
                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateCard),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, PrimarySky.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Deterministic Live Tax Calculation", fontSize = 11.sp, color = PrimarySkyLight, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Subtotal:", fontSize = 12.sp, color = TextSecondary)
                            Text("₹${previewTax.subtotal}", fontSize = 12.sp, color = TextPrimary)
                        }
                        if (previewTax.discountAmount > 0) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Discount (${previewTax.discountPercent}%):", fontSize = 12.sp, color = DangerRose)
                                Text("-₹${previewTax.discountAmount}", fontSize = 12.sp, color = DangerRose)
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Taxable Value:", fontSize = 12.sp, color = TextSecondary)
                            Text("₹${previewTax.taxableValue}", fontSize = 12.sp, color = TextPrimary)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("GST (${previewTax.gstRate}%):", fontSize = 12.sp, color = TextSecondary)
                            Text("₹${previewTax.totalTax}", fontSize = 12.sp, color = TextPrimary)
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = SlateBorder)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Grand Total:", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text("₹${previewTax.grandTotal}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = SuccessEmerald)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val cust = selectedCustomer ?: return@Button
                            if (selectedDivision == "PRINTING") {
                                val prod = selectedPrintProduct ?: return@Button
                                onCreatePrint(cust.customerId, prod.productId, printSpec, discountPercent)
                            } else {
                                val prod = selectedTradingProduct ?: return@Button
                                onCreateTrading(cust.customerId, listOf(prod to tradingQuantity), discountPercent)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimarySky),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Create Quote")
                    }
                }
            }
        }
    }
}
