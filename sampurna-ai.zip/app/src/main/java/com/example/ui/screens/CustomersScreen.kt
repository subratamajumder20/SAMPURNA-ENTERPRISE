package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.CustomerEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.SampurnaViewModel

@Composable
fun CustomersScreen(
    viewModel: SampurnaViewModel
) {
    val customers by viewModel.customers.collectAsState()
    val customer360 by viewModel.selectedCustomerHistory.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var showCreateDialog by remember { mutableStateOf(false) }

    val filteredCustomers = if (searchQuery.isBlank()) {
        customers
    } else {
        customers.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
            it.phone.contains(searchQuery) ||
            (it.email?.contains(searchQuery, ignoreCase = true) == true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("customers_screen")
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Customer Directory & 360°",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Shared Customer Master across Sampurna Modules",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            Button(
                onClick = { showCreateDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = PrimarySky),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Customer", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Search Field
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by name, phone or email...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp)
        )

        Spacer(modifier = Modifier.height(14.dp))

        if (filteredCustomers.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No customers found", color = TextSecondary)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredCustomers) { cust ->
                    CustomerCard(
                        customer = cust,
                        onView360 = { viewModel.loadCustomerHistory(cust.customerId) }
                    )
                }
            }
        }
    }

    // New Customer Dialog
    if (showCreateDialog) {
        NewCustomerDialog(
            onDismiss = { showCreateDialog = false },
            onSubmit = { name, phone, email, address, type ->
                viewModel.createCustomer(name, phone, email, address, type)
                showCreateDialog = false
            }
        )
    }

    // Customer 360 Dialog
    customer360?.let { history ->
        Customer360Dialog(
            history = history,
            onDismiss = { viewModel.loadCustomerHistory("") }
        )
    }
}

@Composable
fun CustomerCard(
    customer: CustomerEntity,
    onView360: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SlateCard),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SlateBorder, RoundedCornerShape(10.dp))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(customer.name, fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                Text("Phone: ${customer.phone} • Email: ${customer.email ?: "N/A"}", fontSize = 11.sp, color = TextSecondary)
                Text("GSTIN: ${customer.gstinOptional ?: "Unregistered"} • Type: ${customer.customerType}", fontSize = 10.sp, color = TextMuted)
            }

            OutlinedButton(
                onClick = onView360,
                shape = RoundedCornerShape(6.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text("360° View", fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun NewCustomerDialog(
    onDismiss: () -> Unit,
    onSubmit: (String, String, String?, String?, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var customerType by remember { mutableStateOf("INDIVIDUAL") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Register New Customer", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TextPrimary)
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Customer Name") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone Number") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email (Optional)") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Address (Optional)") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(10.dp))

                Text("Customer Type", fontSize = 11.sp, color = TextSecondary)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("INDIVIDUAL", "BUSINESS", "CORPORATE").forEach { t ->
                        FilterChip(
                            selected = customerType == t,
                            onClick = { customerType = t },
                            label = { Text(t, fontSize = 9.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        onClick = {
                            if (name.isNotBlank() && phone.isNotBlank()) {
                                onSubmit(name, phone, email.ifBlank { null }, address.ifBlank { null }, customerType)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimarySky),
                        modifier = Modifier.weight(1f)
                    ) { Text("Save Customer") }
                }
            }
        }
    }
}

@Composable
fun Customer360Dialog(
    history: com.example.data.repository.CustomerHistory360,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = history.customer?.name ?: "Customer Profile",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "Phone: ${history.customer?.phone} • GSTIN: ${history.customer?.gstinOptional ?: "None"}",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = null, tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Summary Financials
                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateCard),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Total Billed", fontSize = 10.sp, color = TextMuted)
                            Text("₹${history.totalBilled}", fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Total Collected", fontSize = 10.sp, color = TextMuted)
                            Text("₹${history.totalPaid}", fontSize = 12.sp, color = SuccessEmerald, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Outstanding", fontSize = 10.sp, color = TextMuted)
                            Text(
                                "₹${history.totalOutstanding}",
                                fontSize = 12.sp,
                                color = if (history.totalOutstanding > 0) DangerRose else SuccessEmerald,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text("Activity Ledger", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TextPrimary)
                Spacer(modifier = Modifier.height(6.dp))

                Text("Quotations (${history.quotations.size})", fontSize = 11.sp, color = PrimarySkyLight, fontWeight = FontWeight.SemiBold)
                history.quotations.forEach { q ->
                    Text("• ${q.quotationNumber} [${q.status}] - ₹${q.grandTotal}", fontSize = 11.sp, color = TextSecondary)
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text("Orders (${history.orders.size})", fontSize = 11.sp, color = AccentAmber, fontWeight = FontWeight.SemiBold)
                history.orders.forEach { o ->
                    Text("• ${o.orderNumber} [${o.status}] - ₹${o.grandTotal}", fontSize = 11.sp, color = TextSecondary)
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text("Invoices (${history.invoices.size})", fontSize = 11.sp, color = SuccessEmerald, fontWeight = FontWeight.SemiBold)
                history.invoices.forEach { inv ->
                    Text("• ${inv.invoiceNumber} [${inv.status}] - Due: ₹${inv.balanceDue}", fontSize = 11.sp, color = TextSecondary)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                    Text("Close")
                }
            }
        }
    }
}
