package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.EnterpriseProductionJobEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.SampurnaViewModel

@Composable
fun ProductionKanbanScreen(
    viewModel: SampurnaViewModel
) {
    val jobs by viewModel.productionJobs.collectAsState()
    val orders by viewModel.orders.collectAsState()

    var selectedPriorityFilter by remember { mutableStateOf("ALL") }
    var qcJobTarget by remember { mutableStateOf<EnterpriseProductionJobEntity?>(null) }
    var packJobTarget by remember { mutableStateOf<EnterpriseProductionJobEntity?>(null) }
    var deliveryJobTarget by remember { mutableStateOf<EnterpriseProductionJobEntity?>(null) }

    val kanbanStages = listOf(
        "ARTWORK_PENDING" to "Artwork Pending",
        "MATERIAL_PENDING" to "Material Pending",
        "READY_FOR_PRODUCTION" to "Ready",
        "IN_PRODUCTION" to "In Production",
        "QUALITY_CHECK" to "Quality Check",
        "READY_FOR_PACKING" to "Packing",
        "READY_FOR_DELIVERY" to "Ready for Delivery",
        "COMPLETED" to "Completed"
    )

    val filteredJobs = if (selectedPriorityFilter == "ALL") {
        jobs
    } else {
        jobs.filter { it.priority == selectedPriorityFilter }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("kanban_screen")
            .padding(16.dp)
    ) {
        // Header & Filter Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Production Kanban Board",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Division A: Print Job Tracking & Stage Gating",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            // Priority Filter Chips
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("ALL", "URGENT", "HIGH", "NORMAL").forEach { p ->
                    FilterChip(
                        selected = selectedPriorityFilter == p,
                        onClick = { selectedPriorityFilter = p },
                        label = { Text(p, fontSize = 11.sp) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Horizontal scrolling Kanban Board
        Row(
            modifier = Modifier
                .fillMaxSize()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            kanbanStages.forEach { (statusKey, statusTitle) ->
                val stageJobs = filteredJobs.filter { it.status == statusKey }

                KanbanColumn(
                    title = statusTitle,
                    count = stageJobs.size,
                    jobs = stageJobs,
                    orders = orders,
                    onAdvance = { job, nextStatus -> viewModel.updateProductionStatus(job.productionJobId, nextStatus) },
                    onReserve = { job -> viewModel.reserveMaterial(job.productionJobId, "MAT-PAP-300", 500.0) },
                    onOpenQc = { job -> qcJobTarget = job },
                    onOpenPack = { job -> packJobTarget = job },
                    onOpenDelivery = { job -> deliveryJobTarget = job }
                )
            }
        }
    }

    // QC Inspection Dialog
    qcJobTarget?.let { job ->
        QcInspectionDialog(
            job = job,
            onDismiss = { qcJobTarget = null },
            onSubmit = { passed, remarks ->
                viewModel.recordQualityCheck(job.productionJobId, job.orderId, passed, remarks)
                qcJobTarget = null
            }
        )
    }

    // Packing Dialog
    packJobTarget?.let { job ->
        PackingDialog(
            job = job,
            onDismiss = { packJobTarget = null },
            onSubmit = { qty, count ->
                viewModel.packOrder(job.orderId, qty, count)
                packJobTarget = null
            }
        )
    }

    // Delivery Schedule Dialog
    deliveryJobTarget?.let { job ->
        DeliveryDialog(
            job = job,
            onDismiss = { deliveryJobTarget = null },
            onSubmit = { method ->
                viewModel.createDelivery(job.orderId, method)
                deliveryJobTarget = null
            }
        )
    }
}

@Composable
fun KanbanColumn(
    title: String,
    count: Int,
    jobs: List<EnterpriseProductionJobEntity>,
    orders: List<com.example.data.model.EnterpriseOrderEntity>,
    onAdvance: (EnterpriseProductionJobEntity, String) -> Unit,
    onReserve: (EnterpriseProductionJobEntity) -> Unit,
    onOpenQc: (EnterpriseProductionJobEntity) -> Unit,
    onOpenPack: (EnterpriseProductionJobEntity) -> Unit,
    onOpenDelivery: (EnterpriseProductionJobEntity) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .width(280.dp)
            .fillMaxHeight()
            .border(1.dp, SlateBorder, RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Column Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = TextPrimary
                )
                Surface(
                    color = SlateBorder,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "$count",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (jobs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No jobs in this stage", color = TextMuted, fontSize = 11.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(jobs) { job ->
                        val order = orders.firstOrNull { it.orderId == job.orderId }
                        JobCard(
                            job = job,
                            order = order,
                            onAdvance = onAdvance,
                            onReserve = onReserve,
                            onOpenQc = onOpenQc,
                            onOpenPack = onOpenPack,
                            onOpenDelivery = onOpenDelivery
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun JobCard(
    job: EnterpriseProductionJobEntity,
    order: com.example.data.model.EnterpriseOrderEntity?,
    onAdvance: (EnterpriseProductionJobEntity, String) -> Unit,
    onReserve: (EnterpriseProductionJobEntity) -> Unit,
    onOpenQc: (EnterpriseProductionJobEntity) -> Unit,
    onOpenPack: (EnterpriseProductionJobEntity) -> Unit,
    onOpenDelivery: (EnterpriseProductionJobEntity) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SlateCard),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SlateBorder, RoundedCornerShape(8.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = job.jobNumber,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = PrimarySkyLight
                )

                // Priority Badge
                Surface(
                    color = if (job.priority == "URGENT") DangerRose.copy(alpha = 0.2f) else SlateBorder,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = job.priority,
                        color = if (job.priority == "URGENT") DangerRose else TextSecondary,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Order: ${order?.orderNumber ?: job.orderId}",
                fontSize = 11.sp,
                color = TextSecondary
            )
            Text(
                text = "Assigned: ${job.assignedTo ?: "Unassigned"}",
                fontSize = 11.sp,
                color = TextMuted
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Stage Action Triggers
            when (job.status) {
                "MATERIAL_PENDING" -> {
                    Button(
                        onClick = { onReserve(job) },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentAmber),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Text("Reserve Materials", fontSize = 11.sp)
                    }
                }
                "READY_FOR_PRODUCTION" -> {
                    Button(
                        onClick = { onAdvance(job, "IN_PRODUCTION") },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimarySky),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Text("Start Production", fontSize = 11.sp)
                    }
                }
                "IN_PRODUCTION" -> {
                    Button(
                        onClick = { onAdvance(job, "QUALITY_CHECK") },
                        colors = ButtonDefaults.buttonColors(containerColor = PurplePrint),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Text("Submit for QC", fontSize = 11.sp)
                    }
                }
                "QUALITY_CHECK" -> {
                    Button(
                        onClick = { onOpenQc(job) },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentAmber),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Text("Conduct QC Inspection", fontSize = 11.sp)
                    }
                }
                "READY_FOR_PACKING" -> {
                    Button(
                        onClick = { onOpenPack(job) },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimarySky),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Text("Pack Finished Goods", fontSize = 11.sp)
                    }
                }
                "READY_FOR_DELIVERY" -> {
                    Button(
                        onClick = { onOpenDelivery(job) },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Text("Dispatch Delivery", fontSize = 11.sp)
                    }
                }
                "COMPLETED" -> {
                    Text("Job Finished ✓", color = SuccessEmerald, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
fun QcInspectionDialog(
    job: EnterpriseProductionJobEntity,
    onDismiss: () -> Unit,
    onSubmit: (Boolean, String?) -> Unit
) {
    var checkQuality by remember { mutableStateOf(true) }
    var checkColour by remember { mutableStateOf(true) }
    var checkPaper by remember { mutableStateOf(true) }
    var checkCutting by remember { mutableStateOf(true) }
    var checkLamination by remember { mutableStateOf(true) }
    var remarks by remember { mutableStateOf("") }

    val allPass = checkQuality && checkColour && checkPaper && checkCutting && checkLamination

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Quality Control Inspection",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Job: ${job.jobNumber}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(16.dp))

                QcCheckRow("Print Sharpness & Defect Free", checkQuality) { checkQuality = it }
                QcCheckRow("Colour Accuracy & Alignment", checkColour) { checkColour = it }
                QcCheckRow("Correct Paper GSM & Texture", checkPaper) { checkPaper = it }
                QcCheckRow("Precision Cutting & Margins", checkCutting) { checkCutting = it }
                QcCheckRow("Lamination / Binding Quality", checkLamination) { checkLamination = it }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = remarks,
                    onValueChange = { remarks = it },
                    label = { Text("Inspector Remarks / Reason if Failed") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = { onSubmit(allPass, remarks.ifBlank { null }) },
                        colors = ButtonDefaults.buttonColors(containerColor = if (allPass) SuccessEmerald else DangerRose),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (allPass) "Pass QC" else "Fail (Rework)")
                    }
                }
            }
        }
    }
}

@Composable
fun QcCheckRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = onCheckedChange)
        Spacer(modifier = Modifier.width(8.dp))
        Text(label, fontSize = 12.sp, color = TextPrimary)
    }
}

@Composable
fun PackingDialog(
    job: EnterpriseProductionJobEntity,
    onDismiss: () -> Unit,
    onSubmit: (Double, Int) -> Unit
) {
    var packageCount by remember { mutableStateOf(1) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Pack Finished Order",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = "$packageCount",
                    onValueChange = { packageCount = it.toIntOrNull() ?: 1 },
                    label = { Text("Number of Packages / Cartons") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        onClick = { onSubmit(500.0, packageCount) },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimarySky),
                        modifier = Modifier.weight(1f)
                    ) { Text("Confirm Packed") }
                }
            }
        }
    }
}

@Composable
fun DeliveryDialog(
    job: EnterpriseProductionJobEntity,
    onDismiss: () -> Unit,
    onSubmit: (String) -> Unit
) {
    var selectedMethod by remember { mutableStateOf("COMPANY_DELIVERY") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Dispatch Delivery",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(12.dp))

                listOf("COMPANY_DELIVERY", "COURIER", "CUSTOMER_PICKUP", "TRANSPORT").forEach { m ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        RadioButton(
                            selected = selectedMethod == m,
                            onClick = { selectedMethod = m }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(m.replace("_", " "), fontSize = 13.sp, color = TextPrimary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        onClick = { onSubmit(selectedMethod) },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald),
                        modifier = Modifier.weight(1f)
                    ) { Text("Schedule Dispatch") }
                }
            }
        }
    }
}
