package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sampurna Enterprise Palette
val SlateDark = Color(0xFF0F172A)
val SlateCard = Color(0xFF1E293B)
val SlateBorder = Color(0xFF334155)
val SlateLight = Color(0xFF64748B)

val PrimarySky = Color(0xFF0284C7)
val PrimarySkyLight = Color(0xFF38BDF8)
val AccentAmber = Color(0xFFF59E0B)
val SuccessEmerald = Color(0xFF10B981)
val DangerRose = Color(0xFFF43F5E)
val PurplePrint = Color(0xFF8B5CF6)
val IndigoTrading = Color(0xFF6366F1)

val BackgroundDark = Color(0xFF0B1120)
val SurfaceDark = Color(0xFF131D31)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
