package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ApprovalRequestEntity
import com.example.data.model.AuditLogEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.SampurnaViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ApprovalsScreen(
    viewModel: SampurnaViewModel
) {
    val approvals by viewModel.pendingApprovals.collectAsState()
    val auditLogs by viewModel.auditLogs.collectAsState()

    var selectedSection by remember { mutableStateOf("APPROVALS") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("approvals_screen")
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Approvals & Audit Trail",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Governance, Threshold Gates & Immutable Logs",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            // Tab switch between Approvals and Audit
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                FilterChip(
                    selected = selectedSection == "APPROVALS",
                    onClick = { selectedSection = "APPROVALS" },
                    label = { Text("Approvals (${approvals.size})", fontSize = 11.sp) }
                )
                FilterChip(
                    selected = selectedSection == "AUDIT",
                    onClick = { selectedSection = "AUDIT" },
                    label = { Text("Audit Logs", fontSize = 11.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedSection == "APPROVALS") {
            if (approvals.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.CheckCircleOutline, contentDescription = null, tint = SuccessEmerald, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("All approvals cleared. No pending requests.", color = TextSecondary)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(approvals) { req ->
                        ApprovalCard(
                            request = req,
                            onApprove = { viewModel.approveQuotation(req.entityId) }
                        )
                    }
                }
            }
        } else {
            // Audit Logs Table
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(auditLogs) { log ->
                    AuditLogCard(log)
                }
            }
        }
    }
}

@Composable
fun ApprovalCard(
    request: ApprovalRequestEntity,
    onApprove: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SlateCard),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, AccentAmber.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = request.requestType.replace("_", " "),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = AccentAmber
                    )
                    Text(
                        text = "Target: ${request.entityType} #${request.entityId} • Div: ${request.divisionId ?: "All"}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }

                Surface(
                    color = AccentAmber.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = request.status,
                        color = AccentAmber,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Reason: ${request.details ?: "Threshold policy triggered"}",
                fontSize = 12.sp,
                color = TextPrimary
            )
            Text(
                text = "Requested by: ${request.requestedBy} • Impact Amount: ₹${request.amount}",
                fontSize = 11.sp,
                color = TextMuted
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onApprove,
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text("Authorize / Approve", fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun AuditLogCard(log: AuditLogEntity) {
    val dateStr = SimpleDateFormat("dd MMM HH:mm:ss", Locale.getDefault()).format(Date(log.timestamp))

    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SlateBorder, RoundedCornerShape(8.dp))
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = log.action,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = PrimarySkyLight
                )
                Text(
                    text = dateStr,
                    fontSize = 10.sp,
                    color = TextMuted
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = log.details ?: "${log.action} executed on ${log.entity} #${log.entityId}",
                fontSize = 11.sp,
                color = TextPrimary
            )

            Text(
                text = "Actor: ${log.actorName} • Biz: ${log.business}${if (log.division != null) " • Div: ${log.division}" else ""} • Result: ${log.result}",
                fontSize = 10.sp,
                color = TextSecondary
            )
        }
    }
}
