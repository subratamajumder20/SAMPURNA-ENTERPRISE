package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.auth.DivisionTenant
import com.example.data.model.EnterpriseInventoryEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.SampurnaViewModel

@Composable
fun InventoryScreen(
    viewModel: SampurnaViewModel
) {
    val inventory by viewModel.inventoryItems.collectAsState()
    val division by viewModel.selectedDivision.collectAsState()

    val filteredItems = if (division == DivisionTenant.BOTH) {
        inventory
    } else {
        inventory.filter { it.divisionId == division.name }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("inventory_screen")
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Inventory & Material Control",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Division Isolation • Negative Stock Guard Active",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            Surface(
                color = SuccessEmerald.copy(alpha = 0.15f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = SuccessEmerald, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Mutex Locked", color = SuccessEmerald, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (filteredItems.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("No inventory items found for ${division.name}", color = TextSecondary)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredItems) { item ->
                    InventoryItemCard(item)
                }
            }
        }
    }
}

@Composable
fun InventoryItemCard(item: EnterpriseInventoryEntity) {
    val isLowStock = item.availableStock <= item.minimumStock

    Card(
        colors = CardDefaults.cardColors(containerColor = SlateCard),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (isLowStock) DangerRose.copy(alpha = 0.5f) else SlateBorder, RoundedCornerShape(10.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = item.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = TextPrimary
                    )
                    Text(
                        text = "Division: ${item.divisionId} • Location: ${item.location ?: "Godown"}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }

                if (isLowStock) {
                    Surface(
                        color = DangerRose.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "LOW STOCK",
                            color = DangerRose,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                } else {
                    Surface(
                        color = SuccessEmerald.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "HEALTHY",
                            color = SuccessEmerald,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = SlateBorder)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Current Stock", fontSize = 10.sp, color = TextMuted)
                    Text("${item.currentStock} ${item.unit}", fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                }
                Column {
                    Text("Reserved", fontSize = 10.sp, color = TextMuted)
                    Text("${item.reservedStock} ${item.unit}", fontSize = 12.sp, color = AccentAmber, fontWeight = FontWeight.SemiBold)
                }
                Column {
                    Text("Available", fontSize = 10.sp, color = TextMuted)
                    Text(
                        "${item.availableStock} ${item.unit}",
                        fontSize = 12.sp,
                        color = if (isLowStock) DangerRose else SuccessEmerald,
                        fontWeight = FontWeight.Bold
                    )
                }
                Column {
                    Text("Min Threshold", fontSize = 10.sp, color = TextMuted)
                    Text("${item.minimumStock} ${item.unit}", fontSize = 12.sp, color = TextSecondary)
                }
            }
        }
    }
}
