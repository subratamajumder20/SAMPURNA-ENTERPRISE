package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.core.auth.BusinessTenant
import com.example.core.auth.DivisionTenant
import com.example.core.financial.DeterministicFinancialEngine
import com.example.data.model.BBMotorJobCardEntity
import com.example.data.model.RenaissanceReservationEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.SampurnaViewModel

@Composable
fun DashboardScreen(
    viewModel: SampurnaViewModel,
    onNavigateTab: (String) -> Unit
) {
    val quotations by viewModel.quotations.collectAsState()
    val orders by viewModel.orders.collectAsState()
    val jobs by viewModel.productionJobs.collectAsState()
    val inventory by viewModel.inventoryItems.collectAsState()
    val deliveries by viewModel.deliveries.collectAsState()
    val invoices by viewModel.invoices.collectAsState()
    val approvals by viewModel.pendingApprovals.collectAsState()
    val lowStock by viewModel.lowStockItems.collectAsState()
    val division by viewModel.selectedDivision.collectAsState()
    val selectedBusiness by viewModel.selectedBusiness.collectAsState()
    val bbJobCards by viewModel.bbJobCards.collectAsState()
    val reservations by viewModel.renaissanceReservations.collectAsState()

    var showCreateJobCardDialog by remember { mutableStateOf(false) }
    var showCreateReservationDialog by remember { mutableStateOf(false) }

    // Metrics for Sampurna Enterprise
    val enterpriseRevenue = orders.sumOf { it.grandTotal }
    val enterpriseActiveTasks = orders.count { it.status != "COMPLETED" && it.status != "CANCELLED" } +
            jobs.count { it.status in listOf("ARTWORK_PENDING", "MATERIAL_PENDING", "IN_PRODUCTION", "QUALITY_CHECK") } +
            lowStock.size

    // Metrics for B.B. Motors
    val bbRevenue = bbJobCards.sumOf { it.estimatedCost }
    val bbActiveTasks = bbJobCards.count { it.status != "CLOSED" && it.status != "DELIVERED" }

    // Metrics for Renaissance Hotels
    val renaissanceRevenue = reservations.sumOf { it.totalAmount }
    val renaissanceActiveTasks = reservations.count { it.status == "CONFIRMED" }

    // Metrics for Sampurna Financial
    val financialCollected = invoices.sumOf { it.grandTotal - it.balanceDue }
    val financialOutstanding = invoices.sumOf { it.balanceDue }
    val financialActiveTasks = invoices.count { it.status != "PAID" } + approvals.size

    // Consolidated Portfolio Revenue & Tasks
    val totalGroupRevenue = enterpriseRevenue + bbRevenue + renaissanceRevenue
    val totalGroupTasks = enterpriseActiveTasks + bbActiveTasks + renaissanceActiveTasks

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("dashboard_screen")
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Group Portfolio Overview Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SlateBorder, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(SuccessEmerald)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "SAMPURNA GROUP HOLDINGS",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = PrimarySkyLight,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                            }
                            Text(
                                text = "Multi-Business Executive Command Center",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SlateBorder.copy(alpha = 0.5f)
                        ) {
                            Text(
                                text = "4 Entities",
                                color = TextPrimary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Consolidated Revenue", fontSize = 11.sp, color = TextMuted)
                            Text(
                                "₹${DeterministicFinancialEngine.round2(totalGroupRevenue)}",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = SuccessEmerald
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Active Group Tasks", fontSize = 11.sp, color = TextMuted)
                            Text(
                                "$totalGroupTasks Operations",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = AccentAmber
                            )
                        }
                    }
                }
            }
        }

        // Section Title: Business Entities Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Business Entities Portfolio",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Tap card to select entity",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }
        }

        // 1. Sampurna Enterprise Entity Card
        item {
            BusinessEntityCard(
                title = "Sampurna Enterprise",
                subtitle = "Commercial Printing, Digital Services & Building Commodities",
                industry = "Printing & Trading",
                icon = Icons.Default.Print,
                accentColor = PrimarySkyLight,
                revenue = enterpriseRevenue,
                revenueLabel = "Order Book Value",
                activeTasks = enterpriseActiveTasks,
                activeTasksLabel = "Active Orders & Jobs",
                isSelected = selectedBusiness == BusinessTenant.SAMPURNA_ENTERPRISE,
                onSelect = { viewModel.selectBusiness(BusinessTenant.SAMPURNA_ENTERPRISE) },
                subTags = listOf("Division A: Printing", "Division B: Trading", "${orders.size} Total Orders", "${lowStock.size} Low Stock Alert"),
                quickActionLabel = "New Quotation",
                onQuickAction = {
                    viewModel.selectBusiness(BusinessTenant.SAMPURNA_ENTERPRISE)
                    onNavigateTab("QUOTATIONS")
                },
                testTag = "card_entity_sampurna_enterprise"
            )
        }

        // 2. B.B. Motors Entity Card
        item {
            BusinessEntityCard(
                title = "B.B. Motors",
                subtitle = "Automotive Engineering, Multi-Brand Workshop & Fleet Servicing",
                industry = "Automotive Workshop (Phase 2A)",
                icon = Icons.Default.DirectionsCar,
                accentColor = AccentAmber,
                revenue = bbRevenue,
                revenueLabel = "Job Card Estimated Billing",
                activeTasks = bbActiveTasks,
                activeTasksLabel = "Active Vehicle Repair Bays",
                isSelected = selectedBusiness == BusinessTenant.BB_MOTORS,
                onSelect = { viewModel.selectBusiness(BusinessTenant.BB_MOTORS) },
                subTags = listOf("Mechanical Bays", "Body & Paint Shop", "${bbJobCards.size} Job Cards", "Quick Service"),
                quickActionLabel = "+ New Job Card",
                onQuickAction = { showCreateJobCardDialog = true },
                testTag = "card_entity_bb_motors"
            )
        }

        // 3. Renaissance Hotels Entity Card
        item {
            BusinessEntityCard(
                title = "Renaissance Hotels",
                subtitle = "Luxury Coastal Resorts, Business Suites & Hospitality Management",
                industry = "Hospitality & Tourism (Phase 2B)",
                icon = Icons.Default.Hotel,
                accentColor = SuccessEmerald,
                revenue = renaissanceRevenue,
                revenueLabel = "Confirmed Bookings",
                activeTasks = renaissanceActiveTasks,
                activeTasksLabel = "Active Guest Reservations",
                isSelected = selectedBusiness == BusinessTenant.RENAISSANCE_HOTELS,
                onSelect = { viewModel.selectBusiness(BusinessTenant.RENAISSANCE_HOTELS) },
                subTags = listOf("Puri Beachfront", "Bhubaneswar Gateway", "${reservations.size} Reservations", "85% Occupancy"),
                quickActionLabel = "+ New Booking",
                onQuickAction = { showCreateReservationDialog = true },
                testTag = "card_entity_renaissance_hotels"
            )
        }

        // 4. Sampurna Financial Entity Card
        item {
            BusinessEntityCard(
                title = "Sampurna Financial",
                subtitle = "Corporate Treasury, Receivables Ledger & Group Working Capital",
                industry = "Treasury & Finance (Phase 1)",
                icon = Icons.Default.AccountBalance,
                accentColor = PurplePrint,
                revenue = financialCollected,
                revenueLabel = "Total Collections",
                activeTasks = financialActiveTasks,
                activeTasksLabel = "Outstanding & Approvals",
                isSelected = selectedBusiness == BusinessTenant.SAMPURNA_FINANCIAL,
                onSelect = { viewModel.selectBusiness(BusinessTenant.SAMPURNA_FINANCIAL) },
                subTags = listOf("Receivables: ₹${DeterministicFinancialEngine.round2(financialOutstanding)}", "${approvals.size} Pending Approvals", "${invoices.size} Invoices"),
                quickActionLabel = "View Approvals",
                onQuickAction = { onNavigateTab("APPROVALS") },
                testTag = "card_entity_sampurna_financial"
            )
        }

        // Selected Business Operations Detail Panel
        item {
            Spacer(modifier = Modifier.height(8.dp))
            SelectedEntityOperationsPanel(
                selectedBusiness = selectedBusiness,
                division = division,
                orders = orders,
                quotations = quotations,
                jobs = jobs,
                inventory = inventory,
                lowStock = lowStock,
                approvals = approvals,
                bbJobCards = bbJobCards,
                reservations = reservations,
                onNavigateTab = onNavigateTab,
                onSelectDivision = { viewModel.selectDivision(it) },
                onCreateJobCard = { showCreateJobCardDialog = true },
                onCreateReservation = { showCreateReservationDialog = true }
            )
        }
    }

    // Modal: Quick Create B.B. Motors Job Card
    if (showCreateJobCardDialog) {
        CreateJobCardDialog(
            onDismiss = { showCreateJobCardDialog = false },
            onSubmit = { regNo, cost ->
                viewModel.createBBJobCard(regNo, "CUST-DEMO-001", cost)
                showCreateJobCardDialog = false
            }
        )
    }

    // Modal: Quick Create Renaissance Hotel Reservation
    if (showCreateReservationDialog) {
        CreateReservationDialog(
            onDismiss = { showCreateReservationDialog = false },
            onSubmit = { location, roomType, amount ->
                viewModel.createRenaissanceReservation(location, roomType, "CUST-DEMO-001", amount)
                showCreateReservationDialog = false
            }
        )
    }
}

@Composable
fun BusinessEntityCard(
    title: String,
    subtitle: String,
    industry: String,
    icon: ImageVector,
    accentColor: Color,
    revenue: Double,
    revenueLabel: String,
    activeTasks: Int,
    activeTasksLabel: String,
    isSelected: Boolean,
    onSelect: () -> Unit,
    subTags: List<String>,
    quickActionLabel: String,
    onQuickAction: () -> Unit,
    testTag: String
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) SurfaceDark else SlateCard
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
            .clickable { onSelect() }
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) accentColor else SlateBorder,
                shape = RoundedCornerShape(14.dp)
            )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Entity Title & Status Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(accentColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = industry,
                            fontSize = 11.sp,
                            color = accentColor,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                if (isSelected) {
                    Surface(
                        color = accentColor.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "CURRENT FOCUS",
                            color = accentColor,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                } else {
                    OutlinedButton(
                        onClick = onSelect,
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text("Select", fontSize = 10.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(text = subtitle, fontSize = 11.sp, color = TextSecondary)

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = SlateBorder)
            Spacer(modifier = Modifier.height(12.dp))

            // Key Metrics: Revenue & Active Tasks
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = revenueLabel, fontSize = 10.sp, color = TextMuted)
                    Text(
                        text = "₹${DeterministicFinancialEngine.round2(revenue)}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = SuccessEmerald
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(text = activeTasksLabel, fontSize = 10.sp, color = TextMuted)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "$activeTasks",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (activeTasks > 0) AccentAmber else TextSecondary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Tasks",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Operational Sub-Tags
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                subTags.forEach { tag ->
                    Surface(
                        color = SlateBorder.copy(alpha = 0.4f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = tag,
                            fontSize = 10.sp,
                            color = TextSecondary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = onSelect,
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(
                        text = if (isSelected) "Viewing Active Operations ↓" else "View Operations →",
                        fontSize = 11.sp,
                        color = accentColor,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Button(
                    onClick = onQuickAction,
                    colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text(quickActionLabel, fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun SelectedEntityOperationsPanel(
    selectedBusiness: BusinessTenant,
    division: DivisionTenant,
    orders: List<com.example.data.model.EnterpriseOrderEntity>,
    quotations: List<com.example.data.model.EnterpriseQuotationEntity>,
    jobs: List<com.example.data.model.EnterpriseProductionJobEntity>,
    inventory: List<com.example.data.model.EnterpriseInventoryEntity>,
    lowStock: List<com.example.data.model.EnterpriseInventoryEntity>,
    approvals: List<com.example.data.model.ApprovalRequestEntity>,
    bbJobCards: List<BBMotorJobCardEntity>,
    reservations: List<RenaissanceReservationEntity>,
    onNavigateTab: (String) -> Unit,
    onSelectDivision: (DivisionTenant) -> Unit,
    onCreateJobCard: () -> Unit,
    onCreateReservation: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SlateCard),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SlateBorder, RoundedCornerShape(14.dp))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header for Selected Business
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = when (selectedBusiness) {
                            BusinessTenant.SAMPURNA_ENTERPRISE -> "Sampurna Enterprise Operations"
                            BusinessTenant.BB_MOTORS -> "B.B. Motors Workshop Command"
                            BusinessTenant.RENAISSANCE_HOTELS -> "Renaissance Hotels Front Desk"
                            BusinessTenant.SAMPURNA_FINANCIAL -> "Sampurna Financial Audit & Approvals"
                            else -> "Group Operations Overview"
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = TextPrimary
                    )
                    Text(
                        text = "Active entity focused workflow",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }

                Surface(
                    color = PrimarySky.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = selectedBusiness.name,
                        color = PrimarySkyLight,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            when (selectedBusiness) {
                BusinessTenant.SAMPURNA_ENTERPRISE -> {
                    // Division Selector Tabs
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            DivisionTenant.BOTH to "Consolidated",
                            DivisionTenant.PRINTING to "Printing",
                            DivisionTenant.TRADING to "Trading"
                        ).forEach { (div, label) ->
                            FilterChip(
                                selected = division == div,
                                onClick = { onSelectDivision(div) },
                                label = { Text(label, fontSize = 11.sp) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Printing & Trading Pipelines
                    if (division == DivisionTenant.BOTH || division == DivisionTenant.PRINTING) {
                        Text("Division A: Print Production Pipeline", fontWeight = FontWeight.Bold, color = PurplePrint, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            PipelineStageChip("Artwork", jobs.count { it.status == "ARTWORK_PENDING" })
                            PipelineStageChip("Material", jobs.count { it.status == "MATERIAL_PENDING" })
                            PipelineStageChip("In Press", jobs.count { it.status == "IN_PRODUCTION" })
                            PipelineStageChip("QC Check", jobs.count { it.status == "QUALITY_CHECK" })
                            PipelineStageChip("Packing", jobs.count { it.status in listOf("READY_FOR_PACKING", "PACKED") })
                            PipelineStageChip("Ready Deliv", jobs.count { it.status == "READY_FOR_DELIVERY" })
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    if (division == DivisionTenant.BOTH || division == DivisionTenant.TRADING) {
                        Text("Division B: Trading Materials Pipeline", fontWeight = FontWeight.Bold, color = IndigoTrading, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        val tradingOrders = orders.filter { it.divisionId == "TRADING" }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            PipelineStageChip("Confirmed", tradingOrders.count { it.status == "ORDER_CONFIRMED" })
                            PipelineStageChip("Reserved", tradingOrders.count { it.status == "STOCK_RESERVED" })
                            PipelineStageChip("Dispatch", tradingOrders.count { it.status == "READY_FOR_DISPATCH" })
                            PipelineStageChip("Dispatched", tradingOrders.count { it.status == "DISPATCHED" })
                            PipelineStageChip("Delivered", tradingOrders.count { it.status == "DELIVERED" })
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { onNavigateTab("QUOTATIONS") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PrimarySky)
                        ) {
                            Text("Quotation Engine", fontSize = 11.sp)
                        }
                        Button(
                            onClick = { onNavigateTab("KANBAN") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SlateBorder)
                        ) {
                            Text("Production Board", fontSize = 11.sp)
                        }
                    }
                }

                BusinessTenant.BB_MOTORS -> {
                    Text("B.B. Motors Active Vehicle Job Cards (${bbJobCards.size})", fontWeight = FontWeight.Bold, color = AccentAmber, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    if (bbJobCards.isEmpty()) {
                        Text("No active job cards in repair bays.", color = TextMuted, fontSize = 11.sp)
                    } else {
                        bbJobCards.take(3).forEach { card ->
                            Surface(
                                color = SurfaceDark,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(card.jobNumber, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TextPrimary)
                                        Text("Vehicle: ${card.vehicleRegNo} • Status: ${card.status}", fontSize = 10.sp, color = TextSecondary)
                                    }
                                    Text("₹${card.estimatedCost}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = AccentAmber)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onCreateJobCard,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AccentAmber)
                    ) {
                        Text("Register Vehicle Job Card", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }

                BusinessTenant.RENAISSANCE_HOTELS -> {
                    Text("Renaissance Hotels Reservations (${reservations.size})", fontWeight = FontWeight.Bold, color = SuccessEmerald, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    if (reservations.isEmpty()) {
                        Text("No active bookings recorded.", color = TextMuted, fontSize = 11.sp)
                    } else {
                        reservations.take(3).forEach { res ->
                            Surface(
                                color = SurfaceDark,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(res.reservationNumber, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TextPrimary)
                                        Text("${res.propertyLocation} • ${res.roomType}", fontSize = 10.sp, color = TextSecondary)
                                    }
                                    Text("₹${res.totalAmount}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SuccessEmerald)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onCreateReservation,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald)
                    ) {
                        Text("Book Room Reservation", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }

                BusinessTenant.SAMPURNA_FINANCIAL -> {
                    Text("Financial Governance & Pending Approvals (${approvals.size})", fontWeight = FontWeight.Bold, color = PurplePrint, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    if (approvals.isEmpty()) {
                        Text("No pending governance approvals. All thresholds within policy.", color = TextSecondary, fontSize = 11.sp)
                    } else {
                        approvals.take(3).forEach { app ->
                            Surface(
                                color = SurfaceDark,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(app.requestType.replace("_", " "), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = AccentAmber)
                                        Text("By ${app.requestedBy} • ${app.entityType} #${app.entityId}", fontSize = 10.sp, color = TextSecondary)
                                    }
                                    Text("₹${app.amount}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TextPrimary)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { onNavigateTab("APPROVALS") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PurplePrint)
                    ) {
                        Text("Open Governance Audit Ledger", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }

                else -> {
                    Text("Select any business entity above to drill down into its operations.", color = TextSecondary, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun CreateJobCardDialog(
    onDismiss: () -> Unit,
    onSubmit: (String, Double) -> Unit
) {
    var regNo by remember { mutableStateOf("OD-02-XY-7788") }
    var costText by remember { mutableStateOf("5500.0") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Register B.B. Motors Job Card", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextPrimary)
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = regNo,
                    onValueChange = { regNo = it },
                    label = { Text("Vehicle Registration No.") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = costText,
                    onValueChange = { costText = it },
                    label = { Text("Estimated Service Cost (₹)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        onClick = {
                            val cost = costText.toDoubleOrNull() ?: 5000.0
                            onSubmit(regNo, cost)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentAmber),
                        modifier = Modifier.weight(1f)
                    ) { Text("Create Job Card", color = Color.Black) }
                }
            }
        }
    }
}

@Composable
fun CreateReservationDialog(
    onDismiss: () -> Unit,
    onSubmit: (String, String, Double) -> Unit
) {
    var selectedLocation by remember { mutableStateOf("Puri") }
    var selectedRoomType by remember { mutableStateOf("Deluxe Sea Facing Suite") }
    var amountText by remember { mutableStateOf("14500.0") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("New Renaissance Reservation", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextPrimary)
                Spacer(modifier = Modifier.height(12.dp))

                Text("Property Location", fontSize = 11.sp, color = TextSecondary)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Puri", "Bhubaneswar").forEach { loc ->
                        FilterChip(
                            selected = selectedLocation == loc,
                            onClick = { selectedLocation = loc },
                            label = { Text(loc, fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text("Room Category", fontSize = 11.sp, color = TextSecondary)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Deluxe", "Executive Suite").forEach { room ->
                        FilterChip(
                            selected = selectedRoomType.contains(room),
                            onClick = { selectedRoomType = "$room Suite" },
                            label = { Text(room, fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Total Booking Value (₹)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        onClick = {
                            val amount = amountText.toDoubleOrNull() ?: 12000.0
                            onSubmit(selectedLocation, selectedRoomType, amount)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald),
                        modifier = Modifier.weight(1f)
                    ) { Text("Confirm Booking", color = Color.Black) }
                }
            }
        }
    }
}

@Composable
fun PipelineStageChip(label: String, count: Int) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(horizontal = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(if (count > 0) PrimarySky.copy(alpha = 0.25f) else SlateBorder.copy(alpha = 0.3f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "$count",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (count > 0) PrimarySkyLight else TextMuted
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = label, fontSize = 10.sp, color = TextSecondary)
    }
}
