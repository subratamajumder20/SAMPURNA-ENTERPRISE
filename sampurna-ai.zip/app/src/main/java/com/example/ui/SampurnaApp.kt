package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.auth.BusinessTenant
import com.example.core.auth.DivisionTenant
import com.example.core.auth.UserRole
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.SampurnaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SampurnaApp(
    viewModel: SampurnaViewModel = viewModel()
) {
    val activeTab by viewModel.activeTab.collectAsState()
    val selectedBusiness by viewModel.selectedBusiness.collectAsState()
    val selectedDivision by viewModel.selectedDivision.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val userMessage by viewModel.userMessage.collectAsState()

    var showBusinessMenu by remember { mutableStateOf(false) }
    var showDivisionMenu by remember { mutableStateOf(false) }
    var showRoleMenu by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(userMessage) {
        userMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearUserMessage()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = BackgroundDark,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "SAMPURNA AI",
                            fontWeight = FontWeight.Black,
                            fontSize = 17.sp,
                            color = PrimarySkyLight,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))

                        // Business Selector Dropdown
                        Box {
                            Surface(
                                onClick = { showBusinessMenu = true },
                                shape = MaterialTheme.shapes.small,
                                color = SlateCard,
                                border = ButtonDefaults.outlinedButtonBorder(enabled = true)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = when (selectedBusiness) {
                                            BusinessTenant.SAMPURNA_ENTERPRISE -> "Sampurna Enterprise"
                                            BusinessTenant.BB_MOTORS -> "B.B. Motors (2A)"
                                            BusinessTenant.RENAISSANCE_HOTELS -> "Renaissance Hotels (2B)"
                                            else -> "All Businesses"
                                        },
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                                }
                            }

                            DropdownMenu(
                                expanded = showBusinessMenu,
                                onDismissRequest = { showBusinessMenu = false },
                                modifier = Modifier.background(SurfaceDark)
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Sampurna Enterprise (Phase 2C)") },
                                    onClick = {
                                        viewModel.selectBusiness(BusinessTenant.SAMPURNA_ENTERPRISE)
                                        showBusinessMenu = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("B.B. Motors Workshop (Phase 2A)") },
                                    onClick = {
                                        viewModel.selectBusiness(BusinessTenant.BB_MOTORS)
                                        showBusinessMenu = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Renaissance Hotels (Phase 2B)") },
                                    onClick = {
                                        viewModel.selectBusiness(BusinessTenant.RENAISSANCE_HOTELS)
                                        showBusinessMenu = false
                                    }
                                )
                            }
                        }
                    }
                },
                actions = {
                    // Division Selector Dropdown
                    if (selectedBusiness == BusinessTenant.SAMPURNA_ENTERPRISE) {
                        Box {
                            TextButton(onClick = { showDivisionMenu = true }) {
                                Text(
                                    text = when (selectedDivision) {
                                        DivisionTenant.BOTH -> "Div: Both"
                                        DivisionTenant.PRINTING -> "Div: Print"
                                        DivisionTenant.TRADING -> "Div: Trade"
                                    },
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimarySkyLight
                                )
                            }

                            DropdownMenu(
                                expanded = showDivisionMenu,
                                onDismissRequest = { showDivisionMenu = false },
                                modifier = Modifier.background(SurfaceDark)
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Consolidated (Both Divisions)") },
                                    onClick = {
                                        viewModel.selectDivision(DivisionTenant.BOTH)
                                        showDivisionMenu = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Division A: Printing & Digital") },
                                    onClick = {
                                        viewModel.selectDivision(DivisionTenant.PRINTING)
                                        showDivisionMenu = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Division B: Building & Trading") },
                                    onClick = {
                                        viewModel.selectDivision(DivisionTenant.TRADING)
                                        showDivisionMenu = false
                                    }
                                )
                            }
                        }
                    }

                    // Role / User Switcher Button (Crucial for testing RBAC and Division Isolation)
                    Box {
                        IconButton(onClick = { showRoleMenu = true }) {
                            Icon(Icons.Default.AccountCircle, contentDescription = "Role", tint = AccentAmber)
                        }

                        DropdownMenu(
                            expanded = showRoleMenu,
                            onDismissRequest = { showRoleMenu = false },
                            modifier = Modifier.background(SurfaceDark)
                        ) {
                            Text(
                                "Switch User / Role (RBAC):",
                                fontSize = 11.sp,
                                color = TextMuted,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            )
                            listOf(
                                UserRole.OWNER,
                                UserRole.ADMIN,
                                UserRole.MANAGER,
                                UserRole.SALES,
                                UserRole.PRODUCTION_MANAGER,
                                UserRole.DESIGNER,
                                UserRole.STORE_KEEPER,
                                UserRole.PURCHASE,
                                UserRole.DELIVERY,
                                UserRole.ACCOUNTANT
                            ).forEach { role ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            "${role.displayName}${if (currentUser.role == role) " ✓" else ""}",
                                            color = if (currentUser.role == role) PrimarySkyLight else TextPrimary,
                                            fontSize = 12.sp
                                        )
                                    },
                                    onClick = {
                                        viewModel.switchUserRole(role)
                                        showRoleMenu = false
                                    }
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SurfaceDark,
                    titleContentColor = TextPrimary
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = SurfaceDark,
                contentColor = TextPrimary,
                modifier = Modifier.navigationBarsPadding()
            ) {
                NavigationBarItem(
                    selected = activeTab == "DASHBOARD",
                    onClick = { viewModel.selectTab("DASHBOARD") },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                    label = { Text("Dashboard", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = activeTab == "QUOTATIONS",
                    onClick = { viewModel.selectTab("QUOTATIONS") },
                    icon = { Icon(Icons.Default.RequestQuote, contentDescription = "Quotes") },
                    label = { Text("Quotes", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = activeTab == "KANBAN",
                    onClick = { viewModel.selectTab("KANBAN") },
                    icon = { Icon(Icons.Default.ViewKanban, contentDescription = "Kanban") },
                    label = { Text("Kanban", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = activeTab == "INVENTORY",
                    onClick = { viewModel.selectTab("INVENTORY") },
                    icon = { Icon(Icons.Default.Inventory, contentDescription = "Stock") },
                    label = { Text("Stock", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = activeTab == "INVOICES",
                    onClick = { viewModel.selectTab("INVOICES") },
                    icon = { Icon(Icons.Default.Receipt, contentDescription = "Billing") },
                    label = { Text("Billing", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = activeTab == "CUSTOMERS",
                    onClick = { viewModel.selectTab("CUSTOMERS") },
                    icon = { Icon(Icons.Default.People, contentDescription = "Customers") },
                    label = { Text("Customers", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = activeTab == "AI_COO",
                    onClick = { viewModel.selectTab("AI_COO") },
                    icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "AI COO") },
                    label = { Text("AI COO", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = activeTab == "APPROVALS",
                    onClick = { viewModel.selectTab("APPROVALS") },
                    icon = { Icon(Icons.Default.Gavel, contentDescription = "Audit") },
                    label = { Text("Audit", fontSize = 10.sp) }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeTab) {
                "DASHBOARD" -> DashboardScreen(
                    viewModel = viewModel,
                    onNavigateTab = { viewModel.selectTab(it) }
                )
                "QUOTATIONS" -> QuotationScreen(viewModel = viewModel)
                "KANBAN" -> ProductionKanbanScreen(viewModel = viewModel)
                "INVENTORY" -> InventoryScreen(viewModel = viewModel)
                "INVOICES" -> InvoicesScreen(viewModel = viewModel)
                "CUSTOMERS" -> CustomersScreen(viewModel = viewModel)
                "AI_COO" -> AiCommandScreen(viewModel = viewModel)
                "APPROVALS" -> ApprovalsScreen(viewModel = viewModel)
                else -> DashboardScreen(
                    viewModel = viewModel,
                    onNavigateTab = { viewModel.selectTab(it) }
                )
            }
        }
    }
}
