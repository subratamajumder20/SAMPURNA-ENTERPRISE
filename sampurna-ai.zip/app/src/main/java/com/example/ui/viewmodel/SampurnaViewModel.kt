package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.ai.AiRouter
import com.example.core.ai.AiToolRegistry
import com.example.core.ai.RoutingTarget
import com.example.core.auth.BusinessTenant
import com.example.core.auth.DivisionTenant
import com.example.core.auth.UserRole
import com.example.core.auth.UserSession
import com.example.core.financial.PrintSpecification
import com.example.data.db.SampurnaDatabase
import com.example.data.model.*
import com.example.data.repository.CustomerHistory360
import com.example.data.repository.SampurnaRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class AiChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: String, // "USER" or "AI_COO"
    val text: String,
    val businessTag: String? = null,
    val divisionTag: String? = null,
    val dataSource: String? = null,
    val actionAvailable: String? = null,
    val approvalRequired: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

class SampurnaViewModel(application: Application) : AndroidViewModel(application) {

    private val db = SampurnaDatabase.getDatabase(application)
    val repo = SampurnaRepository(db)
    val aiRegistry = AiToolRegistry(repo)

    // Current User Session (Owner default)
    private val _currentUser = MutableStateFlow(
        UserSession(
            userId = "USER-OWNER-01",
            name = "Subrata Majumder (Owner)",
            email = "subratamajumder20@gmail.com",
            role = UserRole.OWNER,
            allowedBusiness = BusinessTenant.ALL,
            allowedDivision = DivisionTenant.BOTH
        )
    )
    val currentUser: StateFlow<UserSession> = _currentUser.asStateFlow()

    // Current Business View
    private val _selectedBusiness = MutableStateFlow(BusinessTenant.SAMPURNA_ENTERPRISE)
    val selectedBusiness: StateFlow<BusinessTenant> = _selectedBusiness.asStateFlow()

    // Current Division View (Consolidated, Printing, Trading)
    private val _selectedDivision = MutableStateFlow(DivisionTenant.BOTH)
    val selectedDivision: StateFlow<DivisionTenant> = _selectedDivision.asStateFlow()

    // Active Tab in Command Center
    private val _activeTab = MutableStateFlow("DASHBOARD")
    val activeTab: StateFlow<String> = _activeTab.asStateFlow()

    // Notification / Toast Message
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    // UI Data Flows
    val quotations = repo.getAllQuotations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders = repo.getAllOrders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val productionJobs = repo.getAllProductionJobs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val inventoryItems = repo.getAllInventory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val deliveries = repo.getAllDeliveries()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val invoices = repo.getAllInvoices()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customers = repo.getAllCustomers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingApprovals = repo.getPendingApprovals()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs = repo.getAllAuditLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockItems = repo.getLowStockItems()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bbJobCards = repo.getAllBBJobCards()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val renaissanceReservations = repo.getAllRenaissanceReservations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // AI Chat History
    private val _chatMessages = MutableStateFlow<List<AiChatMessage>>(
        listOf(
            AiChatMessage(
                sender = "AI_COO",
                text = "Welcome to SAMPURNA AI Command Center. Operating in verified database mode with multi-business routing. Ask for today's report, print quotations, trading stock checks, or B.B. Motors / Renaissance status.",
                dataSource = "SAMPURNA AI Core Foundation",
                actionAvailable = "Type queries like 'Make a quotation for 500 visiting cards' or 'Do we have 20 bags of cement?'",
                approvalRequired = "None"
            )
        )
    )
    val chatMessages: StateFlow<List<AiChatMessage>> = _chatMessages.asStateFlow()

    // Customer 360 State
    private val _selectedCustomerHistory = MutableStateFlow<CustomerHistory360?>(null)
    val selectedCustomerHistory: StateFlow<CustomerHistory360?> = _selectedCustomerHistory.asStateFlow()

    init {
        viewModelScope.launch {
            repo.seedDemoDataIfEmpty()
        }
    }

    fun selectTab(tab: String) {
        _activeTab.value = tab
    }

    fun selectBusiness(business: BusinessTenant) {
        _selectedBusiness.value = business
    }

    fun selectDivision(division: DivisionTenant) {
        _selectedDivision.value = division
    }

    fun switchUserRole(role: UserRole) {
        val divisionAccess = when (role) {
            UserRole.PRODUCTION_MANAGER, UserRole.DESIGNER -> DivisionTenant.PRINTING
            UserRole.STORE_KEEPER -> DivisionTenant.TRADING
            else -> DivisionTenant.BOTH
        }
        _currentUser.value = UserSession(
            userId = "USER-${role.name}",
            name = "${role.displayName} User",
            email = "${role.name.lowercase()}@sampurna.in",
            role = role,
            allowedBusiness = if (role == UserRole.OWNER) BusinessTenant.ALL else BusinessTenant.SAMPURNA_ENTERPRISE,
            allowedDivision = divisionAccess
        )
        _userMessage.value = "Switched active user to ${role.displayName} (Division: ${divisionAccess.name})"
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun createCustomer(name: String, phone: String, email: String?, address: String?, type: String) {
        viewModelScope.launch {
            val result = repo.createCustomer(
                name = name,
                phone = phone,
                email = email,
                address = address,
                customerType = type,
                actor = _currentUser.value
            )
            result.onSuccess {
                _userMessage.value = "Created customer ${it.name} successfully"
            }.onFailure {
                _userMessage.value = "Failed to create customer: ${it.message}"
            }
        }
    }

    fun createPrintQuotation(
        customerId: String,
        productId: String,
        spec: PrintSpecification,
        discountPercent: Double
    ) {
        viewModelScope.launch {
            val result = repo.createPrintQuotation(
                customerId = customerId,
                productId = productId,
                spec = spec,
                discountPercent = discountPercent,
                actor = _currentUser.value
            )
            result.onSuccess {
                _userMessage.value = "Created Quotation ${it.quotationNumber} (Status: ${it.status})"
            }.onFailure {
                _userMessage.value = "Quotation creation error: ${it.message}"
            }
        }
    }

    fun createTradingQuotation(
        customerId: String,
        items: List<Pair<EnterpriseProductEntity, Double>>,
        discountPercent: Double
    ) {
        viewModelScope.launch {
            val result = repo.createTradingQuotation(
                customerId = customerId,
                items = items,
                discountPercent = discountPercent,
                actor = _currentUser.value
            )
            result.onSuccess {
                _userMessage.value = "Created Quotation ${it.quotationNumber} (Status: ${it.status})"
            }.onFailure {
                _userMessage.value = "Quotation creation error: ${it.message}"
            }
        }
    }

    fun approveQuotation(quotationId: String) {
        viewModelScope.launch {
            val result = repo.approveQuotation(quotationId, _currentUser.value)
            result.onSuccess {
                _userMessage.value = "Quotation ${it.quotationNumber} approved"
            }.onFailure {
                _userMessage.value = "Approval failed: ${it.message}"
            }
        }
    }

    fun convertQuotationToOrder(quotationId: String) {
        viewModelScope.launch {
            val result = repo.convertQuotationToOrder(quotationId, _currentUser.value)
            result.onSuccess {
                _userMessage.value = "Order ${it.orderNumber} created successfully"
            }.onFailure {
                _userMessage.value = "Order conversion failed: ${it.message}"
            }
        }
    }

    fun approveArtwork(artworkId: String) {
        viewModelScope.launch {
            val result = repo.approveArtwork(artworkId, _currentUser.value)
            result.onSuccess {
                _userMessage.value = "Artwork approved. Production is now permitted."
            }.onFailure {
                _userMessage.value = "Artwork approval failed: ${it.message}"
            }
        }
    }

    fun createProductionJob(orderId: String) {
        viewModelScope.launch {
            val result = repo.createProductionJob(orderId, _currentUser.value)
            result.onSuccess {
                _userMessage.value = "Production Job ${it.jobNumber} queued"
            }.onFailure {
                _userMessage.value = "Cannot start production: ${it.message}"
            }
        }
    }

    fun updateProductionStatus(jobId: String, newStatus: String) {
        viewModelScope.launch {
            val result = repo.updateProductionStatus(jobId, newStatus, _currentUser.value)
            result.onSuccess {
                _userMessage.value = "Job status moved to $newStatus"
            }.onFailure {
                _userMessage.value = "Failed to update status: ${it.message}"
            }
        }
    }

    fun reserveMaterial(jobId: String, materialId: String, quantity: Double) {
        viewModelScope.launch {
            val result = repo.reserveMaterial(jobId, materialId, quantity, _currentUser.value)
            result.onSuccess {
                _userMessage.value = "Material reserved. Ready for production."
            }.onFailure {
                _userMessage.value = it.message
            }
        }
    }

    fun recordQualityCheck(jobId: String, orderId: String, passed: Boolean, remarks: String?) {
        viewModelScope.launch {
            val checklist = mapOf(
                "print_quality" to passed,
                "colour_accuracy" to passed,
                "paper_gsm" to passed,
                "cutting_alignment" to passed,
                "lamination_binding" to passed
            )
            val result = repo.recordQualityCheck(jobId, orderId, checklist, remarks, _currentUser.value)
            result.onSuccess {
                _userMessage.value = "QC Recorded: ${it.status}"
            }.onFailure {
                _userMessage.value = "QC record failed: ${it.message}"
            }
        }
    }

    fun packOrder(orderId: String, qty: Double, pkgCount: Int) {
        viewModelScope.launch {
            val result = repo.packOrder(orderId, qty, pkgCount, "Standard bubble pack", _currentUser.value)
            result.onSuccess {
                _userMessage.value = "Order packed into $pkgCount parcel(s)"
            }.onFailure {
                _userMessage.value = "Packing failed: ${it.message}"
            }
        }
    }

    fun createDelivery(orderId: String, method: String) {
        viewModelScope.launch {
            val result = repo.createDelivery(orderId, method, "Courier / Fleet Lead", "OD-02-AB-1234", _currentUser.value)
            result.onSuccess {
                _userMessage.value = "Delivery scheduled: ${it.deliveryNumber}"
            }.onFailure {
                _userMessage.value = "Delivery schedule failed: ${it.message}"
            }
        }
    }

    fun markDelivered(deliveryId: String, proofRef: String) {
        viewModelScope.launch {
            val result = repo.markDelivered(deliveryId, proofRef, _currentUser.value)
            result.onSuccess {
                _userMessage.value = "Delivery marked DELIVERED"
            }.onFailure {
                _userMessage.value = "Delivery update failed: ${it.message}"
            }
        }
    }

    fun createInvoice(orderId: String) {
        viewModelScope.launch {
            val result = repo.createInvoiceForOrder(orderId, _currentUser.value)
            result.onSuccess {
                _userMessage.value = "Invoice generated: ${it.invoiceNumber}"
            }.onFailure {
                _userMessage.value = "Invoice generation failed: ${it.message}"
            }
        }
    }

    fun recordPayment(invoiceId: String, amount: Double, method: String, refNumber: String?) {
        viewModelScope.launch {
            val result = repo.recordPayment(invoiceId, amount, method, refNumber, "Customer collection", _currentUser.value)
            result.onSuccess {
                _userMessage.value = "Payment recorded: ₹$amount"
            }.onFailure {
                _userMessage.value = "Payment failed: ${it.message}"
            }
        }
    }

    fun loadCustomerHistory(customerId: String) {
        viewModelScope.launch {
            _selectedCustomerHistory.value = repo.getCustomerHistory(customerId)
        }
    }

    fun createBBJobCard(vehicleRegNo: String, customerId: String, estimatedCost: Double) {
        viewModelScope.launch {
            val jc = repo.createBBMotorJobCard(vehicleRegNo, customerId, estimatedCost)
            _userMessage.value = "Created B.B. Motors Job Card ${jc.jobNumber}"
        }
    }

    fun createRenaissanceReservation(location: String, roomType: String, customerId: String, totalAmount: Double) {
        viewModelScope.launch {
            val res = repo.createRenaissanceReservation(location, roomType, customerId, totalAmount)
            _userMessage.value = "Created Renaissance Reservation ${res.reservationNumber} ($location)"
        }
    }

    // AI COO Natural Language Query Processing
    fun sendAiQuery(userQuery: String) {
        val trimmed = userQuery.trim()
        if (trimmed.isBlank()) return

        val userMsg = AiChatMessage(sender = "USER", text = trimmed)
        _chatMessages.value = _chatMessages.value + userMsg

        viewModelScope.launch {
            // 1. AI Business & Division Routing
            val routing = AiRouter.routeQuery(trimmed)

            val response: AiChatMessage = when (routing.target) {
                RoutingTarget.BB_MOTORS -> {
                    val count = repo.getBBJobCardsCount()
                    AiChatMessage(
                        sender = "AI_COO",
                        text = "Routed to B.B. Motors Automotive System.\n\nFound $count active job card(s). I can inspect vehicle service records or create a job card.",
                        businessTag = "B.B. Motors",
                        dataSource = "B.B. Motors Job Card Register (Phase 2A Baseline)",
                        actionAvailable = "Open B.B. Motors Job Card console",
                        approvalRequired = "None"
                    )
                }
                RoutingTarget.RENAISSANCE_HOTELS -> {
                    val reservations = repo.getRenaissanceReservations("Puri")
                    AiChatMessage(
                        sender = "AI_COO",
                        text = "Routed to Renaissance Hotels Hospitality Module.\n\nPuri Property has ${reservations.size} confirmed room booking(s). Deluxe and Super Deluxe rooms are configured.",
                        businessTag = "Renaissance Hotels",
                        dataSource = "Renaissance Hotels Room Reservation Database (Phase 2B Baseline)",
                        actionAvailable = "Open Room Reservation dashboard",
                        approvalRequired = "None"
                    )
                }
                RoutingTarget.SAMPURNA_ENTERPRISE_PRINTING -> {
                    // Check if quote request
                    if (trimmed.contains("visiting card", ignoreCase = true) || trimmed.contains("quotation", ignoreCase = true)) {
                        val result = aiRegistry.executeTool("calculate_print_quote", mapOf("quantity" to 500, "paperType" to "Art Card", "gsm" to 350), _currentUser.value)
                        AiChatMessage(
                            sender = "AI_COO",
                            text = result.answer,
                            businessTag = "Sampurna Enterprise",
                            divisionTag = "Printing",
                            dataSource = result.dataSource,
                            actionAvailable = result.actionAvailable,
                            approvalRequired = result.approvalRequired
                        )
                    } else {
                        val result = aiRegistry.executeTool("get_enterprise_dashboard", mapOf("division" to "PRINTING"), _currentUser.value)
                        AiChatMessage(
                            sender = "AI_COO",
                            text = result.answer,
                            businessTag = "Sampurna Enterprise",
                            divisionTag = "Printing",
                            dataSource = result.dataSource,
                            actionAvailable = result.actionAvailable,
                            approvalRequired = result.approvalRequired
                        )
                    }
                }
                RoutingTarget.SAMPURNA_ENTERPRISE_TRADING -> {
                    if (trimmed.contains("cement", ignoreCase = true)) {
                        val result = aiRegistry.executeTool("check_material_availability", mapOf("materialQuery" to "Cement", "quantity" to 20.0), _currentUser.value)
                        AiChatMessage(
                            sender = "AI_COO",
                            text = result.answer,
                            businessTag = "Sampurna Enterprise",
                            divisionTag = "Trading",
                            dataSource = result.dataSource,
                            actionAvailable = result.actionAvailable,
                            approvalRequired = result.approvalRequired
                        )
                    } else {
                        val result = aiRegistry.executeTool("get_enterprise_dashboard", mapOf("division" to "TRADING"), _currentUser.value)
                        AiChatMessage(
                            sender = "AI_COO",
                            text = result.answer,
                            businessTag = "Sampurna Enterprise",
                            divisionTag = "Trading",
                            dataSource = result.dataSource,
                            actionAvailable = result.actionAvailable,
                            approvalRequired = result.approvalRequired
                        )
                    }
                }
                else -> {
                    if (trimmed.contains("report", ignoreCase = true) || trimmed.contains("brief", ignoreCase = true)) {
                        val result = aiRegistry.executeTool("generate_enterprise_report", emptyMap(), _currentUser.value)
                        AiChatMessage(
                            sender = "AI_COO",
                            text = result.answer,
                            businessTag = "Sampurna Enterprise",
                            dataSource = result.dataSource,
                            actionAvailable = result.actionAvailable,
                            approvalRequired = result.approvalRequired
                        )
                    } else {
                        AiChatMessage(
                            sender = "AI_COO",
                            text = "Verified data response: Query received for general business intelligence. You can ask for 'today's report', print quotations, cement stock check, or switch business tenants.",
                            dataSource = "SAMPURNA AI Knowledge Core",
                            actionAvailable = "Select actions from Dashboard or type specific commands.",
                            approvalRequired = "None"
                        )
                    }
                }
            }

            _chatMessages.value = _chatMessages.value + response
        }
    }
}
