package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SampurnaDarkColorScheme = darkColorScheme(
    primary = PrimarySkyLight,
    onPrimary = Color.Black,
    primaryContainer = PrimarySky,
    onPrimaryContainer = Color.White,
    secondary = AccentAmber,
    onSecondary = Color.Black,
    secondaryContainer = SlateBorder,
    onSecondaryContainer = TextPrimary,
    tertiary = SuccessEmerald,
    background = BackgroundDark,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SlateCard,
    onSurfaceVariant = TextSecondary,
    outline = SlateBorder
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SampurnaDarkColorScheme,
        typography = Typography,
        content = content
    )
}
